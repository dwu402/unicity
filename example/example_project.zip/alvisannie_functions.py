# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		
		# create empty node object	
		node = Node() 
		# store the name of the node
		node.name = name 
		# store any weight the node has
		node.value = value 
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		# create an empty arc object
		arc = Arc() 
		# store the weight of the arc
		arc.weight = weight 
		# store where the arc is going to 
		arc.to_node = node_to 
		# store where the arc is coming from
		arc.from_node = node_from 
		# store that there is an arc leaving the source node
		node_from.arcs_out.append(arc) 
		# store that there is an arc arriving at the destination node
		node_to.arcs_in.append(arc) 
		# store the new arc onto the network list of all arcs
		self.arcs.append(arc) 
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		# open the file
		fp = open(filename, 'r')
		#print('\n \n \n START \n \n \n')
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			X = ln.split(",") 
			# get the number of elements (source node and arcs)
			Z = len(X)
			# source node to be checked below
			from_node_name = X[0] 
			# create an empty list
			arcs = [] 
			#loop through the list
			for i in range(1, Z): 
				temp = X[i] #store the destination and weight temporarily
				arcs.append(temp) #append that data into the arcs list
			
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			source = self.get_node(from_node_name) 
			
			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				node, weight = arc.split(";") 
				
				# get destination node object and link it to source node
				# if destination node doesn't exist, add it to network
				try:
					self.get_node(node)
				except NetworkError:
					self.add_node(node)
					
				# get the node object
				node = self.get_node(node)
				# create the arc between source and destination
				self.join_nodes(source, node, weight) 
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		
		# get all the text files with the capacity data
		connections = glob(directory + '\\connections\\*')
		# get all the node floders 
		nodes = glob(directory + '\\*\\station_data.txt')
		
		for node in nodes:
			#open the node folder for reading
			f = open(node, 'r') 
			#create an empty list
			data = [] 
			#loop through the text file
			for line in f: 
				X = line.split(":") #split the data into two strings as per the ':' delimiter 
				data.append(X) #store the split data in the list
			
			# take the name of node
			name = data[0][1].strip() 
			#take the x coordinate of the node
			x = data[1][1].strip()
			#take the y coordinate of the node			
			y = data[2][1].strip()
			# store the coordinates in a list and cast to floating point numbers
			temp = [float(x), float(y)] 
			# convert the list into an array
			coordinates = np.asarray(temp) 
			# add the new node with its appropriate name and coordinates
			self.add_node(name, coordinates) 
			
		for connection in connections:
			# read the text file to pull out the values for the capacity and store them in an array
			capacity = np.genfromtxt(connection, delimiter = ',', skip_header=1, usecols = (1), unpack = True)
			# calculate the mean capacity
			mean = np.mean(capacity)
			# get the filename
			filename = os.path.basename(connection)
			# split the filename apart from its '.txt' extension
			test = os.path.splitext(filename)
			# take the node names from the filename using '-' as the delimiter
			from_node_name, to_node_name = test[0].split("-")
			# get the corresponding nodes from the network
			node_from = self.get_node(from_node_name)
			node_to = self.get_node(to_node_name)
			# add the new arc between the nodes
			self.join_nodes(node_to, node_from, mean)
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
