import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			X = ln.split(",")
			Z = len(X)
			from_stat_name = X[0]
			conns = []
			for i in range(1, Z):
				temp = X[i] 
				conns.append(temp) 
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source = self.query_station(from_stat_name)
			for conn in conns:
				stat, weight = conn.split(";")
				try:
					self.query_station(stat)
				except GridError:
					self.add_station(stat)
				stat = self.query_station(stat)
				self.add_connection(source, stat, weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		connexions = glob(directory + '\\connections\\*')
		stations = glob(directory + '\\*\\info.txt')
		for stat in stations:
			f = open(stat, 'r')
			data = []
			for line in f:
				X = line.split(":") 
				data.append(X) 
			name = data[0][1].strip()
			x = data[1][1].strip()
			y = data[2][1].strip()
			temp = [float(x), float(y)]
			coordinates = np.asarray(temp)
			self.add_station(name, coordinates)
		for connexion in connexions:
			capacity = np.genfromtxt(connexion, delimiter = ',', skip_header=1, usecols = (1), unpack = True)
			mean = np.mean(capacity)
			filename = os.path.basename(connexion)
			test = os.path.splitext(filename)
			from_stat_name, to_stat_name = test[0].split("-")
			stat_from = self.query_station(from_stat_name)
			stat_to = self.query_station(to_stat_name)
			self.add_connection(stat_to, stat_from, mean)
