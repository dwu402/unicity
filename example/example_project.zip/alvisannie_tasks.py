import numpy as np

# lab 5 task 1a 

(Xs, Ts) = np.genfromtxt('example_file.txt', delimiter = ',', skip_header=1, unpack = True)
