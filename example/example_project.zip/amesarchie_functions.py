import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		conn.wgt = weight
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			ln = ln.split(",")
			conns = ln[1:]
			from_stat_name = ln[0]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			from_stat = self.query_station(from_stat_name)
			for conn in conns:
				connnames = conn.split(";")
				destination_stat = connnames[0]
				connweight = int(connnames[1])
				try:
					self.query_station(destination_stat)
				except GridError:
					self.add_station(destination_stat)
				stat_to_join = self.query_station(destination_stat)
				self.add_connection(from_stat, stat_to_join, connweight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		subfiles = glob(directory+os.sep+'*')
		for subfile in subfiles:
			if (subfile.split(os.sep)[-1]) != 'backbone':
				station = subfile.split(os.sep)[-1]
				datafilepath = directory+os.sep+station+os.sep+'info.txt'
				fp = open(datafilepath, 'r')
				hdr = fp.readline()
				header,stat_name = hdr.split()
				header,x = (fp.readline()).split()
				header,y = (fp.readline()).split()
				x = int(x)
				y = int(y)
				fp.close()
				self.add_station(stat_name, [x,y])
		for subfile in subfiles:
			if (subfile.split(os.sep)[-1]) == 'backbone':
				connection_files = glob(subfile+os.sep+'*')
				for connection_file in connection_files:
					source,destination = (connection_file.strip(directory+os.sep+'backbone'+'.txt')).split('-')
					source_stat = self.query_station(source)
					destination_stat = self.query_station(destination)
					year, capacity = np.genfromtxt(connection_file, delimiter = ',',skip_header = 1, unpack = 1, dtype = float )
					weight = np.mean(capacity)
					self.add_connection(source_stat,destination_stat,weight)
