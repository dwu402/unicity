# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	def __init__(self):
		self.nodes = []
		self.arcs = []
	# these methods are complete, do not modify them
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		node = Node()
		node.name = name
		node.value = value
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		arc = Arc()
		arc.to_node = node_to
		arc.from_node = node_from
		arc.weight = weight
		
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		self.arcs.append(arc)
		
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		

	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			ln = ln.split(",")
			arcs = ln[1:]
			from_node_name = ln[0]
			
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			from_node = self.get_node(from_node_name)
			
			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				arcnames = arc.split(";")
				destination_node = arcnames[0]
				arcweight = int(arcnames[1])
				
				# get destination node object and link it to source node
				try:
					self.get_node(destination_node)
				except NetworkError:
					self.add_node(destination_node)
					
				node_to_join = self.get_node(destination_node)
				self.join_nodes(from_node, node_to_join, arcweight)
				
						
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		
		# define subfiles as all the files within DIRECTORY
		subfiles = glob(directory+os.sep+'*')
		
		#loop through these files, finding all those not called 'connections'
		for subfile in subfiles:
			if (subfile.split(os.sep)[-1]) != 'connections':
				station = subfile.split(os.sep)[-1]
				#determine the path for the station data file for each node
				datafilepath = directory+os.sep+station+os.sep+'station_data.txt'	
				#open this file and read out node name by splitting up first line
				fp = open(datafilepath, 'r')
				hdr = fp.readline()
				header,node_name = hdr.split()
				#find x and y by reading next lines down, splitting by blank space seperator
				header,x = (fp.readline()).split()
				header,y = (fp.readline()).split()
				#convert x and y to integers
				x = int(x)
				y = int(y)
				fp.close()
				#use add_node to add this node and the values to the network
				self.add_node(node_name, [x,y])
				
		#loop through all subfiles searching for 'connections' folder
		for subfile in subfiles:
			if (subfile.split(os.sep)[-1]) == 'connections':
				#loop through all connection files (node-node) which will form the arcs between the existing node setup
				connection_files = glob(subfile+os.sep+'*')
				for connection_file in connection_files:
					#determine which nodes are connected using the filename
					source,destination = (connection_file.strip(directory+os.sep+'connections'+'.txt')).split('-')
					#use get_node to get these node objects
					source_node = self.get_node(source)
					destination_node = self.get_node(destination)
					#read this connection file and get two vectors (one for each column of the file)
					year, capacity = np.genfromtxt(connection_file, delimiter = ',',skip_header = 1, unpack = 1, dtype = float )
					#weight of the arc will be the mean of the capacity column
					weight = np.mean(capacity)
					#use join_nodes to link these two node objects with the given weight
					self.join_nodes(source_node,destination_node,weight)

	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
