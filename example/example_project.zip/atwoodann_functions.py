# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	

class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		#Creating an empty node object
		node = Node()
		#assigning name attribute
		node.name = name
		#assigning value attribute
		node.value = value
				
		# append node to the list of nodes
		self.nodes.append(node)
		
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		
		#Creating an empty arc object
		arc = Arc()
		
		#Assigning weight, to node and from node attributes
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from
		
		#appending node from and node to
		node_from.arcs_out.append(arc) 
		node_to.arcs_in.append(arc)
		
		#append to list of arcs
		self.arcs.append(arc)
		
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		
		
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			
			# split string into source node name and other arcs by splitting with respect to a comma
			arcs = ln.split(',')
			
			#Assigning source node
			from_node_name= arcs[0]
			
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			
			#deleting first value, i.e. source node off stack
			del arcs[0]
			
			#Assinging value of arc weight and destination to nodes
			for Arc  in arcs:
							
				#splitting line based on semi-colon and assingning value to destination and weight			
				destination, weight = Arc.split(';')
				
				#adding node to network if it doesn't exist
				try:
					self.get_node(destination)
				except NetworkError:
					self.add_node(destination)
				
				
				#using the join nodes function to create nodes and arcs with correct weight and destination
				self.join_nodes(self.get_node(from_node_name), self.get_node(destination), weight)
				
				
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
				
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		#directory\station_data.txt
		import fnmatch
		import os
		import glob
				
		#This is a function that finds the names of a list of folders in a given directory		
		def listdirs(folder):
			return [
				d for d in (os.path.join(folder, d1) for d1 in os.listdir(folder))
				if os.path.isdir(d)
			]
		#Calling the function above to find the list of names in 'nz_network' folder
		listnames = listdirs(directory)
		
		
		#This runs through each subfolder within the directory
		for getpos in listnames:
			#this is the special case, where the connections folder is sitting, acts to pass over it
			if getpos == 'nz_network\\connections':
				print()
				
			else:
												
				#coordinate acts as the address to station_data.txt, allowing access.
				coordinate = getpos+"\station_data.txt"
				#This reads information from the station_data.txt folder, where nodename has three elements 
				nodename = np.genfromtxt(coordinate, dtype = 'str', delimiter = ': ', unpack = True, usecols = 1)
				
				#Gets value of x and y coordinates from the text folder
				x,y = np.genfromtxt(coordinate, delimiter = ': ', skip_header=1, unpack = True, usecols = 1)
				#assinging the value of the coordinates to one varibale within an array
				value = [x,y]
				#assinging the name of the place to the node 
				nodenamefinal = nodename[0]
				#Calling add node function, to add the node with the coordinates
				self.add_node(nodenamefinal,value)
				
			
		
		
		
	
		#This is the case where dealing with the connections folder
		conpos = directory+"\\connections"
		
		#importing os 
		import os
		
		#looping through all the files within connections
		for file in os.listdir(conpos):
			#finding text files
			if file.endswith(".txt"):
				#this gives the first 3 letters of text files name, i.e. BPE
				nodefrom = file[0:3]
				#This gives the characters 5,6,7 of the file name i.e HAY
				nodeto = file[4:7]
				#importing numpy
				import numpy
				#This creates an 1 row array with all the capacity values
				#the os.path.join creates the path for the specific text file, is sorted by commas, skips the header and takes the information 
				#from second column
				capacity = np.genfromtxt((os.path.join(conpos, file)), delimiter = ', ', skip_header=1, unpack = True, usecols = 1)
				
				#This is an inbuilt function that finds the mean of the capacity array created, which represents the weight of the arc 
				capacityWeight= (numpy.mean(capacity))
				
				#Using the join_nodes function defined above, creates an arc linking the nodes to and from with the weight from the capacity
				self.join_nodes(self.get_node(nodefrom), self.get_node(nodeto), capacityWeight)
				
	
			


	
	
	
	
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
		
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
