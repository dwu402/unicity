# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		#Create empty node object and assign input attributes:
		node = Node()
		node.name = name
		node.value = value
				
		#Append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		#Create an empty arc object, assign its attributes
		arc = Arc()
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from
		
		# Modify the arcs_in and arcs_out of relevant nodes. Then append new arc into network. 
		node_to.arcs_in.append(arc)
		node_from.arcs_out.append(arc)
		self.arcs.append(arc)
		
		
		
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using string.split() method 
			nodes = ln.split(',')
			#Initialise empty variables
			node_names = []
			weights = []
			#Add first 'source' node into node_names array
			node_names.append(nodes[0])
			
			#Now cycle through daughter nodes
			for i in range(len(nodes) - 1):
				i = i +1
				#For each daughter store node name and weight of arc
				node_names.append(nodes[i].split(';')[0])
				weights.append(nodes[i].split(';')[1])
				
			for i in range(len(nodes)):  #Cycle through names of daughter names, adding to network if not encountered previously. 
				# if node doesn't exist, add to network
				try:
					self.get_node(node_names[i])
				except NetworkError:
					self.add_node(node_names[i])
							
			# Now add arcs to network, using values stored in array
			for i in range(len(weights)):
				self.join_nodes(self.get_node(node_names[0]), self.get_node(node_names[i+1]), weights[i])
			
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		#Import glob function
		from glob import glob
		
		#Initialise useful variables:
		slash = os.sep  #Used in file names
				
		#Check directory is valid, if not return error message, if so perform function.  
		if os.path.isdir(directory):
			#Access all folder names in directory
			folders = glob('{}{}*'.format(directory, slash))
						
			for i in range(len(folders)):	#Cycle through all folders
			
				if folders[i] != '{}{}connections'.format(directory, slash):   #Access all folders except connections folder.
					
					#Open the station data text file within each location subfolder
					fp = open('{}{}station_data.txt'.format(folders[i], slash),'r')
					#Read 3 letter code for location from first line by stripping unnecessary text
					firstline = fp.readline()
					code =(firstline.strip('code: *\n'))
					#Access next line,Read x co-ord, and cast as integer:
					secondline = fp.readline()
					xval = (secondline.strip('x: *\n'))
					xval = int(xval)
					#Access next line, Read y co-ord, and cast as integer:
					thirdline = fp.readline()
					yval = (thirdline.strip('y: *\n'))
					yval = int(yval)
					#Close the folder
					fp.close()
					#Add the node to the network with attributes that have just been read. 
					self.add_node(code, [xval,yval])
			
			
			#After all nodes have been added to the network, arc data can be added:
			
			#Get names for all folders in the connections subfolder
			conFolders = glob('{}{}connections{}*'.format(directory, slash, slash))
			
			for i in range(len(conFolders)):	#Cycle through all subfolders in the connections folder. 
				#Isolate the node names 'ABC-DEF' segment of foldernames
				nod2nod = conFolders[i].strip('{}{}connections{}*.txt'.format(directory, slash, slash))
				#Find names of the nodes the arc is to and from by splitting the 'ABC-DEF' string 
				from_node, to_node = nod2nod.split('-')
				
				#Isolate the capacities information from the text file in the subfolder
				capacities = np.genfromtxt('{}'.format(conFolders[i]), delimiter = ',', skip_header=1, usecols = (1), unpack = True )
				#Cast this data as array, not a list
				capacities = np.asarray(capacities)
				#Use array to calculate mean, used for weight of arc
				conWeight = np.mean(capacities)
				
				#access relevant nodes with node names
				from_node = self.get_node(from_node)
				to_node = self.get_node(to_node)
				
				#join nodes with arc of calculated weight
				self.join_nodes(from_node, to_node, conWeight)					
			
		else :
			print('Directory not found')
		
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
