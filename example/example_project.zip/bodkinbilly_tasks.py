
# Task 1a: File I/O
# In the notes, we saw how text files could be opened, read, and interpreted in terms of data and metadata.
# Research how to use the function np.genfromtxt to read data from 'example_file.txt', returning vectors, xs and Ts. This can be done in a single line.
import numpy as np
xs, Ts = np.genfromtxt('example_file.txt', delimiter = ',', skip_header=1, unpack = True )

# Task 1b: Network data structures
#
# Networks can be thought of as a series of NODES /  \ linked by ARCS \
#                                                 \__/                _\|
#                                                                      
# For example:
#          __          __          
#         /  \ _____\ /  \ 
#	   _  \__/      / \__/ 
#       /|    \         | \ 
#      /       \        |  \
#  __ /         \       |  _\|__
# /  \           \      |    /  \
# \__/            \     |  _ \__/
#     \            \    |   /|
#      \            \   V  /  
#      _\| __       _\|__ /   
#         /  \ _____\ /  \   
#         \__/      / \__/   
#
#
# Each Arc has associated with it a WEIGHT, which could be, say, the capacity 
# of that network connection. An Arc points FROM one node TO another, i.e., these are
# singly DIRECTED Arcs.
#
# Each Node has associated with it a VALUE (a quantity/location/thing), a list of Arcs 
# entering the node, and a list of Arcs leaving the node.

# Modify the classes and methods defined for linked lists during class to describe a network structure. 

# ** to do: Complete the Network class in lab5_functions.py**
from lab5_functions import*

#Create an empty network object
network = Network()

# pass the asserts to verify add_node method is working correctly
network.add_node('A', 2)
ndA = network.get_node('A')
assert(ndA.name == 'A')
assert(ndA.value == 2)

# pass the asserts to verify join_nodes method is working correctly
network.add_node('B', 3)
ndB = network.get_node('B')
network.join_nodes(ndA,ndB,2)
assert(ndA.arcs_out[0].to_node.name == 'B')
assert(ndB.arcs_in[0].from_node.name == 'A')
assert(ndA.arcs_out[0].weight == 2)

# read the network
network = Network()
network.read_network('network.txt')

# print out the network information
network.display()




