import numpy as np
[Xs, Ts] = np.genfromtxt('data.txt', delimiter = ",", skip_header=1, unpack = True);
