import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station() 
		stat.id = name
		stat.val = value
		self.stations.append(stat) 
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection() 
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		conn.wgt = weight
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			arg = ln.split(',')
			stat_name = arg[0]
			try:
				self.query_station(stat_name) 
			except GridError:
				self.add_station(stat_name) 
			stat_from = self.query_station(stat_name)
			conns = arg[1:]
			for conn in conns:
				arg2 = conn.split(';')
				stat_name = arg2[0]
				weight = float(arg2[1])
				self.add_station(stat_to)
				stat_to = self.query_station(stat_name)
				self.add_connection(stat_from, stat_to,weight)
			ln = fp.readline().strip()
		fp.seek(0)
class Roads(Grid):
	def read(self, directory):
		files = glob(directory+os.sep+'*'+os.sep+'info.txt')
		for file in files:
			x_col,y_col = np.genfromtxt(file,dtype = 'str', delimiter=': ',unpack =True)
			stat_name = y_col[0]
			x = int(y_col[1])
			y = int(y_col[2])
			try:
				self.query_station(stat_name)
			except GridError:
				self.add_station(stat_name, value = [x,y])
		connections = glob(directory+os.sep+'backbone'+os.sep+'*')
		for connection in connections:
			arg = connection.split(os.sep)
			file_name = arg[2]
			code = file_name.split('-')
			stat_from = code[0]
			arg2 = code[1].split('.')
			stat_to = arg2[0]
			time, capacity = np.genfromtxt(connection, skip_header = 1, delimiter=',',unpack =True)
			weight = np.mean(capacity)
			self.add_connection(self.query_station(stat_from), self.query_station(stat_to), weight)
