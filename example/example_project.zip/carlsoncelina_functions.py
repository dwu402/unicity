# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

#objects is a variable or type of thingy(pointer, arc, node), a class is the type of variable(int or string) 	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		
		node = Node() #make a new node
		node.name = name
		node.value = value
		# append node to the list of nodes
		self.nodes.append(node) #this adds the new node created onto the original nextwork 
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		
		arc = Arc() # **to do: create an empty arc object, assign its attributes**
		arc.from_node = node_from
		arc.to_node = node_to
		arc.weight = weight
		
		self.arcs.append(arc)
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
	
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			
			# split string into source node name and other arcs using split() method for strings
			arg = ln.split(',') 
			
			#the first index postition should be the node name of the
			node_name = arg[0] 
			
			# if node doesn't exist, add to network
			try:
				self.get_node(node_name) #looks to see if this node exists
			except NetworkError:
				self.add_node(node_name) #creates a node	
			
			# get the source node object
			node_from = self.get_node(node_name)
			
			#creates a list that has the arcs information
			arcs = arg[1:]
			
			# read the arc information and add to network
			for arc in arcs:
				
				# parse arc information
				
				#split the rest of the arguments 
				arg2 = arc.split(';')
				
				#find the node that the arc is going to 
				node_name = arg2[0] 
				
				#assign the weight for the arc
				weight = float(arg2[1])
				
				#create a new node
				self.add_node(node_to)
				node_to = self.get_node(node_name)
				
				# get destination node object and link it to source node
				self.join_nodes(node_from, node_to,weight)
						
			# get next line
			ln = fp.readline().strip()
		fp.seek(0)
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
			''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		
		#open the files and look for those that have the correct file
		files = glob(directory+os.sep+'*'+os.sep+'station_data.txt')
			
		#THIS LOOP CREATES THE NODES
		for file in files:

			#unpacks the data from the file into two arrays
			x_col,y_col = np.genfromtxt(file,dtype = 'str', delimiter=': ',unpack =True)
			
			#assigns the node name, it should be the first index position of the array
			node_name = y_col[0]
			
			#assigns the x and y co-ordinates of the node
			x = int(y_col[1])
			y = int(y_col[2])
	
			#this should create the nodes
			try:
				self.get_node(node_name)
			except NetworkError:
				self.add_node(node_name, value = [x,y])
			
		#accesses the connections folder
		connections = glob(directory+os.sep+'connections'+os.sep+'*')
		
		#This loop creates the connections between the nodes
		for connection in connections:
			
			#split the directory into the filename
			arg = connection.split(os.sep)
			
			#assign the file name to the third index position
			file_name = arg[2]				
			
			#find the node name and assign the source node 
			code = file_name.split('-')
			node_from = code[0]
			
			#split second index postion to find the node that the arc is going to 
			arg2 = code[1].split('.')		
			node_to = arg2[0]
			
			#unpack the file into two lists and calculate the mean 
			time, capacity = np.genfromtxt(connection, skip_header = 1, delimiter=',',unpack =True)
			weight = np.mean(capacity)
			
			#join the nodes 
			self.join_nodes(self.get_node(node_from), self.get_node(node_to), weight)
			
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
