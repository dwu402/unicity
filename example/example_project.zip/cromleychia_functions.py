import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station() 
		stat.val = value 
		stat.id = name 
		self.stations.append(stat) 
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection() 
		conn.from_stat = stat_from 
		conn.to_stat = stat_to 
		conn.wgt = weight 
		self.connections.append(conn) 
		stat_from.cons_out.append(conn) 
		stat_to.cons_in.append(conn) 
	def read(self, filename):
		fp = open(filename, 'r') 
		ln = fp.readline().strip() 
		while ln is not '':        
			list = ln.split(',')
			source_name = list[0] 
			try:
				self.query_station(source_name) 
			except GridError:
				self.add_station(source_name) 
			source_stat_object = self.query_station(source_name) 
			conns = list[1:] 
			for conn in conns: 
				conn2= conn.split(';') 
				stat_to = conn2[0] 
				weight = float(conn2[1]) 
				try:
					self.query_station(stat_to) 
				except:
					self.add_station(stat_to) 
				stat_to = self.query_station(stat_to) 
				self.add_connection(source_stat_object, stat_to, weight) 
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		files = glob(directory+os.sep+'*'+os.sep+'info.txt')
		for i in files:
			first, second = np.genfromtxt(i, dtype = 'str', delimiter = ': ', unpack = True)
			statname = second[0]
			x = int(second[1])
			y = int(second[2])
			try:
				self.query_station(statname)
			except:
				self.add_station(statname, value = [x,y])
		connectionsfile = glob(directory+os.sep+'backbone'+os.sep+'*')
		for i in connectionsfile:
			filename = i.split(os.sep)
			locations = filename[2] 
			title1 = locations.split('-') 
			title2 = title1[1].split('.') 
			stat_from = title1[0] 
			stat_to = title2[0] 
			first, second = np.genfromtxt(i, skip_header = 1, delimiter = ',', unpack = True)
			weight = np.mean(second)
			self.add_connection(self.query_station(stat_from),self.query_station(stat_to), weight)
