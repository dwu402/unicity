# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# define node and arc variables with class object
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
class Network(object):
	''' Basic network class.
	'''
	
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''

		node = Node()
		node.name = name
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		
		arc = Arc()
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from
		
		# Append the arcs to the list of arcs of the nodes
		node_to.arcs_in.append(arc)
		node_from.arcs_out.append(arc)
		self.arcs.append(arc)
		
	def get_or_add_node(self, node_name):
		''' If the node does not exist, add to network 
		'''
		try:
			self.get_node(node_name)
		except NetworkError:
			self.add_node(node_name)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			- the name of a source node (first entry)
			- and destination;weight pairs (each pair separated by a comma)
		 
			Loop through each line of the file and add the nodes and arcs to the network
		'''
		
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '': # keep looping to the end of the file
			
			# test the special instance if there are no arcs connnected to the node
			if len(ln.split(',', 1)) == 1:
				self.get_or_add_node(ln)
				# get the next line
				ln = fp.readline().strip()
				continue
			
			# split string into source node name and other arcs using split() method for strings
			source_node_name, arcs = ln.split(',', 1)
			arcs = arcs.split(',')
			
			# if the node doesn't exist, add it to the network
			self.get_or_add_node(source_node_name)
				
			# get the source node object
			source_node = self.get_node(source_node_name)
				
			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				destination_node_name, weight = arc.split(';')
				weight = int(weight)
				
				# if the_node doesn't exist, add to network
				self.get_or_add_node(destination_node_name)
				
				# get the destination_node object
				destination_node = self.get_node(destination_node_name)
				
				# link the destination node to the source node
				self.join_nodes(source_node, destination_node, weight)
						
			# get next line
			ln = fp.readline().strip()
			
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# get all the text files with the capacity data
		connections = glob(directory + '\\connections\\*')
		# get all the node floders 
		nodes = glob(directory + '\\*\\station_data.txt')
		
		# loop through each subfolder in the directory
		for subfolder in os.listdir(directory):
		
			# the subfolder contains data detailing the nodes
			if (subfolder != 'connections'):
			
				# find the path for the data file in each subfolder
				filename = str(os.listdir(r'%s\%s' % (directory, subfolder))).strip("""['']""")
				path = (r'%s\%s\%s' % (directory, subfolder, filename))
				
				# read the node data from the txt file in each subfolder
				name = np.genfromtxt(path, dtype = ('S'), delimiter = ':', usecols = (1), max_rows = (1)).tostring().strip().decode() # format into a string
				x, y = np.genfromtxt(path, delimiter = ':', skip_header = (1), usecols = (1)) # get the coordinates
				value = [x, y]
				
				# add the node to the network
				self.add_node(name, value)
			
			# the subfolder contains data detailing the arcs
			else:
				arc_path = (r'%s\%s' % (directory, subfolder))
				
		# loop through each file in the connections subfolder
		for filename in os.listdir(arc_path):
			# find the path for each txt file
			path = (r'%s\%s' % (arc_path, filename))
			
			# read arc data from each txt file in the connections subfolder
			node_from, node_to = filename[:-4].split('-')
			time, capacity = np.genfromtxt(path, delimiter = ',', skip_header = (1)).transpose()
			
			# get the node objects and weight for each arc
			weight = np.sum(capacity)/len(time) # the average weight over the number of years
			node_from = self.get_node(node_from)
			node_to = self.get_node(node_to)
			
			# add the arc to the network
			self.join_nodes(node_from, node_to, weight)
		
		
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
