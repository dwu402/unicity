# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
        # create empty node object
		node = Node()
        # assign node name and value
		node.name = name
		node.value = value
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
        # create empty arc object
		arc = Arc()
        # assign arc weight and the nodes the arcs go to/come from
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from
        # append arc to the lists node_from and node_to
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
        # append arc to the list of arcs
		self.arcs.append(arc)

	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			ln = ln.split(",")
            # define source node as first element of string ln and arcs as following elements
			from_node_name = ln[0]
			arcs = ln[1:]

			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name, None)
				
			# get the source node object
			source_node = self.get_node(from_node_name)
            
			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				arc = arc.split(";")
				weight = arc[1]
				to_node_name = arc[0]
                
				# get destination node object and link it to source node
                
                # if node doesn't exist, add to network
				try:
					self.get_node(to_node_name)
				except NetworkError:
					self.add_node(to_node_name, None)
                
                # define the destination node by getting the node to_node_name
				destination_node = self.get_node(to_node_name)
                # join the nodes with the corresponding weight
				self.join_nodes(source_node, destination_node, weight)
						
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------

# creates new class changeDirectory which is used below to change the directory while running code
class changeDirectory:
    """Changes current working directory"""
    def __init__(self, newDirectory):
        # defines the new directory as input
        self.newDirectory = os.path.expanduser(newDirectory)
    
    def __enter__(self):
        # gets the current working directory and saves it as variable savedDirectory
        self.savedDirectory = os.getcwd()
        # changes directory to desired new directory
        os.chdir(self.newDirectory)
    
    def __exit__(self, etype, value, traceback):
        # returns to original saved directory
        os.chdir(self.savedDirectory)

class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
        
        # loops through current directory
		for root, dirs, filenames in os.walk(directory):
            # loops through all subdirectories that aren't called 'connections'
			for d in dirs:
				if d[0:11] != 'connections':
                    # loops through subdirectory d
					for root, dirs, filenames in os.walk(directory + "/" + d):
                        # loops through files in subdirectory d by making the current directory d
						for f in filenames:
							with changeDirectory(directory + "/" + d):
                                # opens file and sets up array to loop through to inspect each line of the file
								fp = open(f, 'r')
								array = [0, 1, 2]
								for a in array:
                                    # takes the next line of the file and splits it at the ': ' saving the value or string following
									ln = fp.readline().strip()
									ln = ln.split(": ")
									array[a] = ln[1]
                                # defines the node name as the first value saved in the array
								node_name = array[0]
                                # defines the node value as the x,y coordinates as integers
								node_value = int(array[1]), int(array[2])
                                # adds node to network
								self.add_node(node_name, node_value)

        # loops through current directory
		for root, dirs, filenames in os.walk(directory):
            # loops through all subdirectories until it finds subdirectory called 'connections'
			for d in dirs:
				if d[0:11] == 'connections':
                    # loops through 'connections' subdirectory
					for root, dirs, filenames in os.walk(directory + "/connections"):
                        # loops through files in subdirectory
						for f in filenames:
                            # first three characters of the filename is the node_from name
							node_from = f[0:3]
                            # fifth to seventh characters of the filename is the node_to name
							node_to = f[4:7]
                            # chnage directory to 'connections' subdirectory
							with changeDirectory(directory + "/connections"):
                                # use genfromtxt function to take capacity values from 2nd column of file
								capacity = np.genfromtxt(f, delimiter=",", skip_header=1, dtype=None, usecols=1)
                                # calculate weight as average of capacity values
								weight = np.sum(capacity)/len(capacity)
                                # define source_node and destination_node by getting respective nodes and join nodes with weight
								source_node = self.get_node(node_from)
								destination_node = self.get_node(node_to)
								self.join_nodes(source_node, destination_node, weight)

	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
