
# Task 1a: File I/O
# In the notes, we saw how text files could be opened, read, and interpreted in terms of data and metadata.
# Research how to use the function np.genfromtxt to read data from 'example_file.txt', returning vectors, xs and Ts. This can be done in a single line.
import numpy as np

# Use genfromtxt function to take the distance and temperature data from columns 0 and 1 repectively as vectors
Xs = np.genfromtxt('example_file.txt', delimiter=",", skip_header=1, dtype=None, usecols=0)
Ts = np.genfromtxt('example_file.txt', delimiter=",", skip_header=1, dtype=None, usecols=1)
# Print the two vectors
print(Xs)
print(Ts)
