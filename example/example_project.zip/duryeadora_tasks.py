# This script uses the np.genfromtxt function to extract two vectors from the 'example_file.txt' file. One vector contains the distance values (in metres) and the other contains the temperature values (in degrees celsius). The function contains 5 parameters specified, the filename, the skip_header which is true (meaning the first line of the text is ignored), the delimeter (i.e a comma) meaning the x and t values are split by a comma, autostrip which is true (meaning white spaces are stripped from the variables) and unpack which is true (meaning the returned array is transposed, making it easier to work with).

import numpy as np

(xs, ts) = np.genfromtxt('example_file.txt', skip_header=1, delimiter=",", autostrip=True, unpack=1)

