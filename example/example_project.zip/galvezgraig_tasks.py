
# Task 1a: File I/O

import numpy as np

#open file
fp = open('example_file.txt','r')

#read data in file
data = np.genfromtxt('example_file.txt', dtype = None, skip_header = 1, delimiter = ',')

#X is column one data, T is column 2 data
X = data[:,0]
T = data[:,1]












