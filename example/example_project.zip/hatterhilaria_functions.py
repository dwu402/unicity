# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob


class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
class Network(object):
	''' Basic network class.
	'''
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
		def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# create an empty node object
		node = Node()
		
		# assign its attributes
		node.name = name
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# create an empty arc object
		arc = Arc()
		
		#assign its attributes
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from
		
		# append arc to the list of arcs coming to and from the nodes
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		
		# append arc to the list of arcs in the network
		self.arcs.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		'''
		
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			
			# split string into source node name and other arcs using split() method for strings
			split_ln = ln.split(',')
			
			# extract source node name (first element in array)
			from_node_name = split_ln[0]
			
			# if source node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			
			# get the source node object for the arc
			source_node = self.get_node(from_node_name)
			
			# initialise an array for the destination;weight pairs
			arcs = []
			# start from the second element of the split_ln array 
			i = 1
			while i < len(split_ln): # loop until the end of the array
				
				arcs.append(split_ln[i]) # add the current element
				i=i+1
				
			# read the information from the pairs and add the arc to the to network
			for arc in arcs:
				# split pairs into destination name and arc weight
				[dest_name,weight] = arc.split(';')
				
				# if destination node doesn't exist, add to network
				try:
					self.get_node(dest_name)
				except NetworkError:
					self.add_node(dest_name)
				
				# get destination node object
				dest_node = self.get_node(dest_name)
				# link it to source node (create the arc)
				self.join_nodes(source_node,dest_node,weight)
				
					
			# get next line
			ln = fp.readline().strip()
			
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		'''
		
		# variable for ease of scanning the directory
		path = directory+os.sep
		
		#find all the files in the directory
		files = glob(path+'*')
		
		# search through all files to find those that are directories and are not the connections folder
		for file in files:             
			if os.path.isdir(file) and file != path+'connections':
				
				# extracting the node name as a string
				name =  np.genfromtxt(file+os.sep+'station_data.txt', dtype = str, delimiter = ": ", usecols = 1, unpack=True, max_rows = 1)
				# extracting the x and y coordinates a floats
				[x,y] = np.genfromtxt(file+os.sep+'station_data.txt', dtype = float, delimiter = ": ", skip_header = 1, usecols = 1, unpack=True)
				
				# adding the node to the network with this information
				self.add_node(name,[x,y])
		
		# now that all the nodes have been set up:
		# iterate through all the files in the connections folder
		con_files = glob(path+'connections'+os.sep+'*')  
		for con_file in con_files:
		
			# removing un-needed information from the file name
			connection = con_file.strip(path+'connections.txt')
			# separating the file name into the from and to node names
			[frm,to] = connection.split('-')
			
			# extracting an array of the capacity across the connection and finding its mean
			cap = np.genfromtxt(con_file, dtype = float, delimiter = ",", skip_header = 1, usecols = 1, unpack=True)
			mean_cap = np.mean(cap)
			
			# getting the to and from node objects
			source_nd = self.get_node(frm)
			dest_nd = self.get_node(to)
			
			# create the arc/connection between the nodes
			self.join_nodes(source_nd,dest_nd,mean_cap)
				
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		

		
		
		
		
		
		
			
