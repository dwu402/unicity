# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		
		# create an empyty node object
		node = Node()
		
		# assign the node a name and value
		node.name = name
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		
		# create an empty arc object
		arc = Arc()
		# assign attributes
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from
		
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		# append arc to arc_in for node_to
		node_to.arcs_in.append(arc)
		# append arc to arc_out for node_from
		node_from.arcs_out.append(arc)
		# append arc to the list of arcs
		self.arcs.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			
			# create an empty list
			arcs = []
			# split the string into the source node name and other arc information
			try: 
				from_node_name, points_to = ln.split(',', 1)
				# split the arc information and append them to the list arcs
				try: # where the arc has two destinations
					points1, points2 = points_to.split(',')
					arcs.append(points1)
					arcs.append(points2)
				except ValueError: # where the arc has one destination
					arcs.append(points_to)
			except ValueError: # where the arc had no destinations
				from_node_name = ln
			
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			source_node = self.get_node(from_node_name)
				
			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				destination, weight = arc.split(';')
				# get destination node object and link it to source node
				
				# if destination node does't exist, add to network
				try:
					self.get_node(destination)
				except NetworkError:
					self.add_node(destination)
				
				# get the destination node object
				destination_node = self.get_node(destination)
				
				#join nodes
				self.join_nodes(source_node, destination_node, weight)
				
						
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		
		# find the files and folders in directory
		files = glob(directory+os.sep+'*')
		
		for file in files:
			if os.path.isdir(file): # if file is a directory
				# find the files and folders in directory
				subfiles = glob(file+os.sep+'*') 
				
				# if file is a node folder get the name and x, y values and create a node
				if len(subfiles) == 1: # node folders will only have 1 subfile and assuming there is more than one connection
					# get the code for the node, and its x and y values for the node position
					file_info = np.genfromtxt(subfiles[0], dtype=str, delimiter =": ", usecols = 1)
					
					node_name = file_info[0]
					# file_info[1] is the x value and file_info[2] is the y value
					node_values = [ float(file_info[1]),float(file_info[2]) ]
					
					# if node doesn't exist, add to network
					try:
						self.get_node(node_name)
					except NetworkError:
						self.add_node(node_name)
					
					# get the node and assign its value
					node = self.get_node(node_name)
					node.value = node_values	
					
				# the connections folder: assuming there are only node folders and connections folders
				else:
					for subfile in subfiles:
						# split subfile into an array containing the names of the folder and the filename
						filename = subfile.split(os.sep)
						# strip '.txt' and split filename[2] to get the names of the connecting nodes
						from_node_name, to_node_name = filename[2].strip('.txt').split('-')
						
						# get the capacity of the connection over the previous 35 years from subfile
						capacity = np.genfromtxt(subfile, dtype="f8", delimiter =",", skip_header = 1, usecols = 1)
						# calculate the mean capacity, this is the weight of the arc
						mean_capacity = sum(capacity) / len(capacity)
						
						# if from and to nodes don't exist, add to network
						try:
							self.get_node(from_node_name)
						except NetworkError:
							self.add_node(from_node_name)
						try:
							self.get_node(to_node_name)
						except NetworkError:
							self.add_node(to_node_name)
						
						# get the connecting nodes
						from_node = self.get_node(from_node_name)
						to_node = self.get_node(to_node_name)
						
						# join the connecting nodes
						self.join_nodes(from_node, to_node, mean_capacity)
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
