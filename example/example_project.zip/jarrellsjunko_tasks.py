# Task 1a: File I/O
# In the notes, we saw how text files could be opened, read, and interpreted in terms of data and metadata.
# Research how to use the function np.genfromtxt to read data from 'example_file.txt', returning vectors, xs and Ts. This can be done in a single line.
import numpy as np

#inputs to the function np.genfromtxt are:
# the file name : 'example_file.txt'
# the delimiter=',' to seperate the text when ',' is found
# skip_header=1 to not get the headers of the text file
# unpack=True so that the returned array is tranposed


Xs, Ts = np.genfromtxt('example_file.txt', delimiter=',' , skip_header=1, unpack=True )

