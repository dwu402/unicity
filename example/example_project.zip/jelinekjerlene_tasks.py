# -*- coding: utf-8 -*-

import numpy as np
[Xs,Ts]=np.genfromtxt('example_file.txt', delimiter=",", skip_header=1, unpack=1) #use np.genfromtxt to assign 2 columns to 2 vectors
