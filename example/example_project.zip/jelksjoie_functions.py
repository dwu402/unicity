# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# Create New Node 
		node = Node()
		# Assign name to node
		node.name = name
		# Assign value to node
		node.value = value		
		# Append node to the list of nodes in the network
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# Join nodes with an arc 
		# Create Arc
		arc = Arc()
		# Assign arc weight
		arc.weight= weight
		# Assign destination node
		arc.to_node = node_to
		# Assign source node 
		arc.from_node = node_from
		# Append arc to the network
		self.arcs.append(arc)
		# Append arc to node_to.arc_in 
		node_to.arcs_in.append(arc)
		# Append arc to node_from.arcs_out
		node_from.arcs_out.append(arc)

	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''	
		# Open the file
		fp = open(filename, 'r')
		# Get the first line from the file
		ln = fp.readline().strip()
		while ln is not '':        # Keep looping to the end of the file
			# Split string into source node name and other arcs using split() method for strings and element assignment
			line_info = ln.split(",")
			arcs = line_info[1:]
			source_node = line_info[0]
			
			# If node doesn't exist, add to network 
			try:
				self.get_node(source_node)
			except NetworkError:
				self.add_node(source_node)
				
			# Read the arc information and add to network. Repeat for all values in the array using for loop 
			for arc in arcs:
				# Parse arc information, splitting into destination node and arc weights
				node_to,weight = arc.split(";")
				
				#If destination node doesn't exist, add to the network
				try:
					self.get_node(node_to)
				except NetworkError:
					self.add_node(node_to)
				
				# Get source and destination node objects, link to source node using join_nodes
				self.join_nodes(self.get_node(source_node),self.get_node(node_to),weight)
					
			# Get next line
			ln = fp.readline().strip()
			
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		# Import package for wildcards to select files and folders
		from glob import glob
		
		# Create arcs array. Elements are the paths to the arc information text files in the connections folder
		arcs = glob(directory + os.sep + 'connections' + os.sep + '*')
		# Create nodes array. Elements are the paths to the station data text file for each station
		nodes = glob(directory + os.sep +'*'+ os.sep + 'station_data.txt')
			
		# Create a for loop to run through all, read station_data.text and record node values in the network
		# Begin for loop, one iteration per element of the nodes array
		for node in nodes:
			# Create empty node
			node_name = []
			# Create empty x co-ordinate array
			x_co_ord = []
			# Create empty y co-ordinate array
			y_co_ord = []
			# Open the text file, specified by the path indicated by the node 
			fp = open(node,'r')
			# Use readline(), strip() and replace() to get node title
			node_name = fp.readline().strip()
			node_name = node_name.replace('code: ','')
			# Use the np.genfromtext function to extract the x and y coordinates from the file
			x_co_ord,y_co_ord = np.genfromtxt(node, unpack = 1, usecols = 1, delimiter = ' ',autostrip = True,skip_header =1 )
			# Add the node object to the network and set node value to the X and Y co-ordinates 
			node_name = self.add_node(node_name,value= [x_co_ord,y_co_ord])
			
		# Create a for loop to run through all connection sub directories. Note: We don't need to test for nodes present.		
		for arc in arcs: 
			# Read File name to get source and destination nodes for the arc by extracting the basename of path directory
			file = os.path.basename(arc)
			# Remove the .txt from the file name
			file = file.replace('.txt','')
			# Find the source and destination node in the file name to join the nodes via an arc 
			nodes_S_D = file.split("-")
			node_from = nodes_S_D[0]
			node_to = nodes_S_D[1]
			# Open the directory using the path name
			fp = open(arc,'r')
			# Extract the arc weights from the directory
			capacities = np.genfromtxt(arc, unpack = 1, usecols = 1, delimiter = ',',autostrip = True,skip_header =1 )
			# Get the mean value for the capacities to the array using np.mean
			capacity = np.mean(capacities)
			# Create an arc to use on the map using the source node and destination node and the weight. 
			self.join_nodes(self.get_node(node_from),self.get_node(node_to),capacity)
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
