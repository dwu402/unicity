
# Task 1a: File I/O
# In the notes, we saw how text files could be opened, read, and interpreted in terms of data and metadata.
# Research how to use the function np.genfromtxt to read data from 'example_file.txt', returning vectors, xs and Ts. This can be done in a single line.
# Import numpy package
import numpy as np
# Extract distance and temperature values from the text file, storing both seperately 
xs, Ts = np.genfromtxt('example_file.txt', skip_header=1, unpack = 1, delimiter=',')





