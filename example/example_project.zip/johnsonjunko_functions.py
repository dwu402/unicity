import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		conn.wgt = weight
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':		
			x = ln.split(",")
			from_stat_name = x[0]
			conns = x[1:]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			origin_stat = self.query_station(from_stat_name)
			for conn in conns:
				conn = conn.split(";")
				try:
					self.query_station(conn[0])
				except GridError:
					self.add_station(conn[0])
				stat_to = self.query_station(conn[0])
				weight = conn[1]
				self.add_connection(origin_stat, stat_to, weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		files = glob(directory+os.sep+'*'+os.sep+'info.txt')
		for file in files:
			row_1,row_2 = np.genfromtxt(file,dtype = 'str', skip_header= 0,delimiter=" ",unpack = True)
			stat = row_2[0]
			x_coordinate = int(row_2[1])
			y_coordinate = int(row_2[2])
			try:
				self.query_station(stat)
			except GridError:
				self.add_station(stat,value = [x_coordinate,y_coordinate])
		texts = glob(directory+os.sep+'backbone'+os.sep+'*')
		for text in texts:
			row_1,row_2 = np.genfromtxt(text, skip_header= 1,delimiter=",",unpack = True)
			weight = np.mean(row_2)
			split_1 = text.split("\\")
			split_2 = split_1[2].split(".")
			stations = split_2[0].split("-")
			self.add_connection(self.query_station(stations[0]), self.query_station(stations[1]), weight)
