# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

    
# these classes are complete, do not modify them
class Node(object):
    def __init__(self):
        self.name = None
        self.value = None
        self.arcs_in = []
        self.arcs_out = []
class Arc(object):
    def __init__(self):
        self.weight= None
        self.to_node = None
        self.from_node = None
class NetworkError(Exception):
    '''An error to raise when violations occur.
    '''
    pass
        
    
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
    
    # these methods are complete, do not modify them
    def __init__(self):
        self.nodes = []
        self.arcs = []
    def get_node(self, name):
        ''' Loops through the list of nodes and returns the one with NAME.
        
            Returns NetworkError if node does not exist.
        '''
        # loop through list of nodes until node found
        for node in self.nodes:
            if node.name == name:
                return node
        
        raise NetworkError
    def display(self):
        ''' Print information about the network.
        '''
        # print nodes
        print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
        # print arcs
        for arc in self.arcs:
            print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
    
    # **these methods are incomplete, you must complete them as part of the lab task**
    def add_node(self, name, value=None):
        '''Adds a Node with NAME and VALUE to the network.
        '''
        # **to do: create an empty node object, assign its attributes**
        # **hint: how are empty network objects created in lab5_task1.py?**
        # **hint: how are names and values assigned in the __init__ method for node?**
        
        #This creates an empty node object 
        node = Node()
        
        #here we assign different classes to the node
        node.name = name
        node.value = value
        # append node to the list of nodes
        self.nodes.append(node)
        
    def join_nodes(self, node_from, node_to, weight):
        '''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
        '''
        # **to do: create an empty arc object, assign its attributes**
        # **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
        
        #this creates an empty arc object 
        arc = Arc()
        
        #here we assign different classes to the arc
        arc.weight = weight
        arc.from_node = node_from
        arc.to_node = node_to
        
        #append the arc to the list of arcs
        self.arcs.append(arc)
        
        #assign each arc to connect two different nodes in a certain direction and append this info to the list of arcs
        node_from.arcs_out.append(arc)
        node_to.arcs_in.append(arc)
    
    def read_network(self, filename):
        '''Read data from FILENAME and construct the network.
        
            Each line of FILENAME contains
             - the name of an origin node (first entry)
             - and destination;weight pairs (each pair separated by a comma)
             
        '''
        # **to do**
        # **hint: inspect 'network.txt' so that you understand the file structure**
        # **hint: each source-destination pair needs to be joined
        
        # **some useful (incomplete) code snippets**
        # ln.split
        #
        # 
        
        # open the file
        fp = open(filename, 'r')
        
        # get first line
        ln = fp.readline().strip()
        while ln is not '':        # keep looping to the end of the file
            # split string into source node name and other arcs using split() method for strings

            #checking if the line has more than the source node in it
            try: 
                from_node_name, arcs = ln.split(",",1) #checking if there are arcs found in the line being read
                arcs = arcs.split(",")  #seperate the arcs in the filename 
            except:
                from_node_name = ln     #if the node name is equal to the line i.e. only thing on the line being read
                arcs = []   #there are no arcs to add to the list
            
            # if node doesn't exist, add to network
            try:
                self.get_node(from_node_name) #if the node already exists then it will be added to the list 
            except NetworkError:
                self.add_node(from_node_name)   #if the node does not exist then it will be added to the list 
                
            # get the source node object
            source = self.get_node(from_node_name)  #define the source node from the from_node_name variable
            
            # read the arc information and add to network
            for arc in arcs:
                # parse arc information
                arc = arc.split(";")    #split the arc name and arc weight which is seperated by a semi-colon
                
                # get destination node object and link it to source node
                try:
                    self.get_node(arc[0]) #check if the node has already been added to the list 
                except:
                    self.add_node(arc[0]) #check if the node has not already beeen added to the list 
                    target = self.get_node(arc[0]) #add the node to the list 
                self.join_nodes(source, target, arc[1]) #join the source and target nodes along with the arc weight 
                

            # get next line
            ln = fp.readline().strip()
        
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
    ''' Derived Network class, for NZ networks.
    '''    
    # **this method is incomplete, you must complete it as part of the lab task**
    def read_network(self, directory):
        ''' Read network information from DIRECTORY
        
            Notes:
            ------
            Assume that DIRECTORY contains one folder for 
            connections between nodes. All other folders define
            the nodes of the network. 
            
            Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
            node) and x and y values for the node position.
            
            In the connections folder, there is a file for each connection.
            The name of the file indicates which two nodes are connected 
            (from-to) and the contents of the file record the capacity of 
            the connection over the previous 35 years. The connection weight
            is the mean capacity.
        '''
        
        # **some useful functions**
        # glob
        # np.genfromtxt
        # os.path.isdir
        
        #list all files in the current directory 
        files = glob("nz_network" + os.sep + "*")   #finds files and folders matching the string with '*' meaning "any text"
                    
        for file in files:  #for each tem in the list
            if os.path.isdir(file): #read folders
                # is used for connections as it is the only folder with multiple folders inside it
                if file != "nz_network/connections" and file != "pycache": #this is looped for files and connections
                    fp = open(file + os.sep + "station_data.txt", "r")  #this opens the station_data.txt file
                    
                    ln = fp.readline().strip()
                    #split the line into substings with ": "
                    temp_splt = ln.split(": ")
                    station_name = temp_splt[1]
                    
                    
                    #Get x co-ord by reading the next line of station_data.txt
                    ln = fp.readline().strip()
                    
                    #split the line into substrings with ": "
                    x_splt = ln.split(": ")
                    x_coord = int(x_splt[1]) #place x co-ord into a specific variable and convert it from s string to an integer
                    
                    #Get y co-ord by reading the next line of station_data.txt
                    ln = fp.readline().strip()
                    
                    #split the line into substrings with ": "
                    y_splt = ln.split(": ")
                    y_coord = int(y_splt[1]) #place y co-ord into a specific variable and convert it from a string to an integer 
                    
                    
                    #create a vector containing the x and y co-ords
                    xy = [x_coord, y_coord]
                    
                    #create a node using the station name and the co-ords of the station 
                    self.add_node(station_name, xy)
                    
        #list all the files in the connections folder
        files = glob("nz_network" + os.sep + "connections" + os.sep + "*")
        
        #for each item on the list 
        for file in files:
            s = file.split(os.sep) #to remove the seperators ("/") from the filename
            txtFileName = s[2] #to remove the "nz_networks" and "connections" from the filename
            txtFileName = txtFileName.strip(".txt") #to remove the ".txt" from the filename 
            array = txtFileName.split("-") #to split the two nodes from the filename and place in seperate elements of an array
            from_node = self.get_node(array[0]) #use the first element of the array as the source node
            node_to = self.get_node(array[1])   #use the second element of the array as the destination node
            
            #open the file for the connection                       
            fp = open(file)
            
            #create a vector of the time and the capacity of the arc from the file
            [time, capacity] = np.genfromtxt(file, delimiter = ", ", skip_header = 1, unpack = 1)
            #calculate the mean capacity of the arc using the np.meean function
            mean_capacity = np.mean(capacity)
            
            #Join the two nodes by creating an arc with a weight equal to the mean capacity 
            self.join_nodes(from_node, node_to, mean_capacity)
            
            
    # this method is complete, do not modify    
    def show(self, save=None):
        ''' Plot the network and optionally save to file SAVE
        '''
        # create figure axes
        fig=plt.figure()
        fig.set_size_inches([10,10])
        ax=plt.axes()
        
        # NZ coastline as background
        img=mpimg.imread('bg.png')
        ax.imshow(img,zorder=1)
    
        # a filthy hack to get coordinates in the right spot...
        for node in self.nodes:
            x,y = node.value
            y = int((y+10)*1.06)
            x -= int(50*y/800.)
            node.value = [x,y]
    
        # draw nodes as text boxes with station names
            # bounding box properties
        props = dict(boxstyle='round', facecolor='white', alpha=1.0)
        for node in self.nodes:
            # extract coordinates
            x,y = node.value
            ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
            
        # draw connections as lines
        weights = [arc.weight for arc in self.arcs]
            # scale for plotting connections
        wmin = np.min(weights)
        wmax = np.max(weights)
        lmin,lmax = [0.5, 10.0]
        
        # plot connections
        for arc in self.arcs:
            # compute line length, scales with connection size
            lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
            x1,y1 = arc.from_node.value
            x2,y2 = arc.to_node.value
            ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
    
        # remove ticks
        ax.set_xticks([])
        ax.set_yticks([])
    
        # display options
        if save:
            # save to file
            plt.savefig(save, dpi=300)
            plt.close()
        else:
            # open figure window in screen
            plt.show()
    
    
        
        
        
        
        
        
        
        
        
            
