#Import NumPy package to allow use of array objects
import numpy as np

#create a vector of distance and temperature by reading the data out of "example_file.txt" using genfromtxt
#while skipping the header line and seperating the distance and temp value using ", "
[Xs, Ts] = np.genfromtxt('example_file.txt', delimiter = ", ", skip_header = 1, unpack = 1)