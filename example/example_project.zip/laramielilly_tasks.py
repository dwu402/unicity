
# Task 1a: File I/O
# In the notes, we saw how text files could be opened, read, and interpreted in terms of data and metadata.
# Research how to use the function np.genfromtxt to read data from 'example_file.txt', returning vectors, xs and Ts. This can be done in a single line.
import numpy as np

# alternate:
# xs, Ts = np.genfromtxt('example_file.txt', delimiter=',', skip_header=True).transpose()
xs, Ts = np.genfromtxt('example_file.txt', delimiter=',', skip_header=True, unpack=True)