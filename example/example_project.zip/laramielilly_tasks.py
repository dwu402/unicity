import numpy as np
xs, Ts = np.genfromtxt('example_file.txt', delimiter=',', skip_header=True, unpack=True)
