import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		stat.cons_in = []
		stat.cons_out = []
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		conn.wgt = weight
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			ln = ln.split(',')
			from_stat_name = ln[0]
			conns = ln[1:]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			from_stat = self.query_station(from_stat_name)
			for conn in conns:
				to_stat_name,weight = conn.split(';')
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				to_stat = self.query_station(to_stat_name)
				self.add_connection(from_stat,to_stat,weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		files = glob('roads_grid')
		for file in files:
			if os.path.isdir(file):
				subfiles = glob(file+os.sep+'*')
				for subfile in subfiles:
					if os.path.isdir(subfile):
						stat_txts = glob(subfile+os.sep+'*')
						for stat_txt in stat_txts:
							if subfile != 'roads_grid\connections':
								fp = open(stat_txt,'r')
								ln = fp.readline().strip()
								title, stat_name = ln.split(':')
								stat_name = stat_name.lstrip(' ')
								ln = fp.readline().strip()
								title, x = ln.split(':')
								ln = fp.readline().strip()
								title, y = ln.split(':')
								value = [int(x),int(y)]
								fp.close()
								self.add_station(stat_name, value)
				subfiles = glob(file+os.sep+'backbone')
				for subfile in subfiles:
					if os.path.isdir(subfile):
						conn_txts = glob(subfile+os.sep+'*')
						for conn_txt in conn_txts:
							name = ('  '+conn_txt.split(os.sep)[-1])
							name,extension = name.split('.')
							stat_from_name,stat_to_name = name.split('-')
							tTemp,cTemp = np.genfromtxt(conn_txt, delimiter=',', unpack=True, skip_header=1)
							weight = (sum(cTemp)/(tTemp[-1] - tTemp[0]))
							stat_from_name = stat_from_name.lstrip(' ')
							stat_to_name = stat_to_name.lstrip(' ')
							stat_from = self.query_station(stat_from_name)
							stat_to = self.query_station(stat_to_name)
							self.add_connection(stat_from,stat_to,weight)
