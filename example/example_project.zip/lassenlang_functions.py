import os
import re
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat=Station()
		stat.id=name
		stat.val=value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn=Connection()
		conn.to_stat=stat_to
		conn.from_stat=stat_from
		conn.wgt=weight
		self.connections.append(conn)
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':		
			info=ln.split(',')
			from_stat_name=info[0]
			conns=info[1:]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			origin=self.query_station(from_stat_name)
			for conn in conns:
				conn_info=conn.split(';')
				stat_dest=conn_info[0]
				stat_weight=float(conn_info[1])
				try:
					self.query_station(stat_dest)
				except GridError:
					stat = self.add_station(stat_dest)
				stat_to=self.query_station(stat_dest)
				self.add_connection(origin,stat_to,stat_weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		stationdatas = glob(directory+os.sep+'*'+os.sep+'info.txt')
		for stationdata in stationdatas:
			fp = open(stationdata,'r')
			ln = fp.readline()
			ln = ln.strip()
			code,stat_name = ln.split(' ')
			ln = fp.readline()
			axis_x,x = ln.split(':')
			ln = fp.readline()
			axis_y,y = ln.split(':')
			x = int(x)
			y = int(y)
			try:
				self.query_station(stat_name)
			except GridError:
				stat = self.add_station(stat_name, value = [x,y])
			fp.close()
		connectiondatas=glob(directory+os.sep+'backbone'+os.sep+'*')
		for connectiondata in connectiondatas:
			fp = open(connectiondata,'r')
			hdr = fp.readline()
			ln = fp.readline()
			weight = []
			while ln != '':
				ln = ln.strip()
				t,w = ln.split(',')
				weight.append(float(w))
				ln = fp.readline()
			weight = np.mean(weight)
			fp.close
			locations = connectiondata.split('-')
			scan = locations[0]
			source_name = scan.split('\\')
			from_stat_name = source_name[2]
			scan = locations[1]
			dest_name = scan.split('.')
			to_stat_name = dest_name[0]
			self.add_connection(self.query_station(from_stat_name), self.query_station(to_stat_name), weight)
