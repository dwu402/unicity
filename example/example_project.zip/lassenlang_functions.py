# imports
import os
import re
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#				 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
			Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		node=Node()
		node.name=name
		node.value=value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		arc=Arc()
		arc.to_node=node_to
		arc.from_node=node_from
		arc.weight=weight
		
		self.arcs.append(arc)
		
		node_to.arcs_in.append(arc)
		node_from.arcs_out.append(arc)
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':		# keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			info=ln.split(',')
			#postion 0 in the array should contain the source node name
			from_node_name=info[0]
			#the other postions hold the destination nodes and the arc weight
			arcs=info[1:]

			
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			origin=self.get_node(from_node_name)
				
			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				#spliting the arc info into destination and arc weight 
				arc_info=arc.split(';')
				
				#the node destination will be in the first postion in the array
				node_dest=arc_info[0]
				#weights will be in the second postion
				node_weight=float(arc_info[1])
				
				# checking if the node exists, and creating one if it doesnt
				try:
					self.get_node(node_dest)
				except NetworkError:
					node = self.add_node(node_dest)
				
				# get destination node object and link it to source node
				node_to=self.get_node(node_dest)
				self.join_nodes(origin,node_to,node_weight)
						
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#				 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		#getting all the station data and storing it
		stationdatas = glob(directory+os.sep+'*'+os.sep+'station_data.txt')
		#looping through all the station datas and extracting the useful infomation
		for stationdata in stationdatas:
			#opening the txt file
			fp = open(stationdata,'r')
			#reading the first line
			ln = fp.readline()
			#stripping the end lin
			ln = ln.strip()
			#extracting code(useless) and the node name using split
			code,node_name = ln.split(' ')
			#reading the line which holds the x coordinates
			ln = fp.readline()
			#splitting into the axis(useless) and the coordinate value
			axis_x,x = ln.split(':')
			#reading the line which holds the y coordinates
			ln = fp.readline()
			#splitting into the axis(useless) and the coordinate value
			axis_y,y = ln.split(':')
			
			#converting the value from str into int
			x = int(x)
			y = int(y)
			#create node at the coordinates
			try:
				self.get_node(node_name)
			except NetworkError:
				node = self.add_node(node_name, value = [x,y])
			#close file
			fp.close()
		#globbing to get all the connection data	
		connectiondatas=glob(directory+os.sep+'connections'+os.sep+'*')	
		#running a loop to extract the useful info
		for connectiondata in connectiondatas:
			#opening the connection txt file
			fp = open(connectiondata,'r')
			#removing the header
			hdr = fp.readline()
			#reading the first useful line
			ln = fp.readline()
			#forming an empty array to be populates
			weight = []
			#running through all the arc weights and finding the mean 
			while ln != '':
				#stripping the end line
				ln = ln.strip()
				#splitting into two, only the w is useful
				t,w = ln.split(',')
				#adding to the weight array float types
				weight.append(float(w))
				#reading next line
				ln = fp.readline()
			#calculating the mean of the array
			weight = np.mean(weight)
			#close file
			fp.close
			#spliting the data from glob into the node names
			locations = connectiondata.split('-')
			#taking the source node name from the split data
			scan = locations[0]
			#splitting the data so that one postion in the array contains only
			#the source name
			source_name = scan.split('\\')
			#extracting the source name
			from_node_name = source_name[2]
			#taking the destination node name from the split data	
			scan = locations[1]
			#splitting the data so the fisrt postin in the array hold only the
			#destination name
			dest_name = scan.split('.')
			#obtaining the dest name
			to_node_name = dest_name[0]
			#joing the nodes with the acrs  
			self.join_nodes(self.get_node(from_node_name), self.get_node(to_node_name), weight)
			
			
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
