import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		self.add_station('name', value)
		stat.id = name
		stat.val = value
		___
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt= weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		___
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			ln.split(",")
			ln.split(";")
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			stat_source = ln[0]
			for conn in conns:
				stat_wgt = ln[3]
				stat_wgt2 = ln[5]
				stat_dest = ln[2]
				stat_dest2 = ln[4]
				join_stat(self, stat_source, stat_dest, stat_wgt)
				join_stat(self, stat_source, stat_dest2, stat_wgt2)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		connections = glob(directory + '\\connections\\*')
		stations = glob(directory + '\\*\\info.txt')
		if os.path.isdir(directory) == True
			files = glob('station_data')
			i=0
			for i<= length(files)
				data.filei= np.genfromtxt('files[i]', usecols=(1), dtype = str)
				data.filei.split(" ")
				add_station(Roads, data[0], None)
				i = i+1
			return
			files2 = glob('-')
			j=0
			for j<= length(files2)
				data.filej= np.genfromtxt('files2[j]', dtype = float)
				join_stat(Roads, data[0], None)
				j = j+1
			return
		else print("directory does not exist")
		return
		___
