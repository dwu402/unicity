import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt= weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			conns = ln.split(',')
			from_stat_name = conns[0]
			conns.remove(from_stat_name)
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			from_stat = self.query_station(from_stat_name)
			for conn in conns:
				to_stat_name, weight = conn.split(';')
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				to_stat = self.query_station(to_stat_name)
				self.add_connection(from_stat, to_stat, int(weight))
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		if os.path.isdir(directory):
			os.chdir(directory)
			for folder in glob('*'):
				if folder == 'backbone':
					os.chdir('backbone')
					for file in glob('*'):
						time, capacity = np.genfromtxt(file, delimiter = ',', skip_header = 1, unpack = True, dtype='float')
						capacity = np.mean(capacity)
						stat1_name, stat2_name = file.split('-')
						stat2_name = stat2_name[0:3]
						try:
							self.query_station(stat1_name)
						except GridError:
							self.add_station(stat1_name)
						try:
							self.query_station(stat2_name)
						except GridError:
							self.add_station(stat2_name)
						stat1 = self.query_station(stat1_name)
						stat2 = self.query_station(stat2_name)
						self.add_connection(stat1, stat2, capacity)
					os.chdir('..')
				else:
					os.chdir(folder)
					fid = open('info.txt', 'r')
					ln = fid.readline().strip()
					code = ln.split(': ')[1]
					ln = fid.readline().strip()
					x = ln.split(': ')[1]
					ln = fid.readline().strip()
					y = ln.split(': ')[1]
					fid.close()
					try:
						self.query_station(code)
					except GridError:
						self.add_station(code)
					stat = self.query_station(code)
					stat.val = [int(x),int(y)]
					os.chdir('..')
			os.chdir('..')
