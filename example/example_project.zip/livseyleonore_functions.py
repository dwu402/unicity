

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
	
		node = Node()
		node.name = name  
		node.value = value
		
	# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		
		arc = Arc()
		arc.from_node = node_from
		arc.to_node = node_to  
		arc.weight = weight
		
		self.arcs.append(arc)
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		
	def read_network(self, filename):
					
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			try: 
				from_node_name, arcs = ln.split(',',1) # splits source node and arcs
				arcs =arcs.split(',') # splits arcs up
			except:
				from_node_name = ln
				arcs=[]
			
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except:
				self.add_node(from_node_name)
				
			# get the source node object
			source_node = self.get_node(from_node_name)
				
			# read the arc information and add to network
			for arc in arcs:
				# split arc information
				arc = arc.split(';')
				# get targer node object and link it to source node			
				try: 
					self.get_node(arc[0])
				except: 
					self.add_node(arc[0])				
					target_node = self.get_node(arc[0])				
				self.join_nodes(source_node,target_node,arc[1])
						
			# get next line
			ln = fp.readline().strip()
			
class NetworkNZ(Network):
	def read_network(self, directory):
	
		# gives access to all files and folders in the current directory
		files = glob('nz_network' + os.sep + '*')	# finds all files and folders 
	
		# loop through the list, if a folder is encountered, print its name and list the folders contents
		for file in files:		# for each item in the list
			if os.path.isdir(file):    	# checks if the file exists
				
				# open all folders except the connections and __pycache__ folder
				if file != "nz_network\\connections" and file != "nz_network\\__pycache__": 
					
					# opens station_data file
					fp = open(file + os.sep + "station_data.txt",'r')
					
					# extract node name
					ln = fp.readline().strip()
					temp_split = ln.split(' ')
					code = temp_split[1]
					
					# extract x value
					ln = fp.readline().strip()
					x_split = ln.split(' ')
					x_value = int(x_split[1])

					# extract y value	
					ln = fp.readline().strip()
					y_split = ln.split(' ')
					y_value = int(y_split[1])
				
					# store in array
					array = [x_value, y_value]
					
					# add node
					self.add_node(code, array)
					fp.close() # close file
	
		# glob the connections folder
		files = glob('nz_network' + os.sep + 'connections' + os.sep + '*')
		
		# loop through connections files 
		for file in files:
			splt = file.split('\\',1) # remove 'nz_network'
			splt0 = splt[1].split('\\') # remove 'connections'
			splt1 = splt0[1]. split('.') # remove '.txt'
			splt2 = splt1[0].split('-') # seperate source and target nodes
			source_node = splt2[0]
			target_node = splt2[1]	
			
			# gets node object
			from_node = self.get_node(source_node)
			to_node = self.get_node(target_node)	
			
			#extract the arc weigths and average them
			Time, capacity_array = np.genfromtxt(file, delimiter = ',',skip_header=1, unpack = 1)
			weight = np.mean(capacity_array, dtype=np.float64)
			
			# add in the arcs
			self.join_nodes(from_node, to_node, weight)
					
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
