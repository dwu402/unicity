import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat=Station()
		stat.id=name
		stat.val=value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn=Connection()
		conn.to_stat=stat_to
		conn.from_stat=stat_from
		conn.wgt=weight
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			sName=ln.split(',')[0]
			conns=ln.split(',')[1:]
			try:
				self.query_station(sName)
			except GridError:
				self.add_station(sName)
			self.query_station(sName)
			for conn in conns:
				dStation=conn.split(';')[0]
				aWeight=conn.split(';')[1]
			try:
				self.query_station(dStation)
			except GridError:
				self.add_station(dStation)
				self.add_connection(self.query_station(sName), self.query_station(dStation), aWeight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		os.chdir('roads_grid')
		folders=glob('*')
