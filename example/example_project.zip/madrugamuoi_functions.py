# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# Create a new node assign the structure Node
		new_node = Node()
		
		# Assign values to the components name and value of the structure Node given from inputs
		new_node.name = name
		new_node.value = value

		# append node to the list of nodes in the network
		self.nodes.append(new_node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		
		# Create a new arc with the structure Arc
		new_Arc = Arc()
		
		# Assign values to the components from the given inputs
		new_Arc.weight = weight
		new_Arc.to_node = node_to
		new_Arc.from_node = node_from
		
		# Append the arc to the list of arcs in the network
		self.arcs.append(new_Arc)
		
		# Appen the arc to the list of arcs out for the node its leaving
		node_from.arcs_out.append(new_Arc)
		# Appen the arc to the list of arcs in for the node its going to
		node_to.arcs_in.append(new_Arc)
		
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			ln = ln.split(',')
			from_node_name = ln[0]
			# Stores info about arcs leaving the from node
			arcs = ln[1:]
			
			# if from node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object		
			from_node = self.get_node(from_node_name)
			
			
			
			# Read the arc information and add to network using a for loop
				
			# read the arc information individually and split into the to node and arc weight
			for arc in arcs:
				arcdata = arc.split(';')
				net_to_node = arcdata[0]
				arcweight = int(arcdata[1])
				
				# if to node doesn't exist, add to network
				try:
					self.get_node(net_to_node)
				except NetworkError:
					self.add_node(net_to_node)
					
				# get the to node object
				to_node = self.get_node(net_to_node)
				
				# Join nodes and create arc, appending both to their appropriate lists
				self.join_nodes(from_node, to_node, arcweight)
				
				# get destination node object and link it to source node
						
			# get next line
			ln = fp.readline().strip()
			
			
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# Get Directory of foler and find directory of nz_network folder
		dir = os.getcwd()
		contents = glob(dir+os.sep+'nz_network'+os.sep+'*')
		
		# Loop through all paths (in this case folders) in the nz_network directory
		# Loop through folder paths and for folders which aren't the connections folder establish all network nodes
		for content in contents:
			if content != dir+os.sep+'nz_network'+os.sep+'connections':
				# Find path of station data text file
				path = content+os.sep+'station_data.txt'
				# Open and read in first line
				fp = open(path,'r')
				# Discard the "code: " preceding the node name, resulting in the Name
				ln = fp.readline().strip()
				Name = ln.replace("code: ","")
				
				# Read in next line, again stripping the beginning "x: " to be left with x value and convert to integer
				ln = fp.readline().strip()
				x = int(ln.replace("x: ",""))
				
				# Repeat x process above for y to get the y value
				ln = fp.readline().strip()
				y = int(ln.replace("y: ",""))
				
				# Add node to network
				self.add_node(Name, [x,y])
				
		# Loop through connections folder to create all arcs (note all nodes already exist)	
		# Establish directory of connection folder and create array of all file paths inside it
		pathconnect = dir+os.sep+'nz_network'+os.sep+'connections'
		connectarc = glob(pathconnect+os.sep+'*')
		# Loop through all node arc data files to find, to nodes, from node and arc weights 
		for arc in connectarc:
			# Read in arc data text file and formulate arrays of time and capacity with floating point numbers
			[Time, Capacity] = np.genfromtxt(arc, dtype="float64", delimiter=",", skip_header=1, unpack=1)
			# Find the mean of the capacity array to find arc weight
			weight = np.mean(Capacity)
			
			# Remove all unnecessary info on the path name to be left with a string in the form 'node-node'
			NodeNames = arc.replace(pathconnect+os.sep,"")
			NodeNames = NodeNames.replace(".txt","")
			# Split the 'node-node' (in form From-To) string into the individual nodes
			Nodes = NodeNames.split("-")

			# Retrieve node information (noting that all nodes will already exist)	
			FromNode = self.get_node(Nodes[0])
			ToNode = self.get_node(Nodes[1])
			
			# Join nodes and create the arc
			self.join_nodes(FromNode, ToNode, weight)
					
			
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
