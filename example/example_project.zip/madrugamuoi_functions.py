import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		new_stat = Station()
		new_stat.id = name
		new_stat.val = value
		self.stations.append(new_stat)
	def add_connection(self, stat_from, stat_to, weight):
		new_Connection = Connection()
		new_Connection.wgt = weight
		new_Connection.to_stat = stat_to
		new_Connection.from_stat = stat_from
		self.connections.append(new_Connection)
		stat_from.cons_out.append(new_Connection)
		stat_to.cons_in.append(new_Connection)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			ln = ln.split(',')
			from_stat_name = ln[0]
			conns = ln[1:]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			from_stat = self.query_station(from_stat_name)
			for conn in conns:
				conndata = conn.split(';')
				net_to_stat = conndata[0]
				connweight = int(conndata[1])
				try:
					self.query_station(net_to_stat)
				except GridError:
					self.add_station(net_to_stat)
				to_stat = self.query_station(net_to_stat)
				self.add_connection(from_stat, to_stat, connweight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		dir = os.getcwd()
		contents = glob(dir+os.sep+'roads_grid'+os.sep+'*')
		for content in contents:
			if content != dir+os.sep+'roads_grid'+os.sep+'backbone':
				path = content+os.sep+'info.txt'
				fp = open(path,'r')
				ln = fp.readline().strip()
				Name = ln.replace("code: ","")
				ln = fp.readline().strip()
				x = int(ln.replace("x: ",""))
				ln = fp.readline().strip()
				y = int(ln.replace("y: ",""))
				self.add_station(Name, [x,y])
		pathconnect = dir+os.sep+'roads_grid'+os.sep+'backbone'
		connectconn = glob(pathconnect+os.sep+'*')
		for conn in connectconn:
			[Time, Capacity] = np.genfromtxt(conn, dtype="float64", delimiter=",", skip_header=1, unpack=1)
			weight = np.mean(Capacity)
			StationNames = conn.replace(pathconnect+os.sep,"")
			StationNames = StationNames.replace(".txt","")
			Stations = StationNames.split("-")
			FromStation = self.query_station(Stations[0])
			ToStation = self.query_station(Stations[1])
			self.add_connection(FromStation, ToStation, weight)
