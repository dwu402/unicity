import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		conn.wgt = weight
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			line = ln.split(",")
			from_stat_name = line[0]
			linkedConnections = line [1:]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source_stat = self.query_station(from_stat_name)
			if not(linkedConnections == None):
				for a in linkedConnections:
					connData = a.split(";")
					try:
						self.query_station(connData[0])
					except:
						self.add_station(connData[0])
					to_stat = self.query_station(connData[0])
					self.add_connection(source_stat,to_stat,connData[1])
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		for name in glob(directory + os.sep + '*' +os.sep + 'info.txt'):
			title, value = np.genfromtxt(name, unpack = True, dtype= str)
			code = value[0]
			coordx = value[1]
			coordx = int(str(coordx))
			coordy = value[2]
			coordy = int(str(coordy))
			statVal = [coordx, coordy]
			self.add_station(code,statVal)
		for name in glob(directory + os.sep + 'backbone' + os.sep + '*'):
			fileName = name.split(os.sep)
			fileNameA = fileName[2]
			fileNameB = fileNameA.split(".")
			fileNameC = fileNameB[0]
			statA, statB = fileNameC.split("-")
			A = self.query_station(statA)
			B = self.query_station(statB)
			time, capacity = np.genfromtxt(name,skip_header = 1, delimiter = ",", unpack = True, dtype = float)
			connWeight = np.mean(capacity)
			self.add_connection(A, B, connWeight)
