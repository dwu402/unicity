import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to;
		conn.from_stat = stat_from;
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			from_stat_name = ln.split(',')[0]
			conns = ln.split(',')[1:]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source_stat = self.query_station(from_stat_name)
			for conn in conns:
				to_stat_name, conn_weight = conn.split(';')
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				destination_stat = self.query_station(to_stat_name)
				self.add_connection(source_stat, destination_stat, conn_weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		for name in glob(directory + '/*/info.txt'):
			stat_name, x, y = np.genfromtxt(name, dtype = 'str', delimiter = ': ', unpack = True, usecols = 1)
			coordinates = [int(x), int(y)]
			try:
				self.query_station(stat_name)
			except GridError:
				self.add_station(stat_name, coordinates)
		for name in glob(directory + '/connections/*'):
			filename = os.path.basename(name)
			stations = filename.split('.')[0]
			from_stat_name, to_stat_name = stations.split('-')
			weight_data = np.genfromtxt(name, delimiter = ',', skip_header = 1, unpack = True, usecols = 1)
			weight = sum(weight_data)/(len(weight_data))
			from_stat = self.query_station(from_stat_name)
			to_stat = self.query_station(to_stat_name)
			self.add_connection(from_stat, to_stat, weight)
