import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		conn.wgt = weight
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			line = ln.split(",")
			line2 = line[1:];
			print(line)
			print(line2)
			source = line[0]
			try:
				self.query_station(source)
			except GridError:
				self.add_station(source)
			source_stat = self.query_station(source)
			if not(line2 == None):
				for i in line2:
					info = i.split(";")
					print(info)
					try:
						self.query_station(info[0])
					except:
						self.add_station(info[0])
					to_stat = self.query_station(info[0])
					self.add_connection(source_stat, to_stat, float(info[1]))
				ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		from glob import glob
		roads_grid_folder_names = glob(directory + os.sep + '*' + os.sep + 'info.txt')
		for file in roads_grid_folder_names:
			metadata, data = np.genfromtxt(file, dtype = str, delimiter = ': ', unpack = True)
			self.add_station(data[0], [int(data[1]), int(data[2])])
			stat = self.query_station(data[0])
		connection_file_names = glob(directory + os.sep + "connections" + os.sep + '*.txt')
		for i in connection_file_names:
			a,b,c = i.split(os.sep) 
			c_without_txt, w = c.split('.') 
			from_stat, to_stat = c_without_txt.split("-") 
			years, capacity = np.genfromtxt(i, dtype = float, skip_header = 1, delimiter = '', unpack = True)
			weight = np.mean(np.array(capacity))
			self.add_connection(self.query_station(from_stat), self.query_station(to_stat), weight)
