import numpy as np
xs, Ts = np.genfromtxt('data.txt', delimiter = ',', skip_header = 1, unpack = 1)
