import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt = None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			data = ln.split(",")
			from_stat_name = data[0]
			conns = data[1:]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			from_stat_name = self.query_station(from_stat_name)
			for conn in conns:
				to_stat_name, weight = conn.split(";")
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				to_stat_name = self.query_station(to_stat_name)
				self.add_connection(from_stat_name, to_stat_name, weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		files = glob(directory+'/*')
		for file in files:
			subfiles = glob(file+os.sep+'*')
			if len(subfiles)==1:    
				station_data = subfiles[0]
				fp = open(station_data, 'r')
				ln = fp.readline().strip()
				n, from_stat_name = ln.split(" ")
				ln = fp.readline().strip()
				n, x = ln.split(" ")
				x = int(x)
				ln = fp.readline().strip()
				n, y = ln.split(" ")
				y = int(y)
				value = [x,y]
				try:
					self.query_station(from_stat_name)
				except GridError:
					self.add_station(from_stat_name, value)
		subfiles = glob(directory+'\connections/*')
		for file in subfiles: 
			filename = file.strip('roads_grid\\connections\\*.txt')
			from_stat_name, to_stat_name = filename.split("-")
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			try:
				self.query_station(to_stat_name)
			except GridError:
				self.add_station(to_stat_name)
			from_stat_name = self.query_station(from_stat_name)
			to_stat_name = self.query_station(to_stat_name)
			fp = open(file, 'r')
			Times, Capacities = np.genfromtxt(file, skip_header = 1, delimiter = ",", unpack= True)
			weight = sum(Capacities)/len(Capacities)
			self.add_connection(from_stat_name, to_stat_name, weight)
