import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()                
		stat.id = name
		stat.val = value       
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()            
		conn.from_stat = stat_from
		conn.to_stat =stat_to
		conn.wgt = weight              
		stat_from.cons_out.append(conn)   
		stat_to.cons_in.append(conn)      
		self.connections.append(conn)            
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':
			ln = ln.split(',')       
			from_stat_name = ln[0]
			conns = ln[1:]            
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source = self.query_station(from_stat_name)
			for conn in conns:
				if conn != '':         
					conn_weight = int(conn[2])      
					try:
						self.query_station(conn[0])
					except GridError:
						self.add_station(conn[0]) 
					destination = self.query_station(conn[0])
					self.add_connection(source,destination,conn_weight) 
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		stat_files = glob(os.path.join(directory,'*','info.txt')) 
		for file in stat_files:  
			data = np.genfromtxt(file,delimiter =':',dtype= str)   
			code = data[0][1].strip()    
			x_value = float(data[1][1])
			y_value = float(data[2][1])
			self.add_station(code,(x_value,y_value))  
		conn_files = glob(os.path.join(directory,'backbone','*.txt') ) 
		for file in conn_files:
			position = file.rfind('-')                
			from_stat = self.query_station(file[position-3:position])
			to_stat = self.query_station(file[position+1:position+4])
			conn_capacity = np.genfromtxt(file,delimiter =',',dtype = float,skip_header = 1,usecols = 1)
			weight = np.mean(conn_capacity)   
			self.add_connection(from_stat,to_stat,weight)  
