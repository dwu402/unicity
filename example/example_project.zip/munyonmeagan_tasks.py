import numpy as np

Xs,Ts =np.genfromtxt('example_file.txt',delimiter = ',',skip_header = 1,unpack=True)

#',' as th delimiter to separate the cols.
# skip_header = 1 to skip reading the first row
# unpack = True to store data in two separate variable 
