import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.val = value
		stat.id = name
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			if len(ln) > 1:
				from_stat_name,pairs = ln.split(',',1)
				conns = pairs.split(',')
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source_stat = self.query_station(from_stat_name)
			for conn in conns:
				stat_to_name, conn_weight = conn.split(';')
				try:
					self.query_station(stat_to_name)
				except GridError:
					self.add_station(stat_to_name)
				stat_to = self.query_station(stat_to_name)
				self.add_connection(source_stat, stat_to, conn_weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		if os.path.isdir(directory):
			folders = glob(directory+os.sep+'*')
			for folder in folders:
				files = glob(folder+os.sep+'*')
				if len(files) == 1:
					fp = open(files[0],'r')
					meta, stat_value = np.genfromtxt(files[0], dtype='f8', delimiter=": ", skip_header = 1,unpack=1)
					ln = fp.readline()
					meta, ln  = ln.split(' ',1)
					stat_name = ln.strip()
					self.add_station(stat_name,stat_value)
					fp.close()
			files = glob(directory+os.sep+'backbone'+os.sep+'*')
			for file in files:
				first_half,second_half = file.split('-',1)
				stat_from = first_half[-3:]
				stat_to = second_half[:3]
				fp = open(file,'r')
				meta,values = np.genfromtxt(file, dtype='f8', delimiter=",", skip_header = 1,unpack=1)
				conn_weight = (values.sum())/(len(values))
				stat_from = self.query_station(stat_from)
				stat_to = self.query_station(stat_to)
				self.add_connection(stat_from, stat_to, conn_weight)
