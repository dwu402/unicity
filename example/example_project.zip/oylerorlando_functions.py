import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		stat.cons_in = []
		stat.cons_out = []
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		try:
			self.query_station(stat_to)
		except GridError:
			self.add_station(stat_to)
		destination_stat = self.query_station(stat_to)
		destination_stat.cons_in.append(conn)
		conn.to_stat = destination_stat
		try:
			self.query_station(stat_from)
		except GridError:
			self.add_station(stat_from)
		origin_stat = self.query_station(stat_from)
		origin_stat.cons_out.append(conn)
		conn.from_stat = origin_stat
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			lnlist = ln.split(',', 2)
			from_stat_name = lnlist[0]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			srcstat = self.query_station(from_stat_name)
			conn1 = Connection()
			conn2 = Connection()
			conns = (conn1, conn2)
			for conn in conns:
				conn.stat_from = lnlist[0]
				if conn == conns[0] and len(lnlist) >= 2:
					conninfo = lnlist[1].split(';', 1)
					try:
						self.query_station(conninfo[0])
					except GridError:
						self.add_station(conninfo[0])
					deststat = self.query_station(conninfo[0])
					conn.stat_to = conninfo[0]
					conn.wgt = conninfo[1]
					deststat.cons_in.append(conn)
					srcstat.cons_out.append(conn)
				elif len(lnlist) == 3:
					conninfo = lnlist[2].split(';', 1)
					try:
						self.query_station(conninfo[0])
					except GridError:
						self.add_station(conninfo[0])
					deststat = self.query_station(conninfo[0])
					conn.stat_to = conninfo[0]
					conn.wgt = conninfo[1]
					deststat.cons_in.append(conn)
					srcstat.cons_out.append(conn)
				ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		import glob
		files = glob.glob('*/*/info.txt')
		for file in files:
			import numpy as np
			headings, info = np.genfromtxt(file, dtype='U', delimiter=': ', unpack=1)
			self.add_station(info[0], (info[1], info[2]))
			stat = Roads.query_station(self, info[0])
			x,y = stat.val
			x = int(x)
			y = int(y)
			stat.val = [x,y]
		import glob
		connections = glob.glob('*\connections\*.txt')
		for connection in connections:
			import os
			pathinfo = os.path.split(connection)
			filename = pathinfo[1]
			filenamelist = filename.split('.', 1) 
			stations = filenamelist[0].split('-', 1) 
			From = stations[0] 
			to = stations[1] 
			time, capacity = np.genfromtxt(connection, dtype='f', skip_header=1, delimiter=",", unpack=1)
			sumCapacity = sum(capacity)
			numberOfYears = len(capacity)
			weight = sumCapacity/numberOfYears
			self.add_connection(From, to, weight)
			stat = self.query_station(From)
