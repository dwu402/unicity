#Task 1a.
#This script opens a text file called 'example_file.txt', reads it and then returns the vectors xs and Ts
import numpy as np
xs, Ts = np.genfromtxt("example_file.txt", skip_header=1, delimiter=",", unpack=1) 
#Print the vectors
print("Ts = ",Ts)
print("xs = ",xs)