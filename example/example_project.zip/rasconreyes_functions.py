# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		
		#Create an empty node object
		node = Node()
		
		#Assign its attributes
		node.name = name
		node.value = value
		
		#Append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		
		#Create an empty arc object
		arc = Arc()
		
		#Assign its attributes
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from
		
		#Modify the arc attributes of each node
		node_to.arcs_in.append(arc)
		node_from.arcs_out.append(arc)
		
		#Append arc to the list of arcs
		self.arcs.append(arc)
		
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		#Open the file
		fp = open(filename, 'r')
		
		#Get first line
		ln = fp.readline().strip()
		
		#Keep looping until it gets to the end of the file
		while ln is not '':
		
			#Split line into the source, and destination/weight pairs
			line = ln.split(',')
			
			#Create empty lists
			sdw=[]
			arcs=[]
			destinationNodes=[]
			
			#Create a list of source and desination\weight pairs
			for i in range(len(line)):
				sdw.append((line[i]).split(';'))
				
			    #If the node doesn't exist, add it to the network
				try:
					self.get_node(sdw[i][0])
				except NetworkError:
					self.add_node(sdw[i][0])
			
			#Create list of arcs
			for j in range(1,len(line)):
				arcs.append(sdw[j][1])
				
			#Get the source node object
			source = (sdw[0][0])
			sourceNode = self.get_node(source)
			
			#Create list of destination nodes
			for k in range(1, len(line)):
				destinationNodes.append(sdw[k][0])
		
			
			for l in range(len(arcs)):
			
					#Get destination node object 
					destinationNode = self.get_node(destinationNodes[l])
					
					#Link source and destination nodes
					self.join_nodes(sourceNode, destinationNode, arcs[l])
					
			#Get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		#Get all folders in the directory
		folders = glob(directory+os.sep+'*')
		
		#Loop through each folder in the directory
		for folder in folders:
			#If the folder is a directory 
			if os.path.isdir(folder):
				#Special case for the connections folder
				if folder == directory+os.sep+'connections':
					#Get all the files in the connections folder
					connection_files = glob(folder+os.sep+'*')
					#Loop through each of these files
					for file in connection_files:
						#Open the file
						fp = open(file, 'r')
						
						#Using the split method get the source and destination node names from the txt file names
						sd = file.split(os.sep)
						dt = sd[2].split('-')
						from_node = dt[0]
						tn = dt[1].split('.txt')
						to_node = tn[0]
						
						#If nodes do not exist, add them to the network
						try:
							self.get_node(from_node)
						except NetworkError:
							self.add_node(from_node)
							
						try:	
							self.get_node(to_node)
						except NetworkError:
							self.add_node(to_node)
						
						#Get source and destination node objects
						source_node = self.get_node(from_node)
						destination_node = self.get_node(to_node)
						
						#Read the second column of each file to get an array of all the capacity values
						capacity = np.genfromtxt(file, delimiter = ',', unpack = True, usecols = 1, skip_header = True)
						#Find the mean of the capacity array (which becomes the arc weight)
						weight = np.mean(capacity)
						
						#Link source and destination nodes
						self.join_nodes(source_node, destination_node, weight)
				
				#For all other folders not named 'connections'
				else:
					#Get all the node information files
					nodes = glob(folder+os.sep+'*')
					node = nodes[0]
					
					#Open the file
					fp = open(node, 'r')
					
					#Read in information from the txt files about the x and y values
					xandy = np.genfromtxt(node, delimiter = ': ', skip_header=1, usecols = 1, unpack = True)
					x = xandy[0]
					y = xandy[1]
					
					#Get the header information which contain the code used to name the nodes
					ln = fp.readline()
					ln = ln.strip()
					xs,code = ln.split(': ')
				
					#If node does not exist, add it to the network
					try:
						self.get_node(code)
					except NetworkError:
						self.add_node(code)
					
					#Get node object
					node = self.get_node(code)
					#Assign its values
					node.value = [x, y]
						
					
										
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
