import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':
			line = ln.split(',')
			sdw=[]
			conns=[]
			destinationStations=[]
			for i in range(len(line)):
				sdw.append((line[i]).split(';'))
				try:
					self.query_station(sdw[i][0])
				except GridError:
					self.add_station(sdw[i][0])
			for j in range(1,len(line)):
				conns.append(sdw[j][1])
			source = (sdw[0][0])
			sourceStation = self.query_station(source)
			for k in range(1, len(line)):
				destinationStations.append(sdw[k][0])
			for l in range(len(conns)):
					destinationStation = self.query_station(destinationStations[l])
					self.add_connection(sourceStation, destinationStation, conns[l])
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		folders = glob(directory+os.sep+'*')
		for folder in folders:
			if os.path.isdir(folder):
				if folder == directory+os.sep+'backbone':
					connection_files = glob(folder+os.sep+'*')
					for file in connection_files:
						fp = open(file, 'r')
						sd = file.split(os.sep)
						dt = sd[2].split('-')
						from_stat = dt[0]
						tn = dt[1].split('.txt')
						to_stat = tn[0]
						try:
							self.query_station(from_stat)
						except GridError:
							self.add_station(from_stat)
						try:
							self.query_station(to_stat)
						except GridError:
							self.add_station(to_stat)
						source_stat = self.query_station(from_stat)
						destination_stat = self.query_station(to_stat)
						capacity = np.genfromtxt(file, delimiter = ',', unpack = True, usecols = 1, skip_header = True)
						weight = np.mean(capacity)
						self.add_connection(source_stat, destination_stat, weight)
				else:
					stations = glob(folder+os.sep+'*')
					stat = stations[0]
					fp = open(stat, 'r')
					xandy = np.genfromtxt(stat, delimiter = ': ', skip_header=1, usecols = 1, unpack = True)
					x = xandy[0]
					y = xandy[1]
					ln = fp.readline()
					ln = ln.strip()
					xs,code = ln.split(': ')
					try:
						self.query_station(code)
					except GridError:
						self.add_station(code)
					stat = self.query_station(code)
					stat.val = [x, y]
