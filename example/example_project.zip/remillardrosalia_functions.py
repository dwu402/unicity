import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		self.connections.append(conn)
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			try:
				stat_name,conns = ln.split(',',1)
				conns = conns.split(',')
			except:
				stat_name=ln
				conns=[]
			try:
				self.query_station(stat_name)
			except GridError:
				self.add_station(stat_name)
			source_stat = self.query_station(stat_name)
			for conn in conns:
				to_stat,weight= conn.split(';')
				try:
					destination_stat_1 = self.query_station(to_stat)
				except GridError:
					self.add_station(to_stat)
				destination_stat_2 = self.query_station(to_stat)
				self.add_connection(source_stat,destination_stat_2,weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		files = glob(directory+os.sep+'*')
		for file in files:
			if os.path.isdir(file) and os.path.basename(file) != ('backbone'): 
				stat_name,x_value,y_value =  np.genfromtxt(file+os.sep+'info.txt',dtype = (str),delimiter = ': ', usecols=1,unpack=True)
				self.add_station(stat_name,[int(x_value),int(y_value)])
		files = glob(directory+os.sep+'backbone'+os.sep+'*')
		for file in files:
			conn_name=os.path.basename(file)
			conn_name=conn_name.rstrip('.txt')
			from_stat,to_stat=conn_name.split('-')
			from_stat=self.query_station(from_stat)
			to_stat=self.query_station(to_stat)
			weight= np.genfromtxt(file,skip_header=1,usecols=1)
			weight= np.sum(weight)/len(weight)
			self.add_connection(from_stat,to_stat,weight)
