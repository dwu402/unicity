import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		conn.wgt = weight
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			try:
				src_stat_name, conns = ln.split(',' , 1)
				conns = conns.split(',')
			except ValueError:
				src_stat_name = ln
				conns = []
			try:
				self.query_station(src_stat_name)
			except GridError:
				self.add_station(src_stat_name)
			src_stat = self.query_station(src_stat_name)
			for conn in conns:
				dest_stat_name, weight = conn.split(';')
				weight = int(weight)
				try:
					self.query_station(dest_stat_name)
				except GridError:
					self.add_station(dest_stat_name)
				dest_stat = self.query_station(dest_stat_name)
				self.add_connection(src_stat, dest_stat, weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		folders = glob(directory+os.sep+'*')
		for folder in folders:
			if len(glob(folder+os.sep+'*')) == 1 or folder.split(os.sep)[-1] != 'backbone':
				stat_name, stat_x, stat_y = np.genfromtxt(folder+os.sep+'info.txt', delimiter = ': ', dtype = str, usecols = (1))
				stat_x = float(stat_x)
				stat_y = float(stat_y)
				self.add_station(stat_name, (stat_x, stat_y))
			else:
				connections_folder = folder
		connections = glob(connections_folder+os.sep+'*')
		for connection in connections:
				capacity = np.genfromtxt(connection, unpack = 1, delimiter = ',', skip_header = 1, usecols = (1))
				weight = sum(capacity) / len(capacity)
				src_stat_name, dest_stat_name = (connection.split(os.sep)[-1]).strip('.txt').split('-')
				src_stat = self.query_station(src_stat_name)
				dest_stat = self.query_station(dest_stat_name)
				self.add_connection(src_stat, dest_stat, weight)
