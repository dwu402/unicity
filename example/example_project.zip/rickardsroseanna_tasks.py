import numpy as np
xS, Ts = np.genfromtxt("example_file.txt", skip_header=1, unpack = 1, delimiter = ",")
