import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			conns = ln.split(",")
			from_stat_name = conns[0]
			del conns[0]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			from_stat = self.query_station(from_stat_name)
			for conn in conns:
				data = conn.split(";")
				to_stat_name = data[0]
				weight = float(data[1])
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				to_stat = self.query_station(to_stat_name)
				self.add_connection(from_stat,to_stat,weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		if os.path.isdir(directory):
			files = glob(directory+"/*")
			for file in files:
				if os.path.exists(file+"\info.txt"):
					name,data = np.genfromtxt(file+"\info.txt",delimiter=": ",unpack=True,dtype=str)
					self.add_station(data[0])
					stat = self.query_station(data[0])
					stat.val = float(data[1]),float(data[2])
			if os.path.exists(directory+"\connections"):
				connections = glob(directory+"\connections\*")
				for connection in connections:
					head,tail = os.path.split(connection)
					curstations = tail.split(".")[0].split("-")
					from_stat = self.query_station(curstations[0])
					to_stat = self.query_station(curstations[1])
					_,capacity = np.genfromtxt(connection,delimiter=", ",unpack=True,skip_header=1)
					sum = 0
					for v in capacity:
						sum += v
					weight = sum/len(capacity)
					self.add_connection(from_stat,to_stat,weight)
