import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt=weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			conns = ln.split(',')
			from_stat_name = conns[0]
			conns.remove(conns[0])
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			ndSource = self.query_station(from_stat_name)
			for conn in conns:
				dest, weight = conn.split(';')
				weight = float(weight)
				try:
					self.query_station(dest)
				except GridError:
					self.add_station(dest)
				ndDestination = self.query_station(dest)
				self.add_connection(ndSource, ndDestination, weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		owd = os.getcwd()
		os.chdir(directory)
		station_data_files = glob('*\\info.txt')
		for station_data in station_data_files:
			info = np.genfromtxt(station_data, delimiter = ':', usecols = (1), dtype = str, autostrip = True)
			name = info[0]
			coordinate = [float(info[1]), float(info[2])]
			self.add_station(name, coordinate)
		connnection_data_files = glob('connections\\*.txt')
		for connection_data in connnection_data_files:
			file = os.path.basename(connection_data)
			connection = os.path.splitext(file)[0]
			nameFrom, nameTo = connection.split('-')
			ndFrom = self.query_station(nameFrom)
			ndTo = self.query_station(nameTo)
			capacity = np.genfromtxt(connection_data, skip_header = 1, delimiter = ',', usecols = (1))
			weight = np.mean(capacity)
			self.add_connection(ndFrom, ndTo, weight)
		os.chdir(owd)
