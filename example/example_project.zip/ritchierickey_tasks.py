#imports
import numpy as np

#Generates vectors Xs and Ts containing the column of distances and column of temperatures respectively
Xs = np.genfromtxt('example_file.txt', skip_header = 1, delimiter = ',', usecols = (0))
Ts = np.genfromtxt('example_file.txt', skip_header = 1, delimiter = ',', usecols = (1))