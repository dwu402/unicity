import numpy as np
Xs = np.genfromtxt('example_file.txt', skip_header = 1, delimiter = ',', usecols = (0))
Ts = np.genfromtxt('example_file.txt', skip_header = 1, delimiter = ',', usecols = (1))
