import numpy as np
Xs = np.genfromtxt('data.txt', skip_header = 1, delimiter = ',', usecols = (0))
Ts = np.genfromtxt('data.txt', skip_header = 1, delimiter = ',', usecols = (1))
