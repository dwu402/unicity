# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
				
		#creating an empty node object
		node = Node()
		
		#assigning the name and value of the node
		node.name = name
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		
		# creating an empty arc object
		arc = Arc()
		
		# assigning the from_node, to_node and weight of the arc
		arc.from_node = node_from
		arc.to_node = node_to
		arc.weight = weight
		
		#appending the arc to the appropriate list in the node objects
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		
		#append arc to the list of arcs
		self.arcs.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
		
			# the from_node_name is the first part of the line from the txt file
			from_node_name = ln.split(',')[0]
			
			#the arc/s information is in the second part of the line from the txt file so we remove the first part
			arcs = ln.split(',')
			del arcs[0]
			
			# if from_node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# read the arc information and add to network
			for arc in arcs:
				#separate the to_node_name and the weight of the arc
				to_node_name, weight = arc.split(';')
				
				# if to_node doesn't exist, add to network
				try:
					self.get_node(to_node_name)
				except NetworkError:
					self.add_node(to_node_name)
				
				# get and then connect the from_node to the to_node with an arc
				startNode = self.get_node(from_node_name)
				endNode = self.get_node(to_node_name)
				self.join_nodes(startNode,endNode,weight)
				
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# retrieve the information for each node in the network by looping through station_data.txt files
		for name in glob(directory+'/*/station_data.txt'):
		
			# extract the name of the node(code) and its coordinates(xcord, ycord)
			code, xcord, ycord = np.genfromtxt(name, dtype=str, delimiter=': ', usecols = 1, unpack = True)
			# store the xcord and ycord together in a list as int values
			cord = [int(xcord),int(ycord)]
			
			# if node doesn't exist, add to network
			try:
				self.get_node(code)
			except NetworkError:
				self.add_node(code, cord)
				
		# loop through txt files in the connections folder for arc information
		for name in glob(directory+'/connections/*'):
			# retrieve the to and from node names from the file name
			file=os.path.basename(name)
			nodes = file.split('.')[0]
			fromNode, toNode = nodes.split('-')
			# retrieve the weight information from over the years and get the average for the weight of the arc
			weightarray = np.genfromtxt(name, delimiter=',', skip_header = 1, usecols = 1, unpack = True)
			weight = sum(weightarray)/len(weightarray)
			
			# get and then connect the from_node to the to_node with an arc
			departure = self.get_node(fromNode)
			arrival = self.get_node(toNode)
			self.join_nodes(departure,arrival,weight)
			
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
