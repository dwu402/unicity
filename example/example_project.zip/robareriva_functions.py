# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		
		#Create an empty node
		node = Node()
		
		#Assign the new node's attributes to given inputs
		node.name = name
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		
		#Create an empty arc
		arc = Arc()
		#Assign the new arc's attributes to given inputs
		arc.from_node = node_from
		arc.to_node = node_to
		arc.weight = weight
		
		# append arcs to the list of arcs
		self.arcs.append(arc)
		
		# Append the newly formed arc to the corresponding arc list of the node the arc is leaving from and 
		# the node it is going to
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			split_info = ln.split(',')
			
			# Finding out the length of the the string which has been split to ensure we do not try and 
			# obtain values outside the range, ie if len(split.info)=2 and you try arcs = [split_info[1],split_info[2]]
			# Then we obtain the from_node_name (ie the source node) and the arc information
			if len(split_info) == 3:
				from_node_name = split_info[0]
				arcs = [split_info[1],split_info[2]]
			elif len(split_info) == 2:
				from_node_name = split_info[0]
				arcs = [split_info[1]]
			else:
				break
				
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			
			nd1 = self.get_node(from_node_name)
				
			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				to_node_name,weight = arc.split(';')
				
				#if destination node doesn't exist, add to network
				try:
					self.get_node(to_node_name)
				except NetworkError:
					self.add_node(to_node_name)
				
				# get destination node object and link it to source node
				nd2 = self.get_node(to_node_name)
				self.join_nodes(nd1,nd2,weight)
						
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		
		#Checking to ensure that current working directory contains the directory folder
		if os.path.isdir(directory) == True:
			#Set the input directory as the current working directory (ie in this case setting current working
			#directory as the path of 'nz_network'
			os.chdir(directory)
			
			#Obtain a list of all the subfolders in the directory
			subfolders = glob('*')
			
			# Switching connection folder with last folder, to ensure we can loop through and add all the nodes
			# before we attempt to join the nodes
			subfolders[1],subfolders[19] = subfolders[19],subfolders[1]
			
			#Loop through subfolders but not including the connections
			for file in subfolders[:19]:
				#Enter the subfolder and set as current working directory
				os.chdir(file)
				#using function numpy.genfromtxt obtain the data in the text file which are :node name,
				#x coordinate and y coordinate
				stationdata= np.genfromtxt('station_data.txt',dtype = str, delimiter = ': ', usecols=1)
				#Returning to previous director to access the other subfolders now
				os.chdir('..')
				
				#Converting the string numbers to integers
				x_point = int(stationdata[1])
				y_point = int(stationdata[2])
				
				#Creating a node and adding it to the network
				value = (x_point,y_point)
				name = stationdata[0]
				
				self.add_node(name,value)
			
			
			
			#Setting the connections folder as current working directory and obtaining a list of all the text
			# files in the folder
			os.chdir('connections')
			connections = glob('*')
			
			#Loop through textfiles in connections and joining the nodes as stated in each file
			for connection in connections:
				
				#Obtaining the source node and destination node name from text file name
				source_destination = connection.split('.')[0].split('-')
				source_code = source_destination[0]
				destination_code = source_destination[1]
				
				#Obtaining all the data on capacity using numpy.genfromtxt, giving as an array of values
				# and finding the mean_capapcity which is the weight of the arc
				capacity = np.genfromtxt(connection, delimiter = ',',usecols = 1,skip_header=1)
				mean_capacity = np.mean(capacity)
				
				#Using the join_nodes method to join the two nodes
				nd1 = self.get_node(source_code)
				nd2 = self.get_node(destination_code)
				self.join_nodes(nd1,nd2,mean_capacity)
			#Returning to the initial working directory (which should be lab5 folder containing bg.png)			
			os.chdir('..')
			os.chdir('..')
		
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
