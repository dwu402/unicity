import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		conn.wgt = weight
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			split_info = ln.split(',')
			if len(split_info) == 3:
				from_stat_name = split_info[0]
				conns = [split_info[1],split_info[2]]
			elif len(split_info) == 2:
				from_stat_name = split_info[0]
				conns = [split_info[1]]
			else:
				break
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			nd1 = self.query_station(from_stat_name)
			for conn in conns:
				to_stat_name,weight = conn.split(';')
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				nd2 = self.query_station(to_stat_name)
				self.add_connection(nd1,nd2,weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		if os.path.isdir(directory) == True:
			os.chdir(directory)
			subfolders = glob('*')
			subfolders[1],subfolders[19] = subfolders[19],subfolders[1]
			for file in subfolders[:19]:
				os.chdir(file)
				stationdata= np.genfromtxt('info.txt',dtype = str, delimiter = ': ', usecols=1)
				os.chdir('..')
				x_point = int(stationdata[1])
				y_point = int(stationdata[2])
				value = (x_point,y_point)
				name = stationdata[0]
				self.add_station(name,value)
			os.chdir('backbone')
			connections = glob('*')
			for connection in connections:
				source_destination = connection.split('.')[0].split('-')
				source_code = source_destination[0]
				destination_code = source_destination[1]
				capacity = np.genfromtxt(connection, delimiter = ',',usecols = 1,skip_header=1)
				mean_capacity = np.mean(capacity)
				nd1 = self.query_station(source_code)
				nd2 = self.query_station(destination_code)
				self.add_connection(nd1,nd2,mean_capacity)
			os.chdir('..')
			os.chdir('..')
