import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
from os.path import isdir
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id= name
		stat.val= value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			line =ln.split(",")
			from_stat_name = line[0]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source_stat = self.query_station(from_stat_name)
			for connection in line[1:]:
				[to_stat_name, weight] = connection.split(";")
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				to_stat= self.query_station(to_stat_name)
				self.add_connection(source_stat, to_stat , float(weight))
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		from glob import glob
		from statistics import mean
		station_folders = glob(directory + os.sep + '*' + os.sep + 'info.txt')
		connection_info = glob(directory + os.sep + 'backbone' + os.sep + '*')
		for folders in station_folders:
			[ignore_names,info]=np.genfromtxt("%s" %folders, dtype = str, delimiter =":", unpack = 1)
			station_code= info[0]
			[ignore_names,info]=np.genfromtxt("%s" %folders, delimiter =":", unpack = 1)
			station_stat = Station()
			station_stat.val =[info[1],info[2]]
			station_stat.id = station_code.strip() 
			try:
				self.query_station(station_stat.id)
			except GridError:
				self.add_station(station_stat.id , station_stat.val)
		for files in connection_info:
			[years, data]=np.genfromtxt("%s" %files, delimiter =",", unpack = 1 , skip_header=1)
			mean_conn_value = mean(data)
			filename = files
			from_stat_name = filename[-11:-8]
			to_stat_name = filename[-7:-4]
			self.add_connection(self.query_station(from_stat_name), self.query_station(to_stat_name) , mean_conn_value)
