
import numpy as np
#create two vectors Xs and Ts containing the data from example_file.txt
[Xs , Ts] = np.genfromtxt("example_file.txt" , delimiter="," , skip_header=1  , unpack=True)
