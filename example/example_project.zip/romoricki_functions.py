import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			conns = ln.split(',')
			from_stat_name = conns[0]
			del conns[0]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			for conn in conns:
				to_stat_name, weight = conn.split(';')
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				self.add_connection(self.query_station(from_stat_name), self.query_station(to_stat_name), weight)
			ln = fp.readline().strip()
		fp.close()
class Roads(Grid):
	def read(self, directory):
		files = set(glob(directory+os.sep+'*')) - set(glob(directory+os.sep+'backbone'))
		for file in files:
			fp = open(file+os.sep+'info.txt', 'r')
			ln = fp.readline(). strip()
			name = ln.replace('code: ', '')
			lnx = fp.readline().strip()
			x = lnx.replace('x: ', '')
			lny = fp.readline().strip()
			y = lny.replace('y: ', '')
			stat_value = int(x),int(y)
			self.add_station(name, value = stat_value)
			fp.close()
		files = glob(directory+os.sep+'backbone'+os.sep+'*')
		for file in files:
			stat_names = file.replace(directory+os.sep+'backbone'+os.sep, '')
			from_stat_name, to_stat_name = stat_names.split('-')
			to_stat_name = to_stat_name.replace('.txt', '')
			fp = open(file, 'r')
			time, capacity = np.genfromtxt(file, delimiter=',', skip_header=1, unpack=1)
			total_capacity = sum(capacity)
			mean_capacity = total_capacity/len(capacity)
			self.add_connection(self.query_station(from_stat_name), self.query_station(to_stat_name), mean_capacity)
			fp.close()
