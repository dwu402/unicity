import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
    def __init__(self):
        self.id = None
        self.val = None
        self.cons_in = []
        self.cons_out = []
class Connection(object):
    def __init__(self):
        self.wgt=None
        self.to_stat = None
        self.from_stat = None
class GridError(Exception):
    pass
class Grid(object):
    def __init__(self):
        self.stations = []
        self.connections = []
    def query_station(self, name):
        for stat in self.stations:
            if stat.id == name:
                return stat
        raise GridError
    def add_station(self, name, value=None):
        stat = Station()
        stat.id = name
        stat.val = value
        self.stations.append(stat)
    def add_connection(self, stat_from, stat_to, weight):
        conn = Connection()                         
        conn.wgt = weight                 
        conn.to_stat = stat_to
        conn.from_stat = stat_from
        stat_to.cons_in.append(conn)         
        stat_from.cons_out.append(conn)
        self.connections.append(conn)
    def read(self, filename):
        fp = open(filename, 'r')
        ln = fp.readline().strip()
        while ln is not '':        
            iteration = ln.count(',')           
            temps = []
            temps = ln.split(',')               
            name = temps[0]
            stat = Station()
            stat.id = name
            try:
                self.query_station(temps[0])
            except GridError:
                self.add_station(temps[0])
            stat = self.query_station(temps[0])
            for x in range(1, iteration + 1 ):                  
                stat_to, weight = temps[x].split(';')           
                name2 = stat_to
                stat_to = Station()
                stat_to.id = name2
                self.add_connection(stat, stat_to, weight)          
            ln = fp.readline().strip()
class Roads(Grid):
    def read(self, directory):
        from glob import glob
        import os
        check = os.path.isdir(directory)                                    
        if check is True:
            folders = glob(directory + os.sep + '*')                        
            for folder in folders:
                if folder != 'roads_grid' + os.sep + 'backbone':     
                   statfolder = glob(folder + os.sep + '*')
                   fid = open(statfolder[0], 'r')                           
                   ln = fid.readline().strip()
                   bin, name = ln.split(": ")                               
                   ln = fid.readline().strip()
                   bin, x = ln.split(": ")
                   x = int(x)
                   ln = fid.readline().strip()
                   bin, y = ln.split(": ")
                   y = int(y)
                   self.add_station(name,[x, y])                               
            connection_lists = glob(directory + os.sep + 'backbone' + os.sep + '*')
            for connection in connection_lists:                            
                year, cap = np.loadtxt(connection, skiprows = 1, unpack = True, delimiter = ', ', dtype = None)
                avgcap = np.average(cap)                                    
                filename, ext = os.path.splitext(connection)                
                stat_from_directory, stat_to = filename.split('-')         
                directory, directory, stat_from = stat_from_directory.split('\\')
                self.add_connection(self.query_station(stat_from), self.query_station(stat_to), avgcap)
