# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		
		# check that the node does not exist in the network
		node_names = [all_node.name for all_node in self.nodes]
		if name in node_names:
			raise NetworkError
		
		# create an empty node
		node = Node()
		# assign its attributes
		node.name = name
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		
		# create an empty arc
		arc = Arc()
		# assign its attributes
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from
		
		# append arc to the list of arcs of the network as well as the in/out arcs of other nodes
		self.arcs.append(arc)
		node_to.arcs_in.append(arc)
		node_from.arcs_out.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			ln = ln.split(',',1)
			from_node_name = ln[0]
			try:
				arcs = ln[1]
				arcs = arcs.split(',')
			except:
				arcs = ()

			
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			from_node = self.get_node(from_node_name)
				
			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				to_node_name = arc[0]
				arc_weight = arc[2]
				
				# get destination node object and link it to source node
				
				# if to node doesn't exist, add to network
				try:
					self.get_node(to_node_name)
				except:
					self.add_node(to_node_name)
				
				# get to node object
				to_node = self.get_node(to_node_name)
				
				# create new empty arc object
				arc_new = Arc()
				# assign the arc attributes
				arc_new.weight = arc_weight
				arc_new.to_node = to_node
				arc_new.from_node = from_node
				
				# add arc information to the node objects
				from_node.arcs_out.append(arc_new)
				to_node.arcs_in.append(arc_new)
				
				# add arc information to the network
				self.arcs.append(arc_new)
						
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		
		# create an empty network

		# get all files in the folder nz_network
		files = glob('nz_network'+os.sep+'*')
		
		# find all folders containing node information
		for file in files:
			if (os.path.isdir(file)) & (file != 'nz_network\connections'):
				# get subfiles, i.e. the txt files containing node information
				subfiles = glob(file+os.sep+'*')
				# extract information from subfiles:
				for subfile in subfiles:
					fp = open(subfile, 'r')
					# read first line containing node name
					ln = fp.readline()
					ln = ln.strip()
					ln = ln.split(' ')
					name = ln[-1]
					value = [0,0]
					# read second line containing x coordinate
					ln = fp.readline()
					ln = ln.strip()
					ln = ln.split(':')
					value[0] = float(ln[-1])
					# read third line containing y coordinate
					ln = fp.readline()
					ln = ln.strip()
					ln = ln.split(':')
					value[1] = float(ln[-1])
					# add the node to the network
					self.add_node(name,value)
					
		# find the folder containing connection information
		for the_file in files:
			if the_file == 'nz_network\connections':
				# extract information from subfiles
				new_subfiles = glob(the_file+os.sep+'*')
				for new_subfile in new_subfiles:
					# strip year and capacity
					year, capacity = np.genfromtxt(new_subfile,dtype = None, skip_header = 1, delimiter = ",",unpack = 1)
					# find the average capacity
					total = sum(capacity)
					weight = total / 35
					# get from node and to node information from the file name
					new_subfile = new_subfile.split('.')
					name = new_subfile[0]
					name = name[-7:]
					name = name.split('-')
					from_node_name = name[0]
					to_node_name = name[1]
					# get the from and to nodes from the network
					from_node = self.get_node(from_node_name)
					to_node = self.get_node(to_node_name)
					# join the from and to nodes with the arc
					self.join_nodes(from_node,to_node,weight)
		
		
		
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
