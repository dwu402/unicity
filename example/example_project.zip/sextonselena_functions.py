# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		
		#empty node creation
		node = Node()
		#assigning names and values
		node.name = name
		node.value = value
		node.arcs_in = []
		node.arcs_out = []
		# add node to the list of nodes in the network
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''

		# creating an empty arc object
		new_arc = Arc()
		#assigning arc attributes
		new_arc.weight = weight
		new_arc.to_node = node_to 
		new_arc.from_node = node_from
		#adding the new arc into list of arcs from and to the relevant arcs
		node_from.arcs_out.append(new_arc)
		node_to.arcs_in.append(new_arc)
		#adding the new arc into list of all arcs in network
		self.arcs.append(new_arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''

		# open the file
		fp = open(filename, 'r')
		# get first line
		ln = fp.readline().strip()
		
		while ln is not '': 		# keep looping to the end of the file
			# split string into source node name and other arcs
			ln = ln.strip()
			
			try:
				from_node_name,arcs = ln.split(',', 1 )		#seperate out the node from the data
					# if node doesn't exist, add to network
					
				try:
					self.get_node(from_node_name)
				except NetworkError:
					self.add_node(from_node_name)
					
				# taking out the different arcs
				arcvalues = arcs.split(',')
				
				# goes through each arc value and splits the destination and the weight
				for i in arcvalues[:]:	
					destination_name,weight = i.split(';')
					# if node doesn't exist, add to network
					try:
						self.get_node(destination_name)
					except NetworkError:
						self.add_node(destination_name)
					# get destination node object and link it to source node
					self.join_nodes(self.get_node(from_node_name),self.get_node(destination_name),weight)
						
			except ValueError:		# if there are no arcs
				from_node_name = ln
				# if node doesn't exist, add to network
				try:
					self.get_node(from_node_name)
				except NetworkError:
					self.add_node(from_node_name)
			
			# get the next line
			ln = fp.readline().strip()
			
		# close the file
		fp.close()
			


class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		
		# find the folders in nz_network
		files = glob('nz_network'+os.sep+'*')
		for file in files:
			# skips the connections folder
			if file != ('nz_network'+os.sep+'connections'):
				# open up the station_data file for each node
				fp = open(file+os.sep+"station_data.txt","r")
				# goes through data to collect the x,y co-ordinates
				excess1, position = np.genfromtxt(file+os.sep+"station_data.txt", delimiter = ':', skip_header = 1, unpack=True)
				hdr = fp.readline()
				# from the header, spilt to get the name of the node
				excess2, name = hdr.split(': ')
				# take out the new line character
				name = name.rstrip('\n')
				#add the node, with it's name and value
				self.add_node(name, position)
		
		# go through and find all the files in the connections folder
		connections = glob('nz_network'+os.sep+'connections'+os.sep+'*')


		for values in connections:
			# for all files, spilt the data into time values and capacity values
			time, capacity = np.genfromtxt(values, delimiter = ', ', skip_header = 1, unpack=True)
			# find the average of the capacity
			average = (sum(capacity))/len(capacity)
			# spilt the file locations to get filename
			folder1,folder2,filename = values.split(os.sep)
			# take off the end of the file name
			filename = filename.rstrip('.txt')
			# split to get the from and to nodes
			node_from, node_to = filename.split('-')
			# join the two nodes, with their arc values
			self.join_nodes(self.get_node(node_from), self.get_node(node_to), average)
				

		
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
