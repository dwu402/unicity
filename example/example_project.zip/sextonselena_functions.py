import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		stat.cons_in = []
		stat.cons_out = []
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		new_conn = Connection()
		new_conn.wgt = weight
		new_conn.to_stat = stat_to
		new_conn.from_stat = stat_from
		stat_from.cons_out.append(new_conn)
		stat_to.cons_in.append(new_conn)
		self.connections.append(new_conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '': 		
			ln = ln.strip()
			try:
				from_stat_name,conns = ln.split(',', 1 )		
				try:
					self.query_station(from_stat_name)
				except GridError:
					self.add_station(from_stat_name)
				connvalues = conns.split(',')
				for i in connvalues[:]:
					destination_name,weight = i.split(';')
					try:
						self.query_station(destination_name)
					except GridError:
						self.add_station(destination_name)
					self.add_connection(self.query_station(from_stat_name),self.query_station(destination_name),weight)
			except ValueError:		
				from_stat_name = ln
				try:
					self.query_station(from_stat_name)
				except GridError:
					self.add_station(from_stat_name)
			ln = fp.readline().strip()
		fp.close()
class Roads(Grid):
	def read(self, directory):
		files = glob('roads_grid'+os.sep+'*')
		for file in files:
			if file != ('roads_grid'+os.sep+'backbone'):
				fp = open(file+os.sep+"info.txt","r")
				excess1, position = np.genfromtxt(file+os.sep+"info.txt", delimiter = ':', skip_header = 1, unpack=True)
				hdr = fp.readline()
				excess2, name = hdr.split(': ')
				name = name.rstrip('\n')
				self.add_station(name, position)
		connections = glob('roads_grid'+os.sep+'backbone'+os.sep+'*')
		for values in connections:
			time, capacity = np.genfromtxt(values, delimiter = ', ', skip_header = 1, unpack=True)
			average = (sum(capacity))/len(capacity)
			folder1,folder2,filename = values.split(os.sep)
			filename = filename.rstrip('.txt')
			stat_from, stat_to = filename.split('-')
			self.add_connection(self.query_station(stat_from), self.query_station(stat_to), average)
