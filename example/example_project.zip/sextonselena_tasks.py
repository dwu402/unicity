
from io import BytesIO
import numpy as np

# Splits distance and temperature values, deletes the header, and transposes
Xs, Ts = np.genfromtxt('example_file.txt', delimiter = ',', skip_header = 1, unpack=True)
