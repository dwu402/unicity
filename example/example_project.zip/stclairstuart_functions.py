import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			lnList = ln.split(',')
			from_stat_name = lnList[0]
			conns = lnList[1:]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			from_stat_object = self.query_station(from_stat_name)
			for conn in conns:
				toStationAndWeight = conn.split(';')
				to_stat_name = toStationAndWeight[0]
				conn_weight = toStationAndWeight[1]
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				destination_stat = self.query_station(to_stat_name)
				self.add_connection(from_stat_object, destination_stat, conn_weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		stations_folders = glob(directory + os.sep + '*')
		stations_folders.remove(directory + os.sep + 'backbone')
		for station in stations_folders:
			station_data = np.genfromtxt(station + os.sep + "info.txt", delimiter=':', autostrip=True, dtype='str')
			station_code = station_data[0,1]
			coords = [int(station_data[1,1]), int(station_data[2,1])]
			self.add_station(station_code, value=coords)
		connections = glob(directory + os.sep + 'backbone' + os.sep + '*')
		for connection in connections:
			connection_names = connection.split('-')
			from_stat_name = connection_names[0][-3:]
			to_stat_name = connection_names[1][0:3]
			from_stat = self.query_station(from_stat_name)
			to_stat = self.query_station(to_stat_name)
			time,capacity = np.genfromtxt(connection, delimiter=",",skip_header=1,unpack=True)
			average_capacity = np.mean(capacity)
			self.add_connection(from_stat, to_stat, average_capacity)
