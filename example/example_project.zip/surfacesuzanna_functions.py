# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight = None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
		
		
	
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		new_node = Node()
		new_node.name = name
		new_node.value = value
		
		
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		
		
		# append node to the list of nodes
		self.nodes.append(new_node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		new_arc = Arc()
		new_arc.to_node = node_to
		new_arc.from_node = node_from
		new_arc.weight = weight
		
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		self.arcs.append(new_arc) 
		node_from.arcs_out.append(new_arc)
		node_to.arcs_in.append(new_arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			sep = ln.split(",")
			
			#print("sep:", sep)
			first = sep[0]
			#print("node:", first)
			
			
			# if node doesn't exist, add to network
			try:
				self.get_node(first)
			except NetworkError:
				self.add_node(first)
				
			# get the source node object
			source_node = self.get_node(first)
				
			# read the arc information and add to network
			arcs = sep[1:]
			for arc in arcs:
				# parse arc information
				#join_nodes(self, node_from, node_to, weight)
				arc_value = arc.split(";")

				#assign node_to to the first split value from the arc_value
				node_to = arc_value[0]

				#assign weight to the second split value from the arc_value and convert into int
				weight = int(arc_value[1])


					# if node doesn't exist, add to network
				try:
					self.get_node(node_to)
				except NetworkError:
					self.add_node(node_to)
				
				# get the source node object, naming it as dest_node
				dest_node = self.get_node(node_to)


				# get destination node object and link it to source node
				self.join_nodes(source_node, dest_node, weight)

						
			# get next line
			ln = fp.readline().strip()
				
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this 
			should be used to name the node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		



			#getting data from electricitynetwork.txt

		files = glob('*')        # finds all files and folders matching the string, the * means "any text here"
#for file in files: print(file)  # print the list of files and folders

		#open the electricitynetwork.txt file
		fp = open('electricitynetwork.txt')
		ln = fp.readline().strip()

		#get code and position of nodes from the file
		while ln is not '':


				#parse node info
				sep = ln.split(',')
				name = sep[0]
				#print('name:', name)

				#if the split for the line contains something then continue assigning values, otherwise it inidcates empty line and skip 
				if name is not '':

					#set the 3 character name of the node 
					code = sep[1]

					#get the x and y co-ordinates of node, convert to int
					x = int(sep[2])
					y = int(sep[3])
					#print('code:', code, 'x=', x, 'y=', y)
				
				#add to the network with co-ordinates
				self.add_node(code, (x, y))
				
				# read info for next node
				ln = fp.readline().strip()


		#move down a line
		ln = fp.readline().strip()

		#get nodes to and from and weight of arc
		while ln is not '':

			#if the split for the line contains something then continue assigning values, otherwise it inidcates empty line and skip 
			if name is not '':

				#parse first line by dash
				sep = ln.split('-')
				nodefrom = sep[0]

				#parse the 'to' location from the weight
				sep2 = sep[1].split(',')
				nodeto = sep2[0]
				weight = int(sep2[1])
				#print('node_from:', nodefrom, 'node_to:', nodeto, 'wieght:', weight)
				
				#get the nodes from the node text extracted from file
				node_from = self.get_node(nodefrom)
				node_to = self.get_node(nodeto)

				#create arc between nodes
				self.join_nodes(node_from, node_to, weight)

				#move down a line
				ln = fp.readline().strip()
	
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
