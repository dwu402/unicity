import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt = None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		new_stat = Station()
		new_stat.id = name
		new_stat.val = value
		self.stations.append(new_stat)
	def add_connection(self, stat_from, stat_to, weight):
		new_conn = Connection()
		new_conn.to_stat = stat_to
		new_conn.from_stat = stat_from
		new_conn.wgt = weight
		self.connections.append(new_conn)
		stat_from.cons_out.append(new_conn)
		stat_to.cons_in.append(new_conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			sep = ln.split(",")
			first = sep[0]
			try:
				self.query_station(first)
			except GridError:
				self.add_station(first)
			source_stat = self.query_station(first)
			conns = sep[1:]
			for conn in conns:
				conn_value = conn.split(";")
				stat_to = conn_value[0]
				weight = int(conn_value[1])
				try:
					self.query_station(stat_to)
				except GridError:
					self.add_station(stat_to)
				dest_stat = self.query_station(stat_to)
				self.add_connection(source_stat, dest_stat, weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		files = glob('*')        
		fp = open('electricitygrid.txt')
		ln = fp.readline().strip()
		while ln is not '':
				sep = ln.split(',')
				name = sep[0]
				if name is not '':
					code = sep[1]
					x = int(sep[2])
					y = int(sep[3])
				self.add_station(code, (x, y))
				ln = fp.readline().strip()
		ln = fp.readline().strip()
		while ln is not '':
			if name is not '':
				sep = ln.split('-')
				statfrom = sep[0]
				sep2 = sep[1].split(',')
				statto = sep2[0]
				weight = int(sep2[1])
				stat_from = self.query_station(statfrom)
				stat_to = self.query_station(statto)
				self.add_connection(stat_from, stat_to, weight)
				ln = fp.readline().strip()
