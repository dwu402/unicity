import numpy as np
data = np.genfromtxt('electricitynetwork.txt', delimiter=',', names=True)
print('DATA:', data)