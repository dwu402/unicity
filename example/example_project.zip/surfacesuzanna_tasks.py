import numpy as np
data = np.genfromtxt('electricitygrid.txt', delimiter=',', names=True)
print('DATA:', data)
