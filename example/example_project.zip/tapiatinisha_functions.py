import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		conn.wgt = weight
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			ln = ln.split(",")
			conns = ln[1:]
			from_stat = ln[0]
			try:
				self.query_station(from_stat)
			except GridError:
				self.add_station(from_stat)
			source_stat = self.query_station(from_stat)
			for conn in conns:
				conn = conn.split(";")
				try:
					self.query_station(conn[0])
				except GridError:
					self.add_station(conn[0])
				dest_stat = self.query_station(conn[0])
				weight = conn[1]
				self.add_connection(source_stat,dest_stat,weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		def mean(array):
			return float(sum(array)) / max(len(array), 1)
		stat_folders = glob(directory+os.sep+'*'+os.sep+'info.txt')
		for folder in stat_folders:
			file = open(folder, 'r')
			ln = file.readline().strip()
			stat = ln[6:9] 			
			ln = file.readline().strip()
			ln = ln.split(":")
			x = int(ln[1])
			ln = file.readline().strip()
			ln = ln.split(":")
			y = int(ln[1])
			try:
				self.query_station(stat)
			except GridError:
				self.add_station(stat,value = [x,y])
		connections_folder = glob(directory+os.sep+'backbone'+os.sep+'*')
		for file in connections_folder:
			[time,capacity] = np.genfromtxt(file, delimiter=",", skip_header=1, unpack=1)
			weight = mean(capacity)			
			file = file.split("\\")
			file = file[2].split(".")
			file = file[0].split("-")
			from_stat = file[0]			
			to_stat = file[1]			
			self.add_connection((self.query_station(from_stat)),(self.query_station(to_stat)),weight)
