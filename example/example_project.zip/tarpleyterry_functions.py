# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		
		# creats an empty node
		node = Node()
		
		# assign the node the name that is given in the inputs
		node.name = name
		
		# assign the node the value that is given in the inputs
		node.value = value
		
		# append node to the list of nodes in the network
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		
		# create an empty arc
		arc = Arc()
		
		# designate the node that the arc is coming from using the given inputs
		arc.from_node = node_from
		
		# designate the node that the arc is going to using the given inputs
		arc.to_node = node_to
		
		# designate the weight of the arc using the given inputs
		arc.weight = weight
		
		# adding the arc to the list of arc leaving node_from
		node_from.arcs_out.append(arc)
		
		# adding the arc to the list of arc entering node_to
		node_to.arcs_in.append(arc)
		
		# adding the arc to the list of arcs in the network
		self.arcs.append(arc)
		
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
				
		# open the file in read mode
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		
		# keep looping to the end of the file
		while ln is not '':     
			
			# split string into source node name and other arcs using split() method for strings
			ln = ln.split(',')
			
			# getting the initial node that the arcs are coming from
			from_node_name = ln[0]
			
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			sourceNode = self.get_node(from_node_name)
			
			# removing the first value of the ln list and making it equal arcs
			arcs = ln[1:]
			
			# running through the list arcs
			for arc in arcs:
				
				# spliting the arc info into destination and weight
				arcInfo = arc.split(';')
				
				# assigning the destination to arcDest
				arcDest = arcInfo[0]
				
				# assigning the weight to arcWeight
				arcWeight = arcInfo[1]
				
				# if the destination node doesn't exist, add to network
				try:
					self.get_node(arcDest)
				except NetworkError:
					self.add_node(arcDest)
					
				# getting arc destination object and assigning it to destNode
				destNode = self.get_node(arcDest)
				
				# joining the nodes together using the found weight
				self.join_nodes(sourceNode,destNode,int(arcWeight))
				
			# getting the next line
			ln = fp.readline().strip()
			
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# finding all folders in the directory and outputing as a list
		folders = glob(directory+os.sep+'*')
		
		# working through list of folders
		for folder in folders:
			
			# checking that the folder isnt the conections folder
			if folder != (directory+os.sep+'connections'):
				
				# opening the station_data.txt file in read mode in folder
				fp = open(folder+os.sep+'station_data.txt','r')
				
				
				# striping the first line spliting at the : and retrieving the node code name
				line = fp.readline().strip()
				line = line.split(': ')
				code = line[1]
				
				# striping the next line spliting at the ': ' and retrieving the node x coordinate
				line = fp.readline().strip()
				line = line.split(': ')
				Xcoord = int(line[1])
				
				# striping the next line spliting at the ': ' and retrieving the node y coordinate
				line = fp.readline().strip()
				line = line.split(': ')
				Ycoord = int(line[1])
				
				# taking the x and y coordinates and putting them together in an array
				value = np.array([Xcoord,Ycoord])
				
				# adding the node to the network
				self.add_node(code,value)
				
				# closing the file
				fp.close()
		

		
		# opening the connections folder and returning all the text files as a list
		connections	= glob(directory+os.sep+'connections'+os.sep+'*.txt')
		
		# running through the text files in the connections folder
		for connection in connections:
				
			# spliting the directory path for the text file at the seperators
			dest = connection.split(os.sep)
			
			# retrieving the last item on the list after the previous split i.e. 'ABC-DEF.txt'
			# and spliting again at '.'
			dest = dest[-1].split('.')
			
			# retrieving the first item after the previous split i.e. 'ABC-DEF'
			# and spliting again at '-'
			dest = dest[0].split('-')
			
			# assigning the node the arc is coming from
			nodeFrom = dest[0]
			
			# assigning the node that the arc is going to
			nodeTo = dest[1]
			
			# getting the data from the text file ready for processing
			time, cap = np.genfromtxt(connection,delimiter=', ',skip_header=1,unpack=1)
			
			# changing the capacity list into an array
			cap = np.array(cap)
			
			# finding the mean value of the cap array this is our arc weight
			value = np.mean(cap)
			
			# finding the node object that the arc is coming from
			nodeFrom = self.get_node(nodeFrom)
			
			# finding the node object that the arc is going to
			nodeTo = self.get_node(nodeTo)
			
			# joing the nodes together with the weight value found
			self.join_nodes(nodeFrom,nodeTo,value)
				
				
				
		
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
