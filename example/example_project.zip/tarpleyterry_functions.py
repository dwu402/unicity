import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		conn.wgt = weight
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':
			ln = ln.split(',')
			from_stat_name = ln[0]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			sourceStation = self.query_station(from_stat_name)
			conns = ln[1:]
			for conn in conns:
				connInfo = conn.split(';')
				connDest = connInfo[0]
				connWeight = connInfo[1]
				try:
					self.query_station(connDest)
				except GridError:
					self.add_station(connDest)
				destStation = self.query_station(connDest)
				self.add_connection(sourceStation,destStation,int(connWeight))
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		folders = glob(directory+os.sep+'*')
		for folder in folders:
			if folder != (directory+os.sep+'backbone'):
				fp = open(folder+os.sep+'info.txt','r')
				line = fp.readline().strip()
				line = line.split(': ')
				code = line[1]
				line = fp.readline().strip()
				line = line.split(': ')
				Xcoord = int(line[1])
				line = fp.readline().strip()
				line = line.split(': ')
				Ycoord = int(line[1])
				value = np.array([Xcoord,Ycoord])
				self.add_station(code,value)
				fp.close()
		connections	= glob(directory+os.sep+'backbone'+os.sep+'*.txt')
		for connection in connections:
			dest = connection.split(os.sep)
			dest = dest[-1].split('.')
			dest = dest[0].split('-')
			statFrom = dest[0]
			statTo = dest[1]
			time, cap = np.genfromtxt(connection,delimiter=', ',skip_header=1,unpack=1)
			cap = np.array(cap)
			value = np.mean(cap)
			statFrom = self.query_station(statFrom)
			statTo = self.query_station(statTo)
			self.add_connection(statFrom,statTo,value)
