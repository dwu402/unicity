import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
    def __init__(self):
        self.stations = []
        self.connections = []
    def query_station(self, name):
        for stat in self.stations:
            if stat.id == name:
                return stat
        raise GridError
    def add_station(self, name, value=None):
        stat = Station()
        stat.id = name
        stat.val = value
        self.stations.append(stat)
    def add_connection(self, stat_from, stat_to, weight):
        conn = Connection()
        conn.wgt = weight
        conn.to_stat = stat_to
        conn.from_stat = stat_from
        self.connections.append(conn)
        stat_to.cons_in.append(conn)
        stat_from.cons_out.append(conn)
    def read(self, filename):
        fp = open(filename, 'r')
        ln = fp.readline().strip()
        while ln is not '':        
            from_stat_name, conns = ln.split(',')[0],ln.split(',')[1:]
            try:
                self.query_station(from_stat_name)
            except GridError:
                self.add_station(from_stat_name)
            source_stat = Station()
            source_stat = self.query_station(from_stat_name)
            for conn in conns:
                if conn != []:
                    try:
                        self.query_station(conn[0])
                    except GridError:
                        self.add_station(conn[0])
                    self.add_connection(self.query_station(source_stat.id),self.query_station(conn[0]),float(conn.split(';')[1]))
            ln = fp.readline().strip()
class Roads(Grid):
    def read(self, directory):
        connections = glob(directory+os.sep+'backbone'+os.sep+'*')
        i = 0
        for connection in connections:
            from_to = connections[i].strip('roads_grid'+os.sep+'backbone'+os.sep).strip('.txt')
            from_stat_name, to_stat_name = from_to.split('-')[0], from_to.split('-')[1]
            capacities = np.genfromtxt(connections[i],delimiter = ',', skip_header = 1,unpack=True)[1]
            weight = np.mean(capacities)
            try:
                self.query_station(from_stat_name)
            except GridError:
                self.add_station(from_stat_name)
            try:
                self.query_station(to_stat_name)
            except GridError:
                self.add_station(to_stat_name)
            self.add_connection(self.query_station(from_stat_name),self.query_station(to_stat_name),weight)
            folders = glob(directory+os.sep+'*')
            if self.query_station(from_stat_name).val is None:
                for folder in folders:
                    subfolders = glob(folder+os.sep+'*')
                    for file in subfolders:
                        fp0 = open(file)
                        header = fp0.readline()
                        fp0.close()
                        header = header.strip('\n')
                        if from_stat_name in header:
                            self.query_station(from_stat_name).val = np.genfromtxt(file,delimiter = ':', skip_header = 1,unpack=True)[1]
                            break
                    if self.query_station(from_stat_name).val is not None:
                        break
            if self.query_station(to_stat_name).val is None:
                for folder in folders:
                    subfolders = glob(folder+os.sep+'*')
                    for file in subfolders:
                        fp0 = open(file)
                        header = fp0.readline()
                        fp0.close()
                        header = header.strip('\n')
                        if to_stat_name in header:
                            self.query_station(to_stat_name).val = np.genfromtxt(file,delimiter = ':', skip_header = 1,unpack=True)[1]
                            break
                    if self.query_station(to_stat_name).val is not None:
                        break
            i += 1
