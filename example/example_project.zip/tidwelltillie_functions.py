import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		conn.wgt = weight
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			first_split = ln.split(',')
			from_stat = first_split[0]
			try:
				self.query_station(from_stat)
			except GridError:
				self.add_station(from_stat)
			source = self.query_station(from_stat)
			first_split.remove (first_split[0])
			conns = first_split
			for conn in conns:
				second_split = conn.split(';')
				stat_to = second_split[0]
				weight = int(second_split[1])
				try:
					self.query_station(stat_to)
				except GridError:
					self.add_station(stat_to)
				link = self.query_station(stat_to)
				self.add_connection(source,link,weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		if (os.path.isdir(directory) == True):
			connections = glob(directory + '\connections\*')
			station_data = glob(directory + '\*\info.txt')
			for station in station_data:
				code_name = np.genfromtxt(station, str, delimiter = ':')
				name = str(code_name[0,1])
				name = name.strip()
				location = np.genfromtxt(station, skip_header = 1, delimiter = ':')
				x = location[0,1]
				y = location[1,1]
				value = []
				value.append(x)
				value.append(y)
				self.add_station(name, value)
			for connection in connections:
				find_name = connection.split('\\')
				find_name = find_name[2].split('-')
				stat_from = find_name[0]
				find_name = find_name[1].split('.')
				stat_to = find_name[0]
				capacity = np.genfromtxt(connection, skip_header = 1, unpack = True, delimiter = ",")
				mean_capacity = (sum(capacity[1,:]))/(len(capacity[1,:]))
				source = self.query_station(stat_from)
				destination = self.query_station(stat_to)
				self.add_connection(source,destination,mean_capacity)
		else:
			print("The directory you have specified is not contained within the current directory")
