import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		conn.wgt = weight
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			source_stat_name = ln.split(",")[0]
			other_conns = ln.split(",")[1:]
			try:
				self.query_station(source_stat_name)
			except GridError:
				self.add_station(source_stat_name)
			self.query_station(source_stat_name)
			for other_conn in other_conns:
				destination_stat_name = other_conn.split(';')[0]
				connWeight = other_conn.split(';')[1]
				try:
					self.query_station(destination_stat_name)
				except GridError:
					self.add_station(destination_stat_name)
				self.add_connection(self.query_station(source_stat_name), self.query_station(destination_stat_name), connWeight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		os.chdir('roads_grid')
		files = glob('*')
		files[files.index('backbone')], files[-1]=files[-1], files[files.index('backbone')]
		for file in files:
			if (file != 'backbone'):
				os.chdir(file)
				data = np.genfromtxt('info.txt', dtype=str, delimiter=': ', usecols=(1))
				try:
					self.query_station(data[0])
				except GridError:
					self.add_station(data[0], [int(data[1]), int(data[2])])
				os.chdir ('..')
			else:
				os.chdir(file)
				subfiles = glob('*')
				for subfile in subfiles:
					conn_weights = np.genfromtxt(subfile, dtype=None, delimiter=',',skip_header=1 , usecols=(1) )
					average_weights = np.mean(conn_weights)
					self.add_connection(self.query_station(subfile[:3]), self.query_station(subfile[4:7]), average_weights)
				os.chdir('..')
		os.chdir('..')
