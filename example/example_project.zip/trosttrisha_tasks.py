#this script reads data from the file 'example_file.txt' and returns the vectors Ts and 
#Vs, skipping the number of lines specified by "skipheader"

[Ts, Xs]=np.genfromtxt('example_file.txt', delimter=',', skip_header=1, unpack=True)