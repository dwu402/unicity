[Ts, Xs]=np.genfromtxt('example_file.txt', delimter=',', skip_header=1, unpack=True)
