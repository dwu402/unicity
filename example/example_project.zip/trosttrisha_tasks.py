[Ts, Xs]=np.genfromtxt('data.txt', delimter=',', skip_header=1, unpack=True)
