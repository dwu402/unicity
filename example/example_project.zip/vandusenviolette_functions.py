# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		#create an empty node object
		node = Node()
		#give the node the specified attributes
		node.name = name
		node.value = value
		
		
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		
		
		# append node to the list of nodes
		self.nodes.append(node)

	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		
		#create an empty node object
		arc = Arc()
		#assign the arc the specified attributes
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from
		
		#append arc onto list of arcs within the network
		self.arcs.append(arc) 
		
		#append the arc to the corresponding lists of arcs going in or out of the node
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			
			#split the line by the comma, place into a list, as the number of elements varies in different lines
			stuff = ln.split(',')
			from_node_name = stuff[0]
			
			#create an empty list for the arc values, and add one, two or none depending on the line
			arcs = []
			
			#add a first element to arcs list if it exists
			if len(stuff)>1:
				arcs.append(stuff[1])	
			
			#add a second element to the arcs list if it exists
			if len(stuff)>2:
				arcs.append(stuff[2])

			
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			sourcenode = self.get_node(from_node_name)
				
			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				node_to, weight = arc.split(';')
				
				# get destination node object and link it to source node
				
					# if the destination node doesn't exist, add it to network,
					# as the destination nodes mostly won't have been created
				try:
					self.get_node(node_to)
				except NetworkError:
					self.add_node(node_to)
				
				#get the destination node object
				destnode = self.get_node(node_to)
				
				#join the source and destination nodes
				self.join_nodes(sourcenode, destnode, weight)
						
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		
		#find files in the correct directory
		files = glob(directory+os.sep+'*')
		for file in files:
			if os.path.isdir(file): #if there are more pathways in the directory then it is a wanted folder
				#locate subfiles that are in the files in the directory
				subfiles = glob(file+os.sep+'*')
				
				if len(subfiles) == 1:  #this folder must contain just a node, need to add nodes first
					for subfile in subfiles:
						#get data from the file, using type string initially
						data = np.genfromtxt(subfile, delimiter = ': ', usecols = (1), dtype = "str") #get text from this file
	
						#This is the node name, as a string
						node_name = data[0]
						
						#convert the x and y values for location to integers, combine to get a single value
						x = int(data[1])
						y = int(data[2])
						value = (x, y)
						
						#add the node found in the subfile to the network
						self.add_node(node_name, value)
						
						
		for file in files:
			if os.path.isdir(file): #if there are more pathways in the directory then it is a wanted folder
				#get subfiles again
				subfiles = glob(file+os.sep+'*')		
				
				
				if len(subfiles)>1:  #this means that it is the connections folder, this had to be
									#a seperate loop as it needs to be done after the node information
									#is added to the network, so connections are made between present nodes
					for subfile in subfiles:
						#get data from the subfiles in the connections folder
						[time, capacity] = np.genfromtxt(subfile, delimiter = ',', skip_header = 1, unpack = True, dtype = 'float')

						title = subfile.split(os.sep)[-1]
						
						#split off unwanted .txt part of title
						nodes, extra = title.split('.')
						#split remainder of title 
						node_from, node_to = nodes.split('-')
						
						capacity = np.array(capacity)
						
						#sum the capacities and divide by the number of time measurements
						#to get the mean capacity
						sumcapacity = np.sum(capacity)
						meancapacity = sumcapacity/(len(time))
						
						#get nodes to join them.
						nodeone = self.get_node(node_from)
						nodetwo = self.get_node(node_to)
						#join the nodes
						self.join_nodes(nodeone, nodetwo, meancapacity)
					
		
		
		
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
