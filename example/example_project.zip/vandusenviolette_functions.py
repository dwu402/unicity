import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			stuff = ln.split(',')
			from_stat_name = stuff[0]
			conns = []
			if len(stuff)>1:
				conns.append(stuff[1])
			if len(stuff)>2:
				conns.append(stuff[2])
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			sourcestat = self.query_station(from_stat_name)
			for conn in conns:
				stat_to, weight = conn.split(';')
				try:
					self.query_station(stat_to)
				except GridError:
					self.add_station(stat_to)
				deststat = self.query_station(stat_to)
				self.add_connection(sourcestat, deststat, weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		files = glob(directory+os.sep+'*')
		for file in files:
			if os.path.isdir(file): 
				subfiles = glob(file+os.sep+'*')
				if len(subfiles) == 1:  
					for subfile in subfiles:
						data = np.genfromtxt(subfile, delimiter = ': ', usecols = (1), dtype = "str") 
						stat_name = data[0]
						x = int(data[1])
						y = int(data[2])
						value = (x, y)
						self.add_station(stat_name, value)
		for file in files:
			if os.path.isdir(file): 
				subfiles = glob(file+os.sep+'*')
				if len(subfiles)>1:  
					for subfile in subfiles:
						[time, capacity] = np.genfromtxt(subfile, delimiter = ',', skip_header = 1, unpack = True, dtype = 'float')
						title = subfile.split(os.sep)[-1]
						stations, extra = title.split('.')
						stat_from, stat_to = stations.split('-')
						capacity = np.array(capacity)
						sumcapacity = np.sum(capacity)
						meancapacity = sumcapacity/(len(time))
						statone = self.query_station(stat_from)
						stattwo = self.query_station(stat_to)
						self.add_connection(statone, stattwo, meancapacity)
