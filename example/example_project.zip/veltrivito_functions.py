# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob


class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
class Network(object):
	''' Basic network class.
	'''
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	

	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# create an empty node object and assign its attributes
		node = Node()	
		node.name = name
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# create an empty arc object and assign its attributes
		arc = Arc()
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from
		
		# append arc to the list of arcs in the network
		self.arcs.append(arc)
		
		# append the new arc to node_from and node_to
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			try:
				from_node_name,arcs = ln.split(',',1) # split at the first comma in the line
				arcs = arcs.split(',') # get destination;weight pairs
			except: # if there are no arcs coming from this node, assign an empty list to arcs
				from_node_name = ln
				arcs = []
			
			# if the source node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			node_from = self.get_node(from_node_name)
				
			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				to_node_name,weight = arc.split(';')
				
				# if the destination node doesn't exist, add to network
				try:
					self.get_node(to_node_name)
				except NetworkError:
					self.add_node(to_node_name)

				# get destination node object and link it to source node
				node_to = self.get_node(to_node_name)
				self.join_nodes(node_from,node_to,weight)
						
			# get next line
			ln = fp.readline().strip()
			
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		# list all the files in the given directory
		files = glob(directory+os.sep+'*')
		
		# loop through the list and add each node
		for file in files:
			if os.path.isdir(file): # if the file is a directory
				# get station data if the file is not the connections folder
				if file != (directory+os.sep+'connections'):
					# open station_data.txt and get the code and the x and y coordinates
					fp = open(file+os.sep+'station_data.txt','r')
					code = fp.readline().strip('code: '+'\n') # strip everything in the line except the code
					x = int(fp.readline().strip('x: '+'\n')) # convert coordinates from a string to an integer
					y = int(fp.readline().strip('y: '+'\n'))
					fp.close()

					# add the new node to the network with the name=code and value=[x,y]
					self.add_node(code, [x,y])

		# list all the files in the connections folder
		files = glob(directory+os.sep+'connections'+os.sep+'*')

		# loop through the list and add each arc
		for file in files:
			# strip everything from the filename except the connection (from-to)
			connection = file.strip(directory+os.sep+'connections'+os.sep+'.txt')
			# split string into names of to_node and from_node
			to_node_name,from_node_name = connection.split('-')
			
			# get time and capacity data from the textfile
			t,C = np.genfromtxt(file,skip_header=1,delimiter=',',unpack=1)
			# calculate mean capacity which is the connection weight
			weight = sum(C)/len(C)

			# get source and destination nodes and join them together
			node_from = self.get_node(from_node_name)
			node_to = self.get_node(to_node_name)
			self.join_nodes(node_from,node_to,weight)

			
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
