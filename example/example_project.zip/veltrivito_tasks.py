import numpy as np
xs,Ts = np.genfromtxt('data.txt', skip_header=1, delimiter = ',', unpack=1)
