# Task 1a: File I/O
import numpy as np
# get the distance xs and temperature Ts from example_file.txt by splitting at the comma
xs,Ts = np.genfromtxt('example_file.txt', skip_header=1, delimiter = ',', unpack=1)