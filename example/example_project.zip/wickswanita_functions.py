import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
import string
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat=Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		conn.wgt = weight
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			xs = [] 				
			line = ln.split(",")    
			from_stat_name = line[0]	
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			stat_from = self.query_station(from_stat_name)
			del line[0]					
			try:						
				x1 = line[0]
			except IndexError:
				x1 = None
			try:
				x2 = line[1]
			except IndexError:
				x2 = None
			if x1 != None:
				to_stat_name,conn_weight = x1.split(";")			
				try:
					self.query_station(to_stat_name)					
				except GridError:
					self.add_station(to_stat_name)
				stat_to = self.query_station(to_stat_name)						
				self.add_connection(stat_from, stat_to, conn_weight)				
			if x2 != None:												
				to_stat_name,conn_weight = x2.split(";")
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				stat_to = self.query_station(to_stat_name)				
				self.add_connection(stat_from, stat_to, conn_weight)
				ln = fp.readline().strip() 
			else:
				ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		sep = os.sep
		files = glob("{}{}*".format(directory,sep))
		for file in files:
			if file != 'roads_grid\\connections':
					fp = open('{}{}info.txt'.format(file, sep),'r')		
					ln = fp.readline()											
					Ts = []
					count = 0
					while ln != '':
						count = count + 1
						ln = ln.strip()
						x,T = ln.split(':')										
						Ts.append(str(T))
						ln = fp.readline()
						if count%3 == 0:										
							Ts[1] = int(Ts[1])									
							Ts[2] = int(Ts[2])
							self.add_station(Ts[0], [Ts[1], Ts[2]])
			else:
				filec = glob(file+os.sep+'*')									
				for file in filec:												
					stringfile = str(file)										
					stat_from = stringfile[23],stringfile[24],stringfile[25]		
					''.join(stat_from)																		
					stat_to = stringfile[27],stringfile[28],stringfile[29]
					''.join(stat_to)
					Fp = open(file,'r')											
					hdr = Fp.readline()											
					ln = Fp.readline()											
					Xs = []														
					while ln != '':												
						ln = ln.strip()											
						N,useful = ln.split(',')								
						Xs.append(float(useful))								
						ln = Fp.readline()										
					Xs = np.array(Xs)											
					weightcap = sum(Xs)/len(Xs)
				try:
					self.query_station(stat_from)
				except GridError:
					self.add_station(stat_from)
				try:
					self.query_station(stat_to)
				except GridError:
					self.add_station(stat_to)
				self.add_connection(self.query_station(stat_from),self.query_station(stat_to),weightcap)					
