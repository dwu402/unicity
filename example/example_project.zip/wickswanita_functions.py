# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
import string

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		node=Node()
		
		# **hint: how are names and values assigned in the __init__ method for node?**
		node.name = name
		node.value = value
		
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		arc = Arc()
		arc.to_node = node_to
		arc.from_node = node_from
		arc.weight = weight
		
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		
		self.arcs.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			xs = [] 				# creates an empty array
			line = ln.split(",")    # splits file with the delimiter , info seperated into source node and to node      
			from_node_name = line[0]	# gives the name of node from the source index
			          
						
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			
			# get the source node object
			node_from = self.get_node(from_node_name)
				
			# read the arc information and add to network
			
			
			del line[0]					#useful information from index 0 has been used and no longer needed
			try:						# if there is anything in index 1,2 then proceed to the while loop
				x1 = line[0]
			except IndexError:
				x1 = None
			try:
				x2 = line[1]
			except IndexError:
				x2 = None
		
			
			#for first coordinates on first line
			   #parse arc information
			if x1 != None:
				to_node_name,arc_weight = x1.split(";")			#splits information into to node name and arc weight		
				try:
					self.get_node(to_node_name)					# creates a node if need be
				except NetworkError:
					self.add_node(to_node_name)
					
				node_to = self.get_node(to_node_name)						#join_nodes
				self.join_nodes(node_from, node_to, arc_weight)				#get destination node object and link it to source node
				
				#for second coordinates on first line
				#parse arc information
			
			if x2 != None:												# same thing but for the information adjacent to the first
				to_node_name,arc_weight = x2.split(";")
				
				try:
					self.get_node(to_node_name)
				except NetworkError:
					self.add_node(to_node_name)
				
			
				node_to = self.get_node(to_node_name)				#node join
				self.join_nodes(node_from, node_to, arc_weight)	
			
						
				ln = fp.readline().strip() # reads the next line regardless of the result
			
			else:
				ln = fp.readline().strip()	
		
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		sep = os.sep 
		files = glob("{}{}*".format(directory,sep))
		
			
		for file in files:
			if file != 'nz_network\\connections':

					fp = open('{}{}station_data.txt'.format(file, sep),'r')		# accesses the folders in the nz_network folder
					ln = fp.readline()											#read first line
					Ts = []
					count = 0
					while ln != '':
						count = count + 1
						ln = ln.strip()
						x,T = ln.split(':')										# splits into useful information
						
						
						Ts.append(str(T))
						
						ln = fp.readline()
						if count%3 == 0:										# every time the count reaches 3, Ts index is all full,
							Ts[1] = int(Ts[1])									# therefore can be put into the get node function
							Ts[2] = int(Ts[2])
							
					
							self.add_node(Ts[0], [Ts[1], Ts[2]])
			else:
				filec = glob(file+os.sep+'*')									# check the connections folder and the subfiles

				for file in filec:												# start a loop into each text document
					stringfile = str(file)										# creates a string of the text name so that node names can be found

					node_from = stringfile[23],stringfile[24],stringfile[25]		# finds the to node and from node names
					''.join(node_from)																		# concatonates the characters
					
					node_to = stringfile[27],stringfile[28],stringfile[29]
					''.join(node_to)

					Fp = open(file,'r')											# opens the first text document						
					hdr = Fp.readline()											# reads and removes the header					
					ln = Fp.readline()											# reads the first line of the values
					Xs = []														# creates an empty array
					while ln != '':												# reads through the data until there is a blank line
						
						ln = ln.strip()											# takes away the character carriage
						N,useful = ln.split(',')								# splits data into the useful capacity and other data
						Xs.append(float(useful))								# appends to the a list
						ln = Fp.readline()										# reads the next line
						
					Xs = np.array(Xs)											# changes type from list to array
					weightcap = sum(Xs)/len(Xs)		
																			# finds the average capacity for an arc
				try:
					self.get_node(node_from)
				except NetworkError:
					self.add_node(node_from)
				try:
					self.get_node(node_to)
				except NetworkError:
					self.add_node(node_to)
					
				self.join_nodes(self.get_node(node_from),self.get_node(node_to),weightcap)					# joins the nodes with the respective arc weights
					
					
				
				
				
				
				
		
		
						
							
						

						
			
			
				
	
				
			
				
			
			
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
