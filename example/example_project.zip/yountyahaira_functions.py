import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station() 
		stat.id = name 
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		conn.wgt = weight
		stat_from.cons_out.append(conn) 
		stat_to.cons_in.append(conn) 
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			conns = [] 
			try: 
				from_stat_name , conn1info , conn2info = ln.split(",") 
				to_stat_name1 , conn1Weight = conn1info.split(";") 
				to_stat_name2 , conn2Weight = conn2info.split(";")
				conn1 = Connection() 
				conn1.wgt = conn1Weight
				try: 
					self.query_station(to_stat_name1)
				except GridError:
					self.add_station(to_stat_name1)
				conn1.to_stat = self.query_station(to_stat_name1)
				conns.append(conn1) 
				conn2 = Connection() 
				conn2.wgt = conn2Weight
				try: 
					self.query_station(to_stat_name2)
				except GridError:
					self.add_station(to_stat_name2)
				conn2.to_stat = self.query_station(to_stat_name2)
				conns.append(conn2) 
			except ValueError:
				try: 
					from_stat_name , conn1info = ln.split(",")
					to_stat_name1 , conn1Weight = conn1info.split(";")
					conn1 = Connection()
					conn1.wgt = conn1Weight
					try:
						self.query_station(to_stat_name1)
					except GridError:
						self.add_station(to_stat_name1)
					conn1.to_stat = self.query_station(to_stat_name1)
					conns.append(conn1)
				except ValueError:
					break; 
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			sourceStation = self.query_station(from_stat_name)
			for conn in conns:
				conn.from_stat = sourceStation
				destinationStation = conn.to_stat
				sourceStation.cons_out.append(conn)
				destinationStation.cons_in.append(conn)
				self.connections.append(conn) 
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		files = glob('*')
		for folder in files: 
			if os.path.isdir(directory): 
				directoryFolders = glob(directory+os.sep+'*')
				for location in directoryFolders: 
					if location != directory+os.sep+'backbone':
						stationData = open(location+os.sep+'info.txt', 'r') 
						ln = stationData.readline() 
						[prefix , name] = ln.split(': ')
						name = name.strip() 
						stat = Station() 
						stat.id = name
						self.stations.append(stat) 
						ln = stationData.readline() 
						[prefix , xLoc] = ln.split(' ')
						xLoc = xLoc.strip()
						xLoc = int(xLoc) 
						ln = stationData.readline() 
						[prefix , yLoc] = ln.split(' ')
						yLoc = yLoc.strip()
						yLoc = int(yLoc)
						statLocation = [xLoc , yLoc]
						stat.val = statLocation
						stationData.close() 
				connFiles = glob(directory+os.sep+'backbone'+os.sep+'*') 
				for file in connFiles:
					connFile = open(file, 'r')
					fileName = os.path.basename(connFile.id) 
					sourceStation = fileName[:3] 
					destinationStation = fileName[4:7]
					fromStation = self.query_station(sourceStation) 
					toStation = self.query_station(destinationStation)
					conn = Connection() 
					conn.from_stat = fromStation
					fromStation.cons_out.append(conn)
					conn.to_stat = toStation
					toStation.cons_in.append(conn)
					[year , capacityList] = np.genfromtxt(fname = file , skip_header=1, delimiter = ',', unpack=1) 
					capacity = sum(capacityList) / len(capacityList) 
					conn.wgt = capacity
					self.connections.append(conn) 
					connFile.close()
