# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		
		node = Node() # creates an empty node object
		node.name = name # this line and the next assigns a name and value to the node
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		
		# creates an empty arc object and assigns its attributes
		arc = Arc() 
		arc.from_node = node_from
		arc.to_node = node_to
		arc.weight = weight
		
		node_from.arcs_out.append(arc) # adds arc to list of arcs leaving from the source node
		node_to.arcs_in.append(arc) # adds arc to list of nodes entering the destination node
		
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()

		while ln is not '':        # keep looping to the end of the file
			arcs = [] # create list of arcs in each line of the file
			# split string into source node name and other arcs using split() method for strings
			try: # if there are two arcs
				from_node_name , arc1info , arc2info = ln.split(",") # splits line into 3 sections using a comma as the delimiter
				to_node_name1 , arc1Weight = arc1info.split(";") # splits line into destination node and arc weight using a semi-colon as the delimiter
				to_node_name2 , arc2Weight = arc2info.split(";")
				
				arc1 = Arc() # for first arc
				arc1.weight = arc1Weight
				
				try: # if destination node doesn't exist then add it to the network
					self.get_node(to_node_name1)
				except NetworkError:
					self.add_node(to_node_name1)
				
				arc1.to_node = self.get_node(to_node_name1)				
				arcs.append(arc1) # add arc to list of arcs
				
				
				arc2 = Arc() # for second arc
				arc2.weight = arc2Weight
				
				try: # if destination node doesn't exist then add it to the network
					self.get_node(to_node_name2)
				except NetworkError:
					self.add_node(to_node_name2)
					
				arc2.to_node = self.get_node(to_node_name2)				
				arcs.append(arc2) # add arc to list of arcs
			except ValueError:
				try: # if there is only one arc
					from_node_name , arc1info = ln.split(",")
					to_node_name1 , arc1Weight = arc1info.split(";")
					arc1 = Arc()
					arc1.weight = arc1Weight
					
					try:
						self.get_node(to_node_name1)
					except NetworkError:
						self.add_node(to_node_name1)
					arc1.to_node = self.get_node(to_node_name1)						
					arcs.append(arc1)
					
				except ValueError:
					break; # if there are  no arcs then break out of loop
			
			
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			sourceNode = self.get_node(from_node_name)

			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				arc.from_node = sourceNode
				# get destination node object and link it to source node
				destinationNode = arc.to_node
				sourceNode.arcs_out.append(arc)
				destinationNode.arcs_in.append(arc)
				self.arcs.append(arc) # add arc to list of arcs in the network
			# get next line
			ln = fp.readline().strip()
		
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		files = glob('*')
		for folder in files: # looking through root folder
			if os.path.isdir(directory): # stop when directory with data found
				#print(directory)
				directoryFolders = glob(directory+os.sep+'*')
				#print(directoryFolders)
				for location in directoryFolders: # for loop to get node names and locations
					if location != directory+os.sep+'connections':
						#print(location)
						stationData = open(location+os.sep+'station_data.txt', 'r') # open station_data file
						ln = stationData.readline() # first line (contains node abbreviation)
						[prefix , name] = ln.split(': ')
						name = name.strip() # strips unwanted items off string
						node = Node() # create new node object
						node.name = name
						self.nodes.append(node) # add node to list of nodes in network
						
						ln = stationData.readline() # get second line (contains node x location)
						[prefix , xLoc] = ln.split(' ')
						xLoc = xLoc.strip()
						xLoc = int(xLoc) # converts from string to integer
						ln = stationData.readline() # get third line (contains node y location)
						[prefix , yLoc] = ln.split(' ')
						yLoc = yLoc.strip()
						yLoc = int(yLoc) 
						nodeLocation = [xLoc , yLoc]
						node.value = nodeLocation
						#print(node.name)
						#print(node.value)
						
						stationData.close() # close the file
				arcFiles = glob(directory+os.sep+'connections'+os.sep+'*') # get arc data
				for file in arcFiles:
					arcFile = open(file, 'r')
					fileName = os.path.basename(arcFile.name) # get file name with destination and source node
					sourceNode = fileName[:3] # extracts source node and destination node codes from filename
					destinationNode = fileName[4:7]
					fromNode = self.get_node(sourceNode) # get source and destination node objects
					toNode = self.get_node(destinationNode)
					arc = Arc() # create new arc object
					arc.from_node = fromNode
					fromNode.arcs_out.append(arc)
					arc.to_node = toNode
					toNode.arcs_in.append(arc)
					# find weight of arc 
					[year , capacityList] = np.genfromtxt(fname = file , skip_header=1, delimiter = ',', unpack=1) # extracts list of years and corresponding capacities
					capacity = sum(capacityList) / len(capacityList) # finds average capacity
					arc.weight = capacity
					self.arcs.append(arc) # adds arc to list of arcs in network
					arcFile.close()
					
					
				#print(arcFiles)
					
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
