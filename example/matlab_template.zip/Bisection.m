% Nonlinear equation root finding by the bisection method.
% Inputs
% f      : nonlinear function
% xl, xr : initial root bracket
% nmax   : maximum number of iterations performed
% tol    : numerical tolerance used to check for root
% Outputs
% x      : one-dimensional array containing estimates of root
% i      : number of estimates considered
% n      : number of function evaluations

% Hint 1:
% Iterate until either a root has been found or maximum number of iterations has been reached

% Hint 2:
% Check for root each iteration, making use of tol

% Hint 3:
% Update the bracket each iteration

function [x, i, n] = Bisection(f, xl, xr, nmax, tol)

end