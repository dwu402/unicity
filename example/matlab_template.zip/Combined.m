% Nonlinear equation root finding by the combined bisection/Newton's method
% Inputs
% f      : nonlinear function
% g      : nonlinear function derivative (gradient)
% xl, xr : initial root bracket
% nmax   : maximum number of iterations performed
% tol    : numerical tolerance used to check for root
% Outputs
% x      : one-dimensional array containing estimates of root
% i      : number of estimates considered
% nf      : number of function (f) evaluations
% ng      : number of gradient (g) evaluations

function [x, i, nf, ng] = Combined(f, g, xl, xr, nmax, tol)

end
