% Nonlinear equation root finding by Newton's method
% Inputs
% f      : nonlinear function
% g      : nonlinear function derivative (gradient)
% x0     : initial root estimate
% nmax   : maximum number of iterations performed
% tol    : numerical tolerance used to check for root
% Outputs
% x      : one-dimensional array containing estimates of root
% i      : number of estimates considered
% nf      : number of function (f) evaluations
% ng      : number of gradient (g) evaluatio

function [x, i, nf, ng] = Newton(f, g, x0, nmax, tol)

end