% Nonlinear equation root finding in n dimensions using Newton's Method.
% Inputs
% n        : number of dimensions for Newton's method
% func     : function handle for system of nonlinear equations f_i(x) -> f(x,i)
% x0       : vector of initial root estimates for each independent variable
% h        : step size for numerical estimate of partial derivatives
% max_iter : maximum number of iterations performed
% tol      : numerical tolerance used to check for root
% Outputs
% x        : array (n-row matrix) containing estimates of root

% Hint 1: 
% Include the initial root estimate as the first column of x

% Hint 2:
% Use MATLAB in-built functionality for solving the matrix equation for vector of updates, delta

% Hint 3:
% Check for root each iteration, continuing until the maximum number of iterations has been reached

function x = NewtonMultiVar(n, f, x0, h, max_iter, tol)

end