% Nonlinear equation root finding by the Regula falsi method.
% Inputs
% f      : nonlinear function
% xl, xr : initial root bracket
% nmax   : maximum number of iterations performed
% tol    : numerical tolerance used to check for root
% Outputs
% x      : one-dimensional array containing estimates of root
% i      : number of estimates considered
% n      : number of function evaluations

function [x, i, n] = Regulafalsi(f, xl, xr, nmax, tol)


end 