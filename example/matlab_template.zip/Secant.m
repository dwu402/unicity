% Nonlinear equation root finding by the secant method.
% Inputs
% f      : nonlinear function
% x0, x1 : initial root bracket
% nmax   : maximum number of iterations performed
% tol    : numerical tolerance used to check for root
% Outputs
% x      : one-dimensional array containing estimates of root
% i      : number of estimates considered
% n      : number of function evaluations

function [x, i, n] = Secant(f, x0, x1, nmax, tol)


end 
