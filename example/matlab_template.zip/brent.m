function [xmin,fmin,k] = brent(f,a,b,tol,maxiter)
%brent Function minimisation with Brent's search
% Inputs
% f       : function handle
% a       : lower limit of interval of uncertainty
% b       : upper limit of interval of uncertainty
% tol     : convergence tolerance
% maxiter : maximum number of iterations

% Outputs
% xmin    : the minimizer of the function
% fmin    : the minimum function value
% k       : number of iterations completed

c = 0.5*(a + b); % set the third point to be mid-point of the interval of uncertainty.

% Complete this function
