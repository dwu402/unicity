# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob, iglob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		

def test_client_func():
    pass
        
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
		test_client_func()
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		
		#create empty node
		node = Node()
		
		#name node the name that was inputed
		node.name = name
		
		#Set the value of the node to that that was inputted
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		
		#Create empty arc
		arc = Arc()
		
		#Set the node that the arc points to
		arc.to_node = node_to
		
		#Set the node that the node points from
		arc.from_node = node_from
		
		#Sets the weight (strength) of the arc
		arc.weight = weight
		
		#Adds the arc to the list of arcs in the network
		self.arcs.append(arc)
		
		#add the arc to the list of arcs leaving the node that the arc leaves from
		node_from.arcs_out.append(arc)
		
		#add the arc to the list of arcs entering the node that the arc enters into
		node_to.arcs_in.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			
			#split on the ',' symbol and create list
			nodes = ln.split(',')
			
			#the from node is the first element in the list
			from_node_name = nodes[0]
			
			#arcs are the remainder of the elements
			arcs = nodes[1:]
			
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			source_node = self.get_node(from_node_name)
				
			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				[to_node_name,weight_string] = arc.split(';')
				
				#convert weight_string to a float number
				weight = float(weight_string)
				
				# get destination node object and link it to source node
				try:
					self.get_node(to_node_name)
				except NetworkError:
					self.add_node(to_node_name)
				
				# get the destination node object
				destination_node = self.get_node(to_node_name)
				
				#join the source node and the destination node
				self.join_nodes(source_node,destination_node,weight)
						
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		
		#Check if the directory inputted is accessible from the current working directory. If it is accessible enter directory.
		#If the directory not found, raise an error
		if os.path.isdir(directory):
		
			#retrieve all files in the directory
			files = glob(directory+os.sep+'*')
			
			#for each file in the directory, access all folders containing required information and use this to set up the network
			for file in files:
				
				#if file is a directory and is not named 'connections' assume it defines a node in the network, retrieve information and create node
				if os.path.isdir(file):
				
					#If not the connections directory must be a node
					if (file.split(os.sep)[-1]) != 'connections':
					
						#try to retrieve the node information from the file. This includes a name for the node (name) an x coordinate (x) and a y coordinate (y)
						#Then make the node. If this cannot be done an alert is triggered and the file is not included in calculating the network.
						try:
						
							#retrieve information
							[name,x,y] = np.genfromtxt(fname = file+os.sep+'station_data.txt', delimiter = ': ', usecols = -1, dtype = str)
							
							#create node
							self.add_node(name,[float(x),float(y)])
							
						except:
						
							#alert the user that a folder has been excluded from node calculations
							print('data could not be retrieved from station_data.txt in {}. File excluded from network'.format(file))
							pass
			
			#In order to generate the connections for the nodes the folder named 'connections' is accessed and all files dictating the connections are retrieved.
			#Of there is no folder named 'connections' the nodes cannot be joined and an error mesage is generated.
			if os.path.isdir(directory+os.sep+'connections'):
			
				#retrieve all files detailing the connections
				conections = glob(directory+os.sep+'connections'+os.sep+'*')
				
				#for each file detailing a conection, link the two nodes that the title of the file represents with a weight calculated from the data in the file.
				for conection in conections:
				
					#Attempt to create an arc between nodes based on information from the file. If this is not possible an alert is generated and the file is not included in arc calculations
					try:
					
						#retrieve network capacitances from past years out of the file
						capacitys = np.genfromtxt(fname = conection, delimiter = ', ', usecols = -1, skip_header = 1)
						
						#The relative weight of the arc is equal to the average capacitance of the circuit for this time period
						weight = np.mean(capacitys)
						
						#Determe the nodes to connect from the filename:
						
						#Remove the file location from the filename (i.e. leaves nodeA-nodeB.txt).
						filename = (conection.split(os.sep)[-1])
						
						#removes file identifier from filename (i.e. leaves nodeA-nodeB (from-to))
						locations = (filename.split('.')[0])
						
						#Splits this on the '-' symbol to get the two node names
						[from_node,to_node] = (locations.split('-'))
						
						#retrieve the node that it is leaving and node it is going to
						node_from = self.get_node(from_node)
						node_to = self.get_node(to_node)
						
						#join these nodes
						self.join_nodes(node_from, node_to, weight)
						
					except:
					
						#allert user that a file has been excluded from conection calculations
						print('Conection data could not be retrieved from {}. File excluded from network calculations'.format(conection))
						pass
						
			else:
			
				#If connections folder not found nodes cannot be linked and network cannot be created therefore error generated
				print('error accessing {}. Connections folder not found'.format(directory+os.sep+'connections'))
				raise NetworkError
				
		else:
		
			#If the directory is not found no information on the network can be retrieved therefore error is generated
			print('error entering {}. Folder not found'.format(directory))
			raise NetworkError
		
		
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
