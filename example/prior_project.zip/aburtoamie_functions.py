import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob, iglob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
def test_client_func():
    pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
		test_client_func()
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		conn.wgt = weight
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			stations = ln.split(',')
			from_stat_name = stations[0]
			conns = stations[1:]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source_stat = self.query_station(from_stat_name)
			for conn in conns:
				[to_stat_name,weight_string] = conn.split(';')
				weight = float(weight_string)
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				destination_stat = self.query_station(to_stat_name)
				self.add_connection(source_stat,destination_stat,weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		if os.path.isdir(directory):
			files = glob(directory+os.sep+'*')
			for file in files:
				if os.path.isdir(file):
					if (file.split(os.sep)[-1]) != 'backbone':
						try:
							[name,x,y] = np.genfromtxt(fname = file+os.sep+'info.txt', delimiter = ': ', usecols = -1, dtype = str)
							self.add_station(name,[float(x),float(y)])
						except:
							print('data could not be retrieved from info.txt in {}. File excluded from grid'.format(file))
							pass
			if os.path.isdir(directory+os.sep+'backbone'):
				conections = glob(directory+os.sep+'backbone'+os.sep+'*')
				for conection in conections:
					try:
						capacitys = np.genfromtxt(fname = conection, delimiter = ', ', usecols = -1, skip_header = 1)
						weight = np.mean(capacitys)
						filename = (conection.split(os.sep)[-1])
						locations = (filename.split('.')[0])
						[from_stat,to_stat] = (locations.split('-'))
						stat_from = self.query_station(from_stat)
						stat_to = self.query_station(to_stat)
						self.add_connection(stat_from, stat_to, weight)
					except:
						print('Conection data could not be retrieved from {}. File excluded from grid calculations'.format(conection))
						pass
			else:
				print('error accessing {}. Connections folder not found'.format(directory+os.sep+'backbone'))
				raise GridError
		else:
			print('error entering {}. Folder not found'.format(directory))
			raise GridError
