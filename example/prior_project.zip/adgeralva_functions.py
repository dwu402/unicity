import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id=name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		conn.wgt = weight
		origin = self.query_station(stat_from.id)
		origin.cons_out.append(conn)
		destination = self.query_station(stat_to.id)
		destination.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			line = ln.split(',')
			conns = line[1:len(line)]
			originName = line[0]
			try:
				self.query_station(originName)
			except GridError:
				self.add_station(originName)
			source = self.query_station(originName)
			for conn in conns:
					destination = conn[0]
					weight = conn[2]
					conn = Connection()
					conn.wgt=weight
					conn.to_stat=destination
					conn.from_stat=source
					try:
						self.query_station(destination)
					except GridError:
						self.add_station(destination)
					source.cons_out.append(conn)
					self.query_station(destination).cons_out.append(conn)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		for name in glob(directory+'\*\info.txt'):	
			data = np.genfromtxt(name,dtype = str, delimiter = ': ')
			name = data[0,1]				
			value = (float(data[1,1]), float(data[2,1]))	
			self.add_station(name,value)				
		for name in glob(directory+'\connections\*.txt'):
			folders = name.split('\\')
			file = folders[2].split('.')
			stations = file[0].split('-')
			data = np.genfromtxt(name, float,'
			mean = np.sum(data[:,1])/len(data[:,1])
			try:
				self.query_station(stations[0])
			except GridError:
				self.add_station(stations[0])
			source = self.query_station(stations[0])
			try:
				self.query_station(stations[1])
			except GridError:
				self.add_station(stations[1])
			destination = self.query_station(stations[1])
			self.add_connection(source,destination,mean)
