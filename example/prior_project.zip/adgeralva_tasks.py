import numpy as np
A = np.genfromtxt('data.txt', dtype = float, delimiter = ",", skip_header = 1)
xs = A[:,0]
Ts = A[:,1]
from functions import*
grid = Grid()
grid.add_station('A', 2)
ndA = grid.query_station('A')
assert(ndA.id == 'A')
assert(ndA.val == 2)
grid.add_station('B', 3)
ndB = grid.query_station('B')
grid.add_connection(ndA,ndB,2)
assert(ndA.cons_out[0].to_stat.id == 'B')
assert(ndB.cons_in[0].from_stat.id == 'A')
assert(ndA.cons_out[0].wgt == 2)
grid = Grid()
grid.read('grid.txt')
grid.display()
