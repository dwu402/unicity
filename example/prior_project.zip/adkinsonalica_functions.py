import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name;
		stat.val = value;
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		conn.wgt = weight
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			data = ln.split(',')
			statFromName = data[0]
			statToNames = data[1:]
			try:
				statFrom = self.query_station(statFromName)
			except GridError:
				self.add_station(statFromName)
				statFrom = self.query_station(statFromName)
			for conn in statToNames:
				statToName,weight = conn.split(';')
				try:
					statTo = self.query_station(statToName)
				except GridError:
					self.add_station(statToName)
					statTo = self.query_station(statToName)
				self.add_connection(statFrom, statTo, weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		for dirName in os.listdir(directory):
			if dirName != 'backbone':
				fp = open(directory + os.sep + dirName + os.sep + 'info.txt')
				code = fp.readline().strip().split(' ')[1]
				x = int(fp.readline().strip().split(' ')[1])
				y = int(fp.readline().strip().split(' ')[1])
				self.add_station(code, [x,y])
		for fileName in os.listdir(directory + os.sep + 'backbone'):
			statFromName, statToName = fileName.strip('.txt').split('-')
			try:
				statTo = self.query_station(statFromName)
			except GridError:
				pass
			try:
				statFrom = self.query_station(statToName)
			except GridError:
				pass
			meanWeight = np.mean(np.genfromtxt(directory + os.sep + 'backbone' + os.sep + fileName
						                      ,delimiter=',',skip_header=1, autostrip=True, unpack=True)[1][:])
			self.add_connection(statFrom, statTo, meanWeight)
