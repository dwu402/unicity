# Task 1a: File I/O

import numpy as np
name = 'example_file.txt'
xs,Ts = np.genfromtxt(name, delimiter=',', skip_header=1, unpack=True)
print(xs)
print(Ts)