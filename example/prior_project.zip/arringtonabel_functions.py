import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
import re

class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []


class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None


class NetworkError(Exception):
	pass


class Network(object):
	def __init__(self):
		self.nodes = []
		self.arcs = []
		
	def get_node(self, name):
		""" Loops through the list of nodes and returns the one with NAME.
			Returns NetworkError if node does not exist.
		"""

		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError(f'Node "{name}" could not be found.')

	def display(self):
		""" Print information about the network.
		"""

		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))

		# print arcs
		for arc in self.arcs:
			print('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))

	def add_node(self, name, value=None):
		"""Adds a Node with NAME and VALUE to the network.
		"""

		# create a new Node and assign its properties
		node = Node()
		node.name = name
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)

		
	def join_nodes(self, node_from:Node, node_to:Node, weight):
		"""Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		"""

		# create a new arc and assign its properties
		arc = Arc()
		arc.weight = weight
		arc.from_node = node_from
		arc.to_node = node_to

		# append arc to the list of arcs
		self.arcs.append(arc)

		# update both nodes to store connectivity
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)

		
	def read_network(self, filename):
		"""Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			- the name of an origin node (first entry)
			- and destination;weight pairs (each pair separated by a comma)

		"""
		# open the text file describing the network
		with open(filename, 'r') as f:
			for line in f.readlines():
				# separate each line by ","
				parts = line.split(',')
				from_node_name = parts[0]

				# retrieve the from node from the network, creating it if it doesn't already exist
				if from_node_name not in (node.name for node in self.nodes):
					self.add_node(from_node_name)
				from_node = self.get_node(from_node_name)

				# the first part gave the start node name; each successive part gives the end node's name and the value
				# of their connection.
				for part in parts[1:]:
					[to_node_name, value] = part.split(';')

					# retrieve the from node from the network, creating it if it doesn't already exist
					if to_node_name not in (node.name for node in self.nodes):
						self.add_node(to_node_name)
					to_node = self.get_node(to_node_name)

					# join the from and to nodes with the value from the text file
					self.join_nodes(from_node, to_node, value)


class NetworkNZ(Network):
	""" Derived Network class, for NZ networks.
	"""	

	def read_network(self, directory):
		""" Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		"""
		# iterate through each station data file, using a glob wildcard
		for station_data_dir in glob(os.path.join(directory, '*', 'station_data.txt')):
			with open(station_data_dir) as f:
				station_data = ''.join(f.readlines())

				# use the re module to extract the code and x/y coordinates
				station_data_match = re.match(r'code: (.*)\nx: (.*)\ny: (.*)', station_data)
				(code,x,y) = station_data_match.groups()

				# add the node to the network
				self.add_node(code, (int(x),int(y)))

		# iterate through each connection data file, using a glob wildcard
		for conn_data_dir in glob(os.path.join(directory, 'connections', '*.txt')):
			with open(conn_data_dir) as f:
				# ignoring the first header, generate tuples corresponding to the first and second column of each row
				conn_data = (row.split(', ') for row in f.readlines()[1:])
				# convert the entries of the tuples to floats
				conn_data = map(lambda row: (float(row[0]), float(row[1])), conn_data)

				# noting that row[0] corresponds to the capacity, this expresion finds the row with the
				# most recent (highest) date
				most_recent_row = max(conn_data, key=lambda row: row[0])

				capacity = most_recent_row[1]

				# parse the filename of connection data file to get the from and to stations
				filename = os.path.basename(conn_data_dir)
				filename_match = re.match(r'(.*)-(.*).txt', filename)
				(from_station,to_station) = filename_match.groups()

				# get the nodes corresponding to the from and to stations then join them
				from_node = self.get_node(from_station)
				to_node = self.get_node(to_station)
				self.join_nodes(from_node, to_node, capacity)


	def show(self, save=None):
		""" Plot the network and optionally save to file SAVE
		"""
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
