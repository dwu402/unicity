import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
import re
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError(f'Station "{name}" could not be found.')
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from:Station, stat_to:Station, weight):
		conn = Connection()
		conn.wgt = weight
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		with open(filename, 'r') as f:
			for line in f.readlines():
				parts = line.split(',')
				from_stat_name = parts[0]
				if from_stat_name not in (stat.id for stat in self.stations):
					self.add_station(from_stat_name)
				from_stat = self.query_station(from_stat_name)
				for part in parts[1:]:
					[to_stat_name, value] = part.split(';')
					if to_stat_name not in (stat.id for stat in self.stations):
						self.add_station(to_stat_name)
					to_stat = self.query_station(to_stat_name)
					self.add_connection(from_stat, to_stat, value)
class Roads(Grid):
	def read(self, directory):
		for station_data_dir in glob(os.path.join(directory, '*', 'info.txt')):
			with open(station_data_dir) as f:
				station_data = ''.join(f.readlines())
				station_data_match = re.match(r'code: (.*)\nx: (.*)\ny: (.*)', station_data)
				(code,x,y) = station_data_match.groups()
				self.add_station(code, (int(x),int(y)))
		for conn_data_dir in glob(os.path.join(directory, 'backbone', '*.txt')):
			with open(conn_data_dir) as f:
				conn_data = (row.split(', ') for row in f.readlines()[1:])
				conn_data = map(lambda row: (float(row[0]), float(row[1])), conn_data)
				most_recent_row = max(conn_data, key=lambda row: row[0])
				capacity = most_recent_row[1]
				filename = os.path.basename(conn_data_dir)
				filename_match = re.match(r'(.*)-(.*).txt', filename)
				(from_station,to_station) = filename_match.groups()
				from_stat = self.query_station(from_station)
				to_stat = self.query_station(to_station)
				self.add_connection(from_stat, to_stat, capacity)
