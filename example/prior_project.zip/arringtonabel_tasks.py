import numpy as np
[XS, TS] = np.genfromtxt('data.txt', delimiter=',', unpack=True)
def seconnhable_function():
	pass
