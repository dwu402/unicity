import numpy as np
[XS, TS] = np.genfromtxt('example_file.txt', delimiter=',', unpack=True)

def searchable_function():

	# a comment
	# floders
	pass