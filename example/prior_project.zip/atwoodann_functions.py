import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			conns = ln.split(',')
			from_stat_name= conns[0]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			del conns[0]
			for Connection  in conns:
				destination, weight = Connection.split(';')
				try:
					self.query_station(destination)
				except GridError:
					self.add_station(destination)
				self.add_connection(self.query_station(from_stat_name), self.query_station(destination), weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		import fnmatch
		import os
		import glob
		def listdirs(folder):
			return [
				d for d in (os.path.join(folder, d1) for d1 in os.listdir(folder))
				if os.path.isdir(d)
			]
		listnames = listdirs(directory)
		for getpos in listnames:
			if getpos == 'roads_grid\\connections':
				print()
			else:
				coordinate = getpos+"\info.txt"
				statname = np.genfromtxt(coordinate, dtype = 'str', delimiter = ': ', unpack = True, usecols = 1)
				x,y = np.genfromtxt(coordinate, delimiter = ': ', skip_header=1, unpack = True, usecols = 1)
				value = [x,y]
				statnamefinal = statname[0]
				self.add_station(statnamefinal,value)
		conpos = directory+"\\connections"
		import os
		for file in os.listdir(conpos):
			if file.endswith(".txt"):
				statfrom = file[0:3]
				statto = file[4:7]
				import numpy
				capacity = np.genfromtxt((os.path.join(conpos, file)), delimiter = ', ', skip_header=1, unpack = True, usecols = 1)
				capacityWeight= (numpy.mean(capacity))
				self.add_connection(self.query_station(statfrom), self.query_station(statto), capacityWeight)
