import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			info = ln.split(',')
			source_stat = info[0]
			try:
				self.query_station(source_stat)
			except GridError:
				self.add_station(source_stat)
			stat_from = self.query_station(source_stat)
			conns = info[1:]
			for conn in conns:
				conn_info = conn.split(';')
				print(conn_info)
				weight = conn_info[1]
				destination_stat = conn_info[0]
				try:
					self.query_station(destination_stat)
				except GridError:
					self.add_station(destination_stat)
				stat_to = self.query_station(destination_stat)
				self.add_connection(stat_from, stat_to, weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		from glob import glob
		files = glob(directory+os.sep+'*'+os.sep+'info.txt')
		for file in files:
			fp = open(file, 'r')
			x, y = np.genfromtxt(file, delimiter=': ', dtype = str, unpack = True)
			source_stat_name = y[0]
			value = [int(y[1]),int(y[2])]
			self.add_station(source_stat_name, value)
			stat_from = self.query_station(source_stat_name)
		connections = glob(directory+os.sep+'backbone'+os.sep+'*')
		for connection in connections:
			modified_connection = (os.path.splitext(connection)[0])
			modified_connection = (os.path.split(modified_connection))
			modified_connection = modified_connection[1]
			modified_connection = modified_connection.split('-')
			year, capacity = np.genfromtxt(connection, delimiter=', ', skip_header = 1, dtype = float, unpack = True)
			weight = np.mean(capacity)
			stat_from = self.query_station(modified_connection[0])
			stat_to = self.query_station(modified_connection[1])
			self.add_connection(stat_from, stat_to, weight)
