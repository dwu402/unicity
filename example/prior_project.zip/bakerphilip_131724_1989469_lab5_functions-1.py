# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

#Given Methods
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	

                
class Network(object):
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# Create an empty node
		node = Node()
		# Assign a value to the new node
		node.value = value
		# Assign a name attribute to the new node
		node.name = name

		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# Create an empty arc
		arc = Arc()
		# Assign arc weigth
		arc.weight = weight
		# Assign node to be connected to
		arc.to_node = node_to
		# Assign node to be connected
		arc.from_node = node_from
		# Add the arc to the network
		self.arcs.append(arc)
		

		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		fp = open(filename, 'r')
		
		# get first line (a string)
		# - strip() is a useful method that removes white-space from the beginning and 
		#   end of the string
		ln = fp.readline().strip()
		while ln != '':        # keep looping to the end of the file
			# divide the string using the split() method for strings
			entries = []
			entries = ln.split(',')
			# - extract the source node
			from_node_name = entries[0]
			# - extract the remaining arcs
			arcs = []
			entries.pop(0)
			arcs = entries
	
			# if node doesn't exist, add to network
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(from_node_name)           
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(from_node_name)
				
			# get the source node OBJECT, using the source node STRING
			sourceNode = self.get_node(from_node_name)
				
			# read the arc information and add it to network
			for arc in arcs:
				# parse arc information
				destination = arc[0]
				weight = float(arc[2])
				
				# ___
				
				# get destination node object and link it to source node
				# ___
				try:
					destinationNode = self.get_node(destination)
				except NetworkError:
					self.add_node(destination)
				destinationNode = self.get_node(destination)
				self.join_nodes(sourceNode, destinationNode, weight)
								
			# get the next line
			ln = fp.readline().strip()
		
		
						

			
 
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	
	def read_network(self, directory):
		'''Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''

		files = glob(directory)

		for file in files:
			if os.path.isdir(file):
				subfiles = glob(file+os.sep+'*')
				for subfile in subfiles:
					if subfile != directory+os.sep+'connections':
						stations = glob(subfile+os.sep+'*')
						for station in stations:
							data = np.genfromtxt(station, dtype=str, delimiter =':')
							# Store the station code as a string
							code = data[0][1]
							code = code[1:]
							
							# Store Location as floating point numbers in a list
							location = [float(data[1][1]),float(data[2][1])]
							# Add the Station/Node to the Elextricity Network
							self.add_node(code, location)
				# Loop through the files in the directory using an if statement 
				# to find the connections folder 
				for subfile in subfiles:
					if subfile == directory+os.sep+'connections':
						connections = glob(subfile+os.sep+'*')
						for connection in connections:
							#Determain the nodes that are connected via the connection
							#curently being inspected.
							nodeFrom = connection.split(os.sep)[2].split('-')[0]
							nodeTo = connection.split(os.sep)[2].split('-')[1].split('.')[0]

							sumCapacities = 0
							# Read Connection Data from file 
							connectionData = np.genfromtxt(connection,dtype=float,delimiter=',',skip_header=1)
							# Calculate the mean  (average) capacitiy
							for i in range(len(connectionData)):
								values = connectionData[i]
								sumCapacities += values[1]
								averageCapacity = sumCapacities / len(connectionData)
							# Add the conection to the network, with the mean capacity as arc weigth
							self.join_nodes(self.get_node(str(nodeFrom)),self.get_node(str(nodeTo)),averageCapacity)

						
						

		
		

		
		
		
		
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
