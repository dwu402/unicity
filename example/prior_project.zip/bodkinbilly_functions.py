import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			stations = ln.split(',')
			stat_names = []
			weights = []
			stat_names.append(stations[0])
			for i in range(len(stations) - 1):
				i = i +1
				stat_names.append(stations[i].split(';')[0])
				weights.append(stations[i].split(';')[1])
			for i in range(len(stations)):  
				try:
					self.query_station(stat_names[i])
				except GridError:
					self.add_station(stat_names[i])
			for i in range(len(weights)):
				self.add_connection(self.query_station(stat_names[0]), self.query_station(stat_names[i+1]), weights[i])
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		from glob import glob
		slash = os.sep  
		if os.path.isdir(directory):
			folders = glob('{}{}*'.format(directory, slash))
			for i in range(len(folders)):	
				if folders[i] != '{}{}connections'.format(directory, slash):   
					fp = open('{}{}info.txt'.format(folders[i], slash),'r')
					firstline = fp.readline()
					code =(firstline.strip('code: *\n'))
					secondline = fp.readline()
					xval = (secondline.strip('x: *\n'))
					xval = int(xval)
					thirdline = fp.readline()
					yval = (thirdline.strip('y: *\n'))
					yval = int(yval)
					fp.close()
					self.add_station(code, [xval,yval])
			conFolders = glob('{}{}connections{}*'.format(directory, slash, slash))
			for i in range(len(conFolders)):	
				nod2nod = conFolders[i].strip('{}{}connections{}*.txt'.format(directory, slash, slash))
				from_stat, to_stat = nod2nod.split('-')
				capacities = np.genfromtxt('{}'.format(conFolders[i]), delimiter = ',', skip_header=1, usecols = (1), unpack = True )
				capacities = np.asarray(capacities)
				conWeight = np.mean(capacities)
				from_stat = self.query_station(from_stat)
				to_stat = self.query_station(to_stat)
				self.add_connection(from_stat, to_stat, conWeight)
		else :
			print('Directory not found')
