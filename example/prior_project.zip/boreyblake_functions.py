# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		# Return an error message if the node could not be found
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# Create an emoty node and assign its attributes
		node = Node()
		node.name = name
		# Default value is None
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# Create an emoty arc object and assign its attributes
		arc = Arc()
		arc.weight = weight
		arc.from_node = node_from
		arc.to_node = node_to
		
		# Append the arc to the source and destination nodes' list of arcs
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		
		# Append the arc to the list of arcs
		self.arcs.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			
			# split string into source node name and other arcs using split() method for strings
			line = ln.split(',')
			from_node_name = line[0]
			
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			sourceNode = self.get_node(from_node_name)
			
			# Creates a list of arc information
			arcs = line[1:]
			
			# read the arc information and add to network
			for arc in arcs:
				# Split the arc into destination node name and arc weight
				arc_info = arc.split(';')
				to_node_name = arc_info[0]
				arc_weight = int(arc_info[1])
				
				# Error check to make sure node exists else add it to the network
				try:
					self.get_node(to_node_name)
				except NetworkError:
					self.add_node(to_node_name)
					
				# get destination node object and link it to source node
				destinationNode = self.get_node(to_node_name)
				self.join_nodes(sourceNode, destinationNode, arc_weight)
						
			# get next line
			ln = fp.readline().strip()
		
		# Close the file
		fp.close()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		
		# Find all of the station_data.txt files within the subfolders of the main directory 'nz_network'
		station_data_files = glob(directory+os.sep+'*'+os.sep+'station_data.txt')
		
		# Loop through the station_data files
		for file in station_data_files:
			# Open the file
			fp = open(file, 'r')
				
			# Extracts the x and y coordinates of the node where the x coordinate is stored
			# in x_y[0] and the y coordinate in x_y[1]
			x_y = np.genfromtxt(file, delimiter = ': ', skip_header=1, usecols=(1), unpack=1)
			
			# Extracts the code from the header of the file
			ln = fp.readline().strip()
			x, code = ln.split(': ')
			
			# Add the node with the corresponding x and y values
			self.add_node(code, x_y)
				
			# Close the file
			fp.close()
			
		# Find all of the connection info files 
		connection_info_files = glob(directory+os.sep+'connections'+os.sep+'*')
		
		for file in connection_info_files:
			# Open the file
			fp = open(file, 'r')
			
			# Removes the path preceding the filename from the filename string
			source_destination = file.split(directory+os.sep+'connections'+os.sep)
			
			# Splits filename at the separator '-' and assigns the name of the source to arc_source
			arc_source, destination_txt = source_destination[1].split('-')
			
			# Removes '.txt' from the destination name and assigns the name of the destination to arc_destination
			arc_destination, x = destination_txt.split('.txt')
				
			# Splits the informtion in the file into two vectors which contain the year
			# and capacity respectively
			capacity = np.genfromtxt(file, delimiter=', ', skip_header=1, unpack=1, usecols=1)
				
			# Calculates the mean capacity
			mean_capacity = np.mean(capacity)
			
			# Get both nodes required to join together	
			sourceNode = self.get_node(arc_source)
			destinationNode = self.get_node(arc_destination)
			
			# Join these two nodes together with the arc weight equal to the mean capacity
			self.join_nodes(sourceNode, destinationNode, mean_capacity)
			
			# Close the file	
			fp.close()
		
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()