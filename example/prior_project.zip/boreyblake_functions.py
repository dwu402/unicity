import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			line = ln.split(',')
			from_stat_name = line[0]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			sourceStation = self.query_station(from_stat_name)
			conns = line[1:]
			for conn in conns:
				conn_info = conn.split(';')
				to_stat_name = conn_info[0]
				conn_weight = int(conn_info[1])
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				destinationStation = self.query_station(to_stat_name)
				self.add_connection(sourceStation, destinationStation, conn_weight)
			ln = fp.readline().strip()
		fp.close()
class Roads(Grid):
	def read(self, directory):
		station_data_files = glob(directory+os.sep+'*'+os.sep+'info.txt')
		for file in station_data_files:
			fp = open(file, 'r')
			x_y = np.genfromtxt(file, delimiter = ': ', skip_header=1, usecols=(1), unpack=1)
			ln = fp.readline().strip()
			x, code = ln.split(': ')
			self.add_station(code, x_y)
			fp.close()
		connection_info_files = glob(directory+os.sep+'backbone'+os.sep+'*')
		for file in connection_info_files:
			fp = open(file, 'r')
			source_destination = file.split(directory+os.sep+'backbone'+os.sep)
			conn_source, destination_txt = source_destination[1].split('-')
			conn_destination, x = destination_txt.split('.txt')
			capacity = np.genfromtxt(file, delimiter=', ', skip_header=1, unpack=1, usecols=1)
			mean_capacity = np.mean(capacity)
			sourceStation = self.query_station(conn_source)
			destinationStation = self.query_station(conn_destination)
			self.add_connection(sourceStation, destinationStation, mean_capacity)
			fp.close()
