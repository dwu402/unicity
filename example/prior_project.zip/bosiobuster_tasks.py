import numpy as np
Xs,Ts = np.genfromtxt('example_file.txt', dtype='float', delimiter = ',', skip_header=1, unpack=True);
