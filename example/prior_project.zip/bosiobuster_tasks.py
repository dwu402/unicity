import numpy as np
Xs,Ts = np.genfromtxt('data.txt', dtype='float', delimiter = ',', skip_header=1, unpack=True);
