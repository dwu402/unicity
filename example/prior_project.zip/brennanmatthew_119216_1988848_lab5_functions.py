# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint 1: how is an empty network object created in lab5_practice.py?**
		# **hint 2: take a look Section 0.6 in python101.ipynb, particularly attribute assignment**  
		# **hint 3: what values do the method arguments NAME and VALUE take when the method is called 
		#           in lab5_practice.py?**
		# **hint 4: what does the input argument 'self' represent in this method?**
				
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# create an empty network
		#create a node
		
		
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		# ___
		node = Node()
		node.name = name
		node.value = value
		# 3. THINK VERY CAREFULLY ABOUT WHAT THE NEXT COMMAND IS DOING
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both input nodes have lists called arcs_in and arcs_out.
		# **   - what information do these store?
		# **   - because they are lists, they can be modified using the append method
		
			
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		# ___
		#create a new arc object
		arc = Arc()
		#assign the from node and to node inputs to the arc attributes
		arc.from_node = node_from
		arc.to_node = node_to
		arc.weight = weight
		#add the arcs to the input nodes
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		#add the arc to the list of arcs
		self.arcs.append(arc)
		
		#fix how to input which data to store in each node and how to access the name of the node to add it to depending on whether its to of from
		
		# **delete the placeholder command below once you have written your code**
		
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''

		# 1. THE PSEUDOCODE FOR THIS METHOD HAS ALREADY BEEN WRITTEN BELOW
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		# - strip() is a useful method that removes white-space from the beginning and 
		#   end of the string
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# divide the string using the split() method for strings
			# - extract the source node
			# - extract the remaining arcs
			arcs = []
			#splits the string at the , and takes the first entry to get the source node
			source = ln.split(',')[0]
			#all the rest of the entries contain the useful information
			information = ln.split(',')[1:]
			#list through all the information and split the info through the ; to get the arc name
			for arc in information:
				arcs.append(arc.split(';'))
			
			# YOU WILL NEED TO THINK CAREFULLY ABOUT WHAT THIS TRY/EXCEPT BLOCK DOES
			# if node doesn't exist, add to network
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				sourcenode = self.get_node(source)           
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(source)
				
			sourcenode = self.get_node(source)

			# read the arc information and add it to network
			for arc in arcs: #for the length of the array arcs
				
				#get the actual nodes, the first element in each arc is the name
				try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
					destinationnode = self.get_node(arc[0])           
				except NetworkError:
				# this command gets executed if an error is raised above
				#cant assign a value since we dont know it 
					self.add_node(arc[0])
					destinationnode = self.get_node(arc[0])   
				weight = arc[1]
				#join the nodes to create arcs.
				self.join_nodes(sourcenode,destinationnode,weight)
			
				
				
				
			ln = fp.readline().strip()			
			# get next line
			
		
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		
		#Sets the initial directory to the directory inputted
		os.chdir(directory)
		#gets the name of all of the folders
		Folders = os.listdir() 
		#Checks each element in the Folders list. For all of them that arent the 'connections' folder, execute the following commands:
		#before adding arcs we want to add the nodes first. This is most easily done using the file names
		for Folder in Folders:
			if Folder != 'connections':
				#step the current directory back out of the input directory
				os.chdir('..')
				#enter the file directory of the current folder we're inspecting
				os.chdir(directory+os.sep+Folder)
				#glob will return the station_data file since no other files are in the folder
				StationData = glob('*')
				#Convert the file into useful information. This takes the first(and only) element of the glob and splits it at the :. This then only takes the 2nd column in the file
				#(The first column are headers) and stores each element as a string.
				data = np.genfromtxt(StationData[0],delimiter =': ', usecols=(1),dtype = str) #extracts the 2nd column of each line of the data file and puts it into an array
				#This takes the first element in the data array which is the name.
				StationName = data[0] 
				#Stores the coordinates of the station which are the next two data values and converts them to integers
				StationValues = [float(data[1]), float(data[2])]
				#adds the station as a node to the network
				self.add_node(StationName,StationValues)
				#step back out of our directory into the nz_network folder
				os.chdir('..')

		#Now all of the nodes have been added so step back into lap 5 andthen enter the connections folder		
		os.chdir('..')
		os.chdir(directory+os.sep+'connections')
		#creates a list of the files in the connections folder
		files = os.listdir()  
		for file in files:
			#splits the name of the file. The first entry in the name is the node its coming from and the second is the node its going to
			fromname,toname = file.split('-')
			#our second string will have a .txt in the filename so this must be removed
			toname = toname.strip('.txt')
			#skips the header line and reads the second column in the file after the comma which will give an array with all of the arc weights over the last 30 years
			data = np.genfromtxt(file, skip_header=1, delimiter =",", usecols=(1)) #gets the arc data
			#takes the average of this data
			average = np.average(data)	
			#get the nodes corresponding to the names of the nodes obtained previously
			from_node = self.get_node(fromname)
			to_node = self.get_node(toname)
			#join the nodes together to create arcs
			self.join_nodes(from_node,to_node,average)
			
		#step back to the original folder so a picture can be created. This might not be necessary depending on what function is run after this
		os.chdir('..\..')

	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
