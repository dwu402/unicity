# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob


# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass


# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.

		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node

		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))

	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**


		node = Node()  # Create a new empty Node() object
		node.name = name  # Assigns the name to the node
		node.value = value  #Assigns the value to the node

		# append node to the list of nodes
		self.nodes.append(node)

	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**


		arc = Arc()  #Creates a new empty Arc() object
		arc.weight = weight  # Assignment of arc weight
		arc.to_node = node_to   # Assigning node_to as the to_node for the arc
		arc.from_node = node_from  # As above for node_from

		#Appending the arc to the respective arcs_in and arcs_out for the node_to and node_from
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)

		#Append the arc to the list of arcs
		self.arcs.append(arc)


	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.

			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)

		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined

		# open the file
		fp = open(filename, 'r')

		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			arcs = None	#Initialisation of arcs array which holds the destination node and arc weight

			# Try to split the string to the source node and arcs otherwise let from_node_name be the complete string
			try:
				from_node_name, arcs = ln.split(",",1) # Splits the from_node from the arcs
				arcs = arcs.split(",") # Separate the arcs from each other

			except ValueError:
				from_node_name = ln # Assigns from_node_name as ln

			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)

			# get the source node object
			source_nd = self.get_node(from_node_name)

			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				to_node_name, arc_weight = arc.split(";") #Splits the to_node from the arc_weight
				arc_weight = float(arc_weight) #Converts string to float



				# get destination node object and link it to source node

				#If destination node doesn't exist, add to network
				try:
					self.get_node(to_node_name)
				except NetworkError:
					self.add_node(to_node_name)

				dest_nd = self.get_node(to_node_name)

				#Calling of join_nodes function to join nodes
				self.join_nodes(source_nd, dest_nd, arc_weight)

			# get next line
			ln = fp.readline().strip()

# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''

	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY

			Notes:
			------
			Assume that DIRECTORY contains one folder for
			connections between nodes. All other folders define
			the nodes of the network.

			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.

			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected
			(from-to) and the contents of the file record the capacity of
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''

		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir


		# Creates list of the folders in the directory folder
		ntwk_directory = glob(directory+os.sep+'*')


		#OBTAINING INFORMATION ABOUT NODES
		for folder in ntwk_directory:

			# Try to open the station_data.txt file inside folder to add nodes to the network, otherwise the folder is assigned as the folder for arcs
			try:
				fp = open(folder+os.sep+'station_data.txt','r') # Open the station_data.txt file
				values = [] # Initialisation of the values array
				ln = fp.readline().strip() # Gets the first line from txt file
				while ln is not '':        # Keeps looping to the end of the file
					label, data = ln.split(' ') # Splits the line to label and data(***: ### -> ***:,###)

					#Checks if the code is the code for the name of the node and assigns it as node name
					if (label.strip(':') == 'code'):
						node_name = data

					#Else appends the data onto the values array as an integer
					else:
						values.append(int(data))
					# Gets the next line
					ln = fp.readline().strip()
				fp.close() #Close the file
				self.add_node(node_name,values) #Adds the node to the network

			# Exception to catch to assign the folder as the folder for arcs
			except IOError:
				arcs = glob(folder+os.sep+'*')

		#OBTAINING INFORMATION ABOUT ARCS
		#Looping through each arc and assigning the weights for the arcs
		for arc in arcs:

			# Gets name of from and to nodes from the filename by using split and strip
			from_node_name, to_node_name = (arc.split(os.sep)[-1].strip('.txt').split('-'))

			# Gets the node object for assignments
			from_node = self.get_node(from_node_name)
			to_node = self.get_node(to_node_name)

			# Sorts data from file to vectors of time and capacity using np.genfromtxt
			time, capacity = np.genfromtxt(arc, skip_header=1, delimiter=",", unpack=True)

			# Assigning of weight to arc by using np.mean
			weight = np.mean(capacity)

			# Adds the arc to the network
			self.join_nodes(from_node,to_node,weight)



	# this method is complete, do not modify
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()

		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)

		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]

		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)

		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]

		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])

		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])

		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
