import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()  
		stat.id = name  
		stat.val = value  
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()  
		conn.wgt = weight  
		conn.to_stat = stat_to   
		conn.from_stat = stat_from  
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			conns = None	
			try:
				from_stat_name, conns = ln.split(",",1) 
				conns = conns.split(",") 
			except ValueError:
				from_stat_name = ln 
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source_nd = self.query_station(from_stat_name)
			for conn in conns:
				to_stat_name, conn_weight = conn.split(";") 
				conn_weight = float(conn_weight) 
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				dest_nd = self.query_station(to_stat_name)
				self.add_connection(source_nd, dest_nd, conn_weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		ntwk_directory = glob(directory+os.sep+'*')
		for folder in ntwk_directory:
			try:
				fp = open(folder+os.sep+'info.txt','r') 
				values = [] 
				ln = fp.readline().strip() 
				while ln is not '':        
					label, data = ln.split(' ') 
					if (label.strip(':') == 'code'):
						stat_name = data
					else:
						values.append(int(data))
					ln = fp.readline().strip()
				fp.close() 
				self.add_station(stat_name,values) 
			except IOError:
				conns = glob(folder+os.sep+'*')
		for conn in conns:
			from_stat_name, to_stat_name = (conn.split(os.sep)[-1].strip('.txt').split('-'))
			from_stat = self.query_station(from_stat_name)
			to_stat = self.query_station(to_stat_name)
			time, capacity = np.genfromtxt(conn, skip_header=1, delimiter=",", unpack=True)
			weight = np.mean(capacity)
			self.add_connection(from_stat,to_stat,weight)
