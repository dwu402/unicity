# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	

	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# creates an empty node object
		node = Node()
		# assigns a name and value to the new node
		node.name = name
		node.value = value

		# append node to the list of nodes
		self.nodes.append(node)
		

	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# creates an empty arc object
		arc = Arc()
		# assigns its attributes
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from

		# append the new arc to the list of existing arcs
		self.arcs.append(arc)
		# add the new arc to the from and to nodes
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''		
		# open the file
		fp = open(filename, 'r')
		# get first line (a string)
		ln = fp.readline().strip()

		while ln is not '':        # keep looping to the end of the file
			# divide the string using the split() method for strings
			ln = ln.split(',')		
			# extract the source node
			from_node_name = ln[0]
			# extract the remaining arcs
			arcs = ln
			del arcs[0]

			# if source node doesn't exist, add to network
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(from_node_name)           
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(from_node_name, None)
				
			# get the source node OBJECT, using the source node STRING
			from_node = self.get_node(from_node_name) 
				
			# read the arc information and add it to network
			for arc in arcs:
				# parse arc information
				arc = arc.split(';')
				to_node_name = arc[0]
				weight = float(arc[1])
				# if destination node doesn't exist, add to network
				try:
					# the output is a node object, the input is a string
					# this command raises an ERROR if the node DOESN'T exist
					from_node = self.get_node(to_node_name)           
				except NetworkError:
					# this command gets executed if an error is raised above
					self.add_node(to_node_name, None)

				# get destination node object and link it to source node
				to_node = self.get_node(to_node_name)
				self.join_nodes(from_node, to_node, weight)
						
			# get next line
			ln = fp.readline().strip()
			

# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		# find all folders in directory
		folder = glob(directory+os.sep+'*')
		for folder in folder:			# for each folder in the directory 
			# check if folder is a directory
			if os.path.isdir(folder):
				# check if folder contains a node info txt file
				subfiles = glob(folder+os.sep+'station_data.txt')
				if len(subfiles)>0:
					# open the txt file
					fp = open(folder+os.sep+'station_data.txt', 'r')

					# read the first three lines and seperate the row names from the values
					ln1 = fp.readline().strip().split(': ')
					ln2 = fp.readline().strip().split(': ')
					ln3 = fp.readline().strip().split(': ')

					# first line contains the node name, second and third lines contain the x and y values for the node weight
					node_name = ln1[1]
					node_weight = [float(ln2[1]), float(ln3[1])]

					# create a new node
					self.add_node(node_name, node_weight)

					# close the txt file
					fp.close()

		# find all txt files in the connection folder in directory
		files = glob(directory+os.sep+'connections'+os.sep+'*')
		weight = 0
		for file in files:			# for each file in the connection folder 
			# check if file is a file
			if os.path.isfile(file):
				# uses np.genfromtxt() to read data from the txt file
				data = np.genfromtxt(file, delimiter=", ", skip_header=True, names="time, capacity")
				# store the capacity data in c
				c = data['capacity']

				# calculates the average capacity to use as arc weight
				for i in c:
					weight += i
				weight = weight/len(c)	

				# removes everything other than the file name from the file path
				file = file.split('\\')[-1]
				file = file.split('.')[0]
				
				# finds the names of the from and to nodes based on the file name
				node_from = self.get_node(file.split('-')[0])
				node_to = self.get_node(file.split('-')[1])
				
				# create a new arc between nodes
				self.join_nodes(node_from, node_to, weight)

	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
