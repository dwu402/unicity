import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			iteration = ln.count(',')
			conns = [] * iteration
			conns = ln.split(',')
			try:
				self.query_station(conns[0])
			except GridError:
				self.add_station(conns[0])
			self.query_station(conns[0])
			head_stat = conns[0]
			name_stat = head_stat
			head_stat = Station()
			head_stat.id = name_stat
			conns.pop(0)
			for conn in conns:
				to_stat, weight = conn.split(';')
				name_to_stat = to_stat
				to_stat = Station()
				to_stat.id = name_to_stat
				self.add_connection(head_stat,to_stat,weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		a = os.path.isdir(directory)
		i = 0;
		if a is True:
			stat_lists = glob(directory+os.sep+'*')
			for stat_list in stat_lists:
				if stat_list != 'roads_grid'+os.sep+'backbone':
					stat_list = glob(stat_list+os.sep+'*')
					for i in stat_list:
						fid = open(i,'r')
						ln = fid.readline().strip()
						stat_name = ln.split(': ')[1]
						ln = fid.readline().strip()
						x = ln.split(": ")[1]
						x = int(x)
						ln = fid.readline().strip()
						y = ln.split(': ')[1]
						y = int(y)
						self.add_station(stat_name,[x,y])
						ln = fid.readline().strip()
			stat_lists = glob(directory+os.sep+'backbone'+os.sep+'*')
			for conn in stat_lists:
				useless1,useless2,name = conn.split('\\')
				stat_connection,useless = name.split('.')
				from_stat,to_stat = stat_connection.split('-')
				useless3, capacity = np.genfromtxt(conn, delimiter = ',', skip_header=1, unpack=True)
				weight = np.mean(capacity) 
				self.add_connection((self.query_station(from_stat)),(self.query_station(to_stat)), weight)
