# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		
		# create an empty node object
		node = Node()
		
		# assign a name and value to the node
		node.name = name
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		
		# create an empty arc object
		arc = Arc()
		
		# set a pointer to a source node and destination node of the arc
		arc.from_node = node_from
		arc.to_node = node_to
		
		# assign a weight to the arc
		arc.weight = weight
		
		self.arcs.append(arc) # append arc to the list of arcs (total arcs)
		node_from.arcs_out.append(arc) # append arc to the list of arcs entering the source node
		node_to.arcs_in.append(arc) # append arc to the list of arcs exiting the destination node
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			
			# split string into source node name and other arcs using split() method for strings
			# but if there are no other arcs, the source node name is the line obtained and the arcs list is empty
			try:
				from_node_name, arcs = ln.split(',', 1) # separate source node name from other arcs
				arcs = arcs.split(',') # separate each arc
			except:
				from_node_name = ln
				arcs = []
			
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			source = self.get_node(from_node_name)
				
			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				to_node_name, weight = arc.split(';') # split string into destination node name and weight of the arc
				
				# get destination node object
				try:
					self.get_node(to_node_name)
				except NetworkError:
					self.add_node(to_node_name)
				destination = self.get_node(to_node_name)
				
				# link the destination node to the source node
				self.join_nodes(source, destination, weight)
						
			# get next line
			ln = fp.readline().strip()
			
		# close the file
		fp.close()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		
		# create a list of subfolders, i.e. folders in nz_network (eg. Bunnythorpe, connections)
		subfolders = glob(directory+os.sep+'*')

		# obtain information from each subfolder
		for subfolder in subfolders:
			# if the subfolder is named 'connections', create a list of connections.
			# otherwise, add nodes (stations) to the network
			if subfolder == directory+os.sep+'connections': 
				con_files = glob(subfolder+os.sep+'*') # create a list of connection files (eg. BPE-HAY.txt)
				con_dir = subfolder # assign connection pathway to variable (for later use)
			else:
				stat_file = glob(subfolder+os.sep+'*')
				fp = open(stat_file[0], 'r') # open the file
				ln = fp.readline().strip() # read the first line
				data = [] # create an empty list
				
				while ln is not '': # loop until the end of the file is reached
					data.append(ln.split(': ')[-1]) # split the string and append the last element to the list of data
					ln = fp.readline().strip() # get the next line
				
				# assign code name and x-y coordinates to separate variables
				code = data[0]
				xy = [float(data[1]), float(data[2])] 
				
				# if node doesn't exist, add to network
				try:
					self.get_node(code)
				except NetworkError:
					self.add_node(code, xy)
				
				# close the file	
				fp.close() 

		for con_file in con_files:
		
			# read data from connection textfiles
			time, cap = np.genfromtxt(con_file, dtype = float, delimiter = ",", skip_header = 1, unpack = True)
			
			# calculate the mean capacity
			mean = sum(cap) / len(cap)
			
			# remove parts of the string and split the remaining string to separate the source and destination
			con_file = con_file.strip(con_dir)
			from_node_name, to_node_name = con_file.strip('.txt').split('-')		
			
			# get source and destination node, and link them
			src = self.get_node(from_node_name)
			des = self.get_node(to_node_name)
			self.join_nodes(src, des, mean)
			
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
