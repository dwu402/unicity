import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		conn.wgt = weight
		self.connections.append(conn) 
		stat_from.cons_out.append(conn) 
		stat_to.cons_in.append(conn) 
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			try:
				from_stat_name, conns = ln.split(',', 1) 
				conns = conns.split(',') 
			except:
				from_stat_name = ln
				conns = []
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source = self.query_station(from_stat_name)
			for conn in conns:
				to_stat_name, weight = conn.split(';') 
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				destination = self.query_station(to_stat_name)
				self.add_connection(source, destination, weight)
			ln = fp.readline().strip()
		fp.close()
class Roads(Grid):
	def read(self, directory):
		subfolders = glob(directory+os.sep+'*')
		for subfolder in subfolders:
			if subfolder == directory+os.sep+'backbone':
				con_files = glob(subfolder+os.sep+'*') 
				con_dir = subfolder 
			else:
				stat_file = glob(subfolder+os.sep+'*')
				fp = open(stat_file[0], 'r') 
				ln = fp.readline().strip() 
				data = [] 
				while ln is not '': 
					data.append(ln.split(': ')[-1]) 
					ln = fp.readline().strip() 
				code = data[0]
				xy = [float(data[1]), float(data[2])]
				try:
					self.query_station(code)
				except GridError:
					self.add_station(code, xy)
				fp.close()
		for con_file in con_files:
			time, cap = np.genfromtxt(con_file, dtype = float, delimiter = ",", skip_header = 1, unpack = True)
			mean = sum(cap) / len(cap)
			con_file = con_file.strip(con_dir)
			from_stat_name, to_stat_name = con_file.strip('.txt').split('-')
			src = self.query_station(from_stat_name)
			des = self.query_station(to_stat_name)
			self.add_connection(src, des, mean)
