# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob


# these classes and methods are complete, do not modify them
class Node(object):
    def __init__(self):
        self.name = None
        self.value = None
        self.arcs_in = []
        self.arcs_out = []

    def __repr__(self):
        return 'nd:{}'.format(self.name)


class Arc(object):
    def __init__(self):
        self.weight = None
        self.to_node = None
        self.from_node = None

    def __repr__(self):
        return '{} -> {}'.format(self.to_node.name, self.from_node.name)


class NetworkError(Exception):
    '''An error to raise when violations occur.
	'''
    pass


# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
    ''' Basic network class.
	'''

    # these methods are complete, do not modify them
    def __init__(self):
        self.nodes = []
        self.arcs = []

    def __repr__(self):
        return 'ntwk'

    def get_node(self, name):
        ''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
        # loop through list of nodes until node found
        for node in self.nodes:
            if node.name == name:
                return node

        raise NetworkError

    def display(self):
        ''' Print information about the network.
		'''
        # print nodes
        print('network has {:d} nodes: '.format(len(self.nodes)) + (len(self.nodes) * '{}, ').format(
            *(nd.name for nd in self.nodes)))
        # print arcs
        for arc in self.arcs:
            print('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))

    # **these methods are incomplete, you must complete them as part of the lab task**
    def add_node(self, name, value=None):
        '''Adds a Node with NAME and VALUE to the network.
        '''

        #generate new node, assign input attributes to node
        nd = Node()
        nd.name = name
        nd.value = value
        self.nodes.append(nd) #add node to network nodes list

    def join_nodes(self, node_from, node_to, weight):
        '''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
        #generate arc, assign arc attributes from inputs.
        arc = Arc()
        arc.from_node = node_from
        arc.to_node = node_to
        arc.weight = weight

        #link origin and destination nodes
        node_from.arcs_out.append(arc)
        node_to.arcs_in.append(arc)
        self.arcs.append(arc) #register arc with network

    def read_network(self, filename):

        # open the file
        fp = open(filename, 'r')
        # get first line (a string), strip whitespace from start/end of string
        ln = fp.readline().strip()

        while ln is not '':  # keep looping to the end of the file
            head_to_dest= ln.split(',') #store each node as a string in a list
            from_node_name= head_to_dest[0] #origin node

            #check if node is registered in network; if not, add node to network
            try:
                from_node = self.get_node(from_node_name)
            except NetworkError:
                self.add_node(from_node_name)

            #loop through each value in generated list of nodes after the first.
            for i in range(1, len(head_to_dest)):
                temp= head_to_dest[i]
                dest, weight= temp.split(';') #separate destination nodes from weight

                #check if nodes are registered in network, adds if not.
                try:
                    from_node = self.get_node(dest)
                except NetworkError:
                    self.add_node(dest)
                #calls join_node method to join origin and destination nodes with given weight
                self.join_nodes(self.get_node(head_to_dest[0]), self.get_node(dest), float(weight))
            #get new line
            ln = fp.readline().strip()

# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):

    def read_network(self, directory):
        #check if directory exists, if doesnt, code passes
        if os.path.isdir(directory) is False:
            pass
        #get list of folders
        folders= glob(directory + '\\*')
        #loop through folders, ignoring the connections folder.
        for folder in folders:
            #get data from file, throwing away the start labels
            if folder!= (directory + '\\connections'):
                throwaway, details = np.genfromtxt(folder + '\\station_data.txt', delimiter=': ', unpack=True, dtype=str)
                #adding node to network
                coord = (float(details[1]), float(details[2]))
                self.add_node(details[0], coord)

        #get list of connections files
        connectionsList = glob(directory + '\\connections' + '\\*')
        #loop through connections, getting only capacity data from files, then averaging it.
        for name in connectionsList:
            capacity = np.genfromtxt(name, skip_header=1, delimiter=',', usecols=1)
            meanCapacity = np.mean(capacity)
            #getting the origin and destination nodes from the name of file
            titles = name.strip('nz_network\\connections\\' + '.txt')
            from_node, to_node = titles.split('-')
            #create arc
            self.join_nodes(self.get_node(from_node), self.get_node(to_node), meanCapacity)


    # this method is complete, do not modify
    def show(self, save=None):
        ''' Plot the network and optionally save to file SAVE
		'''
        # create figure axes
        fig = plt.figure()
        fig.set_size_inches([10, 10])
        ax = plt.axes()

        # NZ coastline as background
        img = mpimg.imread('bg.png')
        ax.imshow(img, zorder=1)

        # a filthy hack to get coordinates in the right spot...
        for node in self.nodes:
            x, y = node.value
            y = int((y + 10) * 1.06)
            x -= int(50 * y / 800.)
            node.value = [x, y]

        # draw nodes as text boxes with station names
        # bounding box properties
        props = dict(boxstyle='round', facecolor='white', alpha=1.0)
        for node in self.nodes:
            # extract coordinates
            x, y = node.value
            ax.text(x, y, node.name, ha='center', va='center', zorder=2, bbox=props)

        # draw connections as lines
        weights = [arc.weight for arc in self.arcs]
        # scale for plotting connections
        wmin = np.min(weights)
        wmax = np.max(weights)
        lmin, lmax = [0.5, 10.0]

        # plot connections
        for arc in self.arcs:
            # compute line length, scales with connection size
            lw = (arc.weight - wmin) / (wmax - wmin) * (lmax - lmin) + lmin
            x1, y1 = arc.from_node.value
            x2, y2 = arc.to_node.value
            ax.plot([x1, x2], [y1, y2], '-', lw=lw, color=[0.6, 0.6, 0.6])

        # remove ticks
        ax.set_xticks([])
        ax.set_yticks([])

        # display options
        if save:
            # save to file
            plt.savefig(save, dpi=300)
            plt.close()
        else:
            # open figure window in screen
            plt.show()
