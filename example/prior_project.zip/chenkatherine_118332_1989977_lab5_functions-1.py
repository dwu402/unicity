# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = NotImplemented
		self.previous = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.from_node.name,self.to_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''

		# **to do: create an empty node object, assign its attributes**
		# **hint 1: how is an empty network object created in lab5_practice.py?**
		# **hint 2: take a look Section 0.6 in python101.ipynb, particularly attribute assignment**  
		# **hint 3: what values do the method arguments NAME and VALUE take when the method is called 
		#           in lab5_practice.py?**
		# **hint 4: what does the input argument 'self' represent in this method?**
				
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# (see notebook)
		
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE

		node = Node() 		# creates an emty node object
		node.name = name 		# assigning the name and value attributes
		node.value = value 		

		node.arcs_in = []		# initialisation: creates an arcs_in and arcs_out array under 'node'
		node.arcs_out = []	
				
		# 3. THINK VERY CAREFULLY ABOUT WHAT THE NEXT COMMAND IS DOING
		self.nodes.append(node) # append node to the list of nodes

		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.'''

		# **to do: create an empty arc object, assign its attributes**
		# **hint: both input nodes have lists called arcs_in and arcs_out.
		# **   - what information do these store?
		# **   - because they are lists, they can be modified using the append method
		
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# (see notebook)
				
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE

		arc = Arc()						# creates an emty arc object
		arc.from_node = node_from		# assigns the node to, nodes from, and weight attributes
		arc.to_node = node_to			
		arc.weight = weight

		node_from.arcs_out.append(arc)	# modify the input node arguments to be associated with the arc created 
		node_to.arcs_in.append(arc)		

		# append this arc to the list of arcs; save it to the Network object
		self.arcs.append(arc)
		
		# **delete the placeholder command below once you have written your code**
		#pass
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination node pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split

		# 1. THE PSEUDOCODE FOR THIS METHOD HAS ALREADY BEEN WRITTEN BELOW
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		# - strip() is a useful method that removes white-space from the beginning and 
		#   end of the string

		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# divide the string using the split() method for strings
			# - extract the source node
			# - extract the remaining arcs

			string1 = ln.split(',')			# separates the line into a string
			nodename = string1[0]		# set first element of each line as the name of the node
			arcs = string1[1:]				# set the rest of the elements as a list containing linked nodes and their weight
			
			# YOU WILL NEED TO THINK CAREFULLY ABOUT WHAT THIS TRY/EXCEPT BLOCK DOES
			# if node doesn't exist, add to network
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(nodename)           
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(nodename)
				
			# get the source node OBJECT, using the source node STRING
			from_node = self.get_node(nodename)

			# read the arc information and add it to network
			for arc in arcs:
				# parse arc information
				# strip 
				
				string2 = arc.split(';')	# separate the names of the linking nodes with their respective weights via ';'

				try:
					to_node = self.get_node(string2[0])     # get destination node object and link it to source node      
				except NetworkError:
				## If not, append the first element as the name of the linking node
					self.add_node(string2[0])

				# Create a list containing all of the names of the linking nodes
				name1 = self.get_node(string2[0])
				
				# creates an arc using the join_node function
					# Inputs: - from_node = nodes coming into arc
					#		  - name1 = nodes coming out of the arc
					#		  - string2[1] = second element of string2 containing the arc weights
				self.join_nodes(from_node, name1, string2[1])

				# delete the placeholder command below when you start writing your code
				#pass
						
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''

		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir

		# initialisation of arrays
		array = []
		data = []

		files = glob('nz_network'+os.sep+ '*') # finds all the pathnames from nz_network to determine the x and y coordinates
												# as well as the name of the nodes
		for filename in files:
			if filename != 'nz_network'+os.sep+'connections': # extract data from all files except from the 'connections' file 
				array = np.genfromtxt(filename+os.sep+'station_data.txt', dtype = str, delimiter = ' ').T # loads all files from nz_network and puts them in a list
				data = array[1,:]		# create a variable from the second row of the list which contains the useful data of the file 
				self.add_node(data[0], [int(data[1]), int(data[2])]) # calls the add_node function that takes in the name and the values of each node
	
		final = glob('nz_network'+os.sep+'connections'+os.sep+'*.txt') # finds all the weight of arcs in 'connections' file

		for output in final:
			readdata = np.genfromtxt(output, dtype = float, delimiter = ', ', skip_header = 1).T # loads all the files from 'connections'
			capacity = readdata[1] # gets the capactiy (second column of readdata)
			mean = (capacity.sum())/(capacity.size) # calculates the mean by taking the sum of the numbers in capacity divided by the lenght of the list

			readdata2 = os.path.split(output) # obtains the last pathname component of 'output'
			#print(os.path.split(readdata2))
			name = readdata2[1] 
			readdata3 = os.path.splitext(name) # obtains the last pathname component of of 'name'
			#print(os.path.splitext(name))
			location = readdata3[0]
			a,b = location.split("-") # splits the data into two lists containing their respective nodes
			self.join_nodes(self.get_node(a), self.get_node(b), mean) # apply the join_node function to create arcs with their respective weights

		
		# **delete the placeholder command below once you have written your code**
		# pass
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
	
