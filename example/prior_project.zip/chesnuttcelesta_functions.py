import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
from io import BytesIO
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		conn.wgt = weight
		stat_change = self.query_station(stat_from.id) 
		stat_change.cons_out.append(conn) 
		stat_change = self.query_station(stat_to.id) 
		stat_change.cons_in.append(conn) 
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			splitStations = ln.split(",")
			from_stat_name = splitStations[0]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source_stat = self.query_station(from_stat_name)
			conns = []
			for i in range(1, len(splitStations)):
				conns.append(splitStations[i])
			for conn in conns:
				conn_details = conn.split(';')
				to = conn_details[0]
				try:
					self.query_station(to)
				except GridError:
					self.add_station(to)
				weight = conn_details[1]
				to_stat = self.query_station(to)
				self.add_connection(source_stat, to_stat, weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		stat_files = glob(directory+'\*')
		for file in stat_files:
			if file == 'roads_grid\connections': 
				continue
			if os.path.isdir(file) == False: 
				continue
			fp = open(file+'\info.txt', 'r') 
			ln = fp.readline().strip()
			while ln is not '': 
				ln = ln.split(' ')
				if ln[0] == 'code:':
					self.add_station(ln[1]) 
					created_stat = self.query_station(ln[1]) 
				if ln[0] == 'x:':
					x = float(ln[1]) 
				if ln[0] == 'y:':
					y = float(ln[1]) 
				ln = fp.readline().strip()	
			created_stat.val = [x,y] 
		conn_files = glob(directory+'\connections\*.txt')
		for file in conn_files:
			weights = np.genfromtxt(file, delimiter =',', skip_header = 1, unpack = True, usecols = 1)
			mean_weight = np.mean(weights) 
			dir_length = len(directory) 
			connection = file[dir_length + 13: -4] 
			from_stat = connection[0:3] 
			to_stat = connection[4:7] 
			from_stat = self.query_station(from_stat)
			to_stat = self.query_station(to_stat)
			self.add_connection(from_stat, to_stat, mean_weight)
