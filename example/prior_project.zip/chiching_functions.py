import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
    def __init__(self):
        self.id = None
        self.val = None
        self.cons_in = []
        self.cons_out = []
class Connection(object):
    def __init__(self):
        self.wgt=None
        self.to_stat = None
        self.from_stat = None
class GridError(Exception):
    pass
class Grid(object):
    def __init__(self):
        self.stations = []
        self.connections = []
    def query_station(self, name):
        for stat in self.stations:
            if stat.id == name:
                return stat
        raise GridError
    def add_station(self, name, value=None):
        stat = Station()
        stat.id = name
        stat.val = value
        self.stations.append(stat)
    def add_connection(self, stat_from, stat_to, weight):
        conn = Connection()
        conn.from_stat = stat_from
        conn.to_stat = stat_to
        conn.wgt = weight
        stat_from.cons_out.append(conn)
        stat_to.cons_in.append(conn)
        self.connections.append(conn)
    def read(self, filename):
        fp = open(filename, 'r')
        ln = fp.readline().strip()
        while ln is not '':        
            ln = ln.split(',')
            from_stat_name = ln[0]
            conn_list = ln[1:]
            try:
                self.query_station(from_stat_name)
            except GridError:
                self.add_station(from_stat_name)
            from_stat = self.query_station(from_stat_name)
            for this_conn in conn_list:
                end_stat_name, conn_weight = this_conn.split(';')
                try:
                    self.query_station(end_stat_name)
                except GridError:
                    self.add_station(end_stat_name)
                end_stat = self.query_station(end_stat_name)
                self.add_connection(from_stat, end_stat, conn_weight)
            ln = fp.readline().strip()
class Roads(Grid):
    def read(self, directory):
        dirlist = glob(directory+'/*')
        for folder_name in dirlist:
            if folder_name == 'roads_grid/connections':
                continue
            if os.path.isdir(folder_name) == False:
                continue
            fp = open(folder_name+'/info.txt', 'r')
            ln = fp.readline().strip()
            while ln is not '':        
                ln = ln.split(' ')
                if ln[0] == 'code:':
                    self.add_station(ln[1])
                    current_stat = self.query_station(ln[1])
                if ln[0] == 'x:':
                    x = float(ln[1])
                if ln[0] == 'y:':
                    y = float(ln[1])
                ln = fp.readline().strip()
            current_stat.val = [x,y]
        connectlist = glob(directory+'/connections/*.txt')
        for connection_name in connectlist:
            (T,C) = np.genfromtxt(connection_name, delimiter=',', skip_header=1, unpack=True)
            connectionvalue = np.mean(C)
            current_connection = connection_name.replace('roads_grid/connections/','')
            current_connection = current_connection.replace('.txt','')
            current_connection = current_connection.split('-')
            stat_from_connection = self.query_station(current_connection[0])
            stat_to_connection = self.query_station(current_connection[1])
            self.add_connection(stat_from_connection,stat_to_connection,connectionvalue)
