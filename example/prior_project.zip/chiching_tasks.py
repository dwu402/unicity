import numpy as np
(x,T) = np.genfromtxt('example_file.txt', delimiter=',', skip_header=1, unpack=True)
