import numpy as np
(x,T) = np.genfromtxt('data.txt', delimiter=',', skip_header=1, unpack=True)
