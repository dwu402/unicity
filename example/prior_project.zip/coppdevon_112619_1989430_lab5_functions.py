# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint 1: how is an empty network object created in lab5_practice.py?**
		# **hint 2: take a look Section 0.6 in python101.ipynb, particularly attribute assignment**  
		# **hint 3: what values do the method arguments NAME and VALUE take when the method is called 
		#           in lab5_practice.py?**
		# **hint 4: what does the input argument 'self' represent in this method?**
				
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# **your pseudocode here**
		
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		node = Node()  #Creating empty node
		node.name = name #Assigning specified name to the node
		node.value = value #Assigning specified value to node
		
				
		# 3. THINK VERY CAREFULLY ABOUT WHAT THE NEXT COMMAND IS DOING
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both input nodes have lists called arcs_in and arcs_out.
		# **   - what information do these store?
		# **   - because they are lists, they can be modified using the append method
		
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# ___
				
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		# ___
		arc = Arc() #Creating empty arc
		arc.from_node = node_from #Assigning attributes
		arc.to_node = node_to
		arc.weight = weight

		node_from.arcs_out.append(arc) #Assigning attributes
		node_to.arcs_in.append(arc)

		self.arcs.append(arc) #Appending arc to list of arcs



		# **delete the placeholder command below once you have written your code**
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination node pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
		
		# 1. THE PSEUDOCODE FOR THIS METHOD HAS ALREADY BEEN WRITTEN BELOW
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		# - strip() is a useful method that removes white-space from the beginning and 
		#   end of the string
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# divide the string using the split() method for strings
			# - extract the source node
			# - extract the remaining arcs
			# ___

			temp = ln.split(',') #Creating temp String list split by ',' from string extracted from line of file
			from_node_name = temp[0] #Extracting from node name
			arcs = [] #creating empty lists to prepare to store arc data
			arc = []

			for i in range(1,len(temp)): #For loop to loop over remaining strings in temp
				arc = temp[i].split(';') #extracting specific arc data in the form ['to_node', 'weight'] via split(;)
				arcs.append(arc) #appending arc data list to the list of arcs (Creates list of lists)
				

		   
			# YOU WILL NEED TO THINK CAREFULLY ABOUT WHAT THIS TRY/EXCEPT BLOCK DOES
			# if node doesn't exist, add to network
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(from_node_name)           
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(from_node_name)
			# get the source node OBJECT, using the source node STRING
			from_node = self.get_node(from_node_name) 
				
			# read the arc information and add it to network
			for arc in arcs: #for loop loops over each list inside the "arcs" list
				# parse arc information
				self.add_node(arc[0]) #adding the to node
				# get destination node object and link it to source node
				to_node = self.get_node(arc[0]) #assigning the to node to a variable
				self.join_nodes(from_node, to_node, arc[1]) #joining nodes via an arc with specified weight
				


			ln = fp.readline().strip() #getting next line
		
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir

		direct = glob(directory+os.sep+'*') #Using glob command to get a list of files in specified directory


		for i in range(len(direct)): #for loop to cycle through each folder in directory

			if direct[i] == (directory+os.sep+'connections'): #Skip over connection folder for later use
				pass
			else:
				fp = open(direct[i]+os.sep+'station_data.txt', 'r') #open the station data
				ln = fp.readline().split(':')  #Getting line and splitting over ':'
				nodename = ln[1].strip() #Grabbing node name from relevant string from split; removing white space
				ln = fp.readline() #Grabbing new line in preperation for while loop
				nodevalue = [] #Creating empty list for multiple node values


				while ln is not '': #while loop to cycle through rest of text file, stopping at the end
					ln = ln.split(':')[1].strip() #grabbing node value component via split and index
					nodevalue.append(float(ln)) #turning node value into floating point and appending to list of node values
					ln = fp.readline() #getting next line to continue while loop


				self.add_node(nodename, nodevalue) #adding node with attributes name and value

		connectionFolder = glob(directory+os.sep+'connections'+os.sep+'*') #Getting list of strings of all the paths to files in connections folder
		for i in range(len(connectionFolder)): #Looping over all files in the connections folder
			temp = connectionFolder[i].split('\\')[2] #Splitting path to files and extracting onnection text file name with extension
			temp = temp.split('.txt') #using split to remove extension
			temp = temp[0].split('-') #splitting string into two strings with from node in index [0], and to node in index [1]
			from_node = self.get_node(temp[0]) #getting from node data from network and storing in variable
			to_node = self.get_node(temp[1]) #getting to node data from network and storing in variable

			#genfromtxt produces an array of data values. Specifically in this case the capacity values for the connections between the
			# stations. The header is skipped and time data is ignored via a delimiter to produce clean capacity data in an array.
			capacity = np.genfromtxt(skip_header = 1,fname = connectionFolder[i],delimiter = ',').T 
			
			averageCapacity = sum(capacity[1])/len(capacity[1]) #Calculating average capacity, the weight attribute between nodes in the form of an arc

			self.join_nodes(from_node,to_node,averageCapacity) #Creating arc between nodes






		
		# **delete the placeholder command below once you have written your code**
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
