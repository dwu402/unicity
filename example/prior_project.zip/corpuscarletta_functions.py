import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			try:
				array = ln.split(',')
				sourceStation = array[0]
				conns = array[1:]
			except:
				sourceStation = ln
				conns = []
			try:
				self.query_station(sourceStation)
			except GridError:
				self.add_station(sourceStation)
			source_stat = self.query_station(sourceStation)
			for conn in conns:
				point_to_stat, weight = conn.split(';')
				try:
					destination_stat = self.query_station(point_to_stat)
				except GridError:
					self.add_station(point_to_stat)
				destination_stat_stat = self.query_station(point_to_stat)
				self.add_connection(source_stat, destination_stat_stat, weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		files = glob(directory+os.sep+'*')
		for file in files:                 
			if os.path.isdir(file) and os.path.basename(file)!=('backbone'):
				code_name, x, y = np.genfromtxt(file+os.sep+'info.txt', dtype = (str), delimiter = ': ', usecols = 1, unpack = True)
				self.add_station(code_name, [int(x), int(y)])
		files = glob(directory+os.sep+'backbone'+os.sep+'*')  
		for file in files:
			conn_direction = os.path.basename(file)
			conn_direction = conn_direction.rstrip('.txt')     
			from_stat, to_stat = conn_direction.split('-')
			from_stat = self.query_station(from_stat)
			to_stat = self.query_station(to_stat)
			connection_weight = np.genfromtxt(file, skip_header=1, usecols=1)
			connection_weight = np.sum(connection_weight)/len(connection_weight)          
			self.add_connection(from_stat, to_stat, connection_weight)  
