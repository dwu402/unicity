# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint 1: how is an empty network object created in lab5_practice.py?**
		# **hint 2: take a look Section 0.6 in python101.ipynb, particularly attribute assignment**  
		# **hint 3: what values do the method arguments NAME and VALUE take when the method is called 
		#           in lab5_practice.py?**
		# **hint 4: what does the input argument 'self' represent in this method?**
				
			# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# **your pseudocode here**
		# call Node() as node
        # assign node.name = name 
        # assign node.value = value
	

		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		# ___
		node = Node()					#Call an instance of Node
		node.name = name				#assign the the attributes of the node (name and value)
		node.value = value
				
		# 3. THINK VERY CAREFULLY ABOUT WHAT THE NEXT COMMAND IS DOING
		# append node to the list of nodes
		self.nodes.append(node)			#add newly created node object to the list of nodes in the current(self) network
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both input nodes have lists called arcs_in and arcs_out.
		# **   - what information do these store?
		# **   - because they are lists, they can be modified using the append method
		
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# ___
		#Define arc as Arc()
		#Define weights, to_node, from_node
		#Add arc to arcs_out of node_from
		#Add arc to arc_in of node_to
		#Add arc to list of arcs in networt (self.arcs)
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		# ___
		arc = Arc()								#call an instance of Arc()
		arc.weight = weight						
		arc.to_node = node_to					#assign the attributes of the arc (weight, to and from nodes)
		arc.from_node = node_from				

		node_from.arcs_out.append(arc)			#add arc object to arcs out list of the from node
		node_to.arcs_in.append(arc)				#add arc object to arcs in list of the to node
		self.arcs.append(arc)					#add arc object to list of arcs in current(self) network
		# **delete the placeholder command below once you have written your code**
		#pass
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)+
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination node pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
		
		# 1. THE PSEUDOCODE FOR THIS METHOD HAS ALREADY BEEN WRITTEN BELOW
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		# - strip() is a useful method that removes white-space from the beginning and 
		#   end of the string
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# divide the string using the split() method for strings
			# - extract the source node
			# - extract the remaining arcs
			# ___
			nList = ln.strip().split(',')				#create a new 'node list' out of previous string split at ","
			from_node_name = nList[0]					#first value of this list is the source node of this line
				
			# YOU WILL NEED TO THINK CAREFULLY ABOUT WHAT THIS TRY/EXCEPT BLOCK DOES
			# if node doesn't exist, add to network
			try:
				# the output is a node object, the input is a string, get the source node OBJECT, using the source node STRING
				# this command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(from_node_name)           
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(from_node_name)
				# after creating the node get the source node OBJECT, using the source node STRING
				from_node = self.get_node(from_node_name)  
				
			#Use a for loop, looping for each term split earlier
			# ___
			for i in range (0, len(nList)):					#could have alternatively used for i in nlist
				if  len(nList[i]) > 1:						#use if statement to identify if any elements of the node list are longer than 1, 
					dList = nList[i].split(';')				#i.e. contain a destination and arc weight and split at ';'
					to_node_name = dList[0]					#the first element of the new 'destination list' will contain the to_node_name
					arc_weight = float(dList[1])			#the second element of the destination list is the arc_weight, converted to a float

					try:
						# the output is a node object, the input is a string
						# this command raises an ERROR if the node DOESN'T exist
						to_node = self.get_node(to_node_name)           
					except NetworkError:
						# this command gets executed if an error is raised above
						self.add_node(to_node_name)
						# after creating the node get the destination node OBJECT, using the destination node STRING
						to_node = self.get_node(to_node_name)

					# read the arc information and add it to network
					#for arc in arcs:			#
					# parse arc information
					# once source, destination nodes and arc weight is established call join_nodes for current(self) network to join the nodes
					# ___
					self.join_nodes(from_node, to_node, arc_weight)
				
				# delete the placeholder command below when you start writing your code
				#pass
						
			# get next line
			# ___
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		# ___
			

		sDir = glob(os.path.join(directory, '*/station_data.txt'))			#use glob and os.path.join along with the input directory to create a
		for j in range(0, len(sDir)):										#list of all the directories of all 'station_data.txt' files in the folder (station directories).
			sData = np.genfromtxt(sDir[j], str, usecols=(1))				#for each directory in the list set station data to the relevant data in the second column using np.genfromtxt(usecols(1)),
			#call add_node for current(self) network
			self.add_node(sData[0], [float(sData[1]), float(sData[2])])		#the first index of station data will contain the node name, the 2nd and 3rd will contain the 'value' of the node as an array


		cDir = glob(os.path.join(directory, 'connections/*.txt'))											#use glob and os.path.join along with the input directory to create a
		for k in range(0, len(cDir)):																		#list of all directories in the connections folder that contain a .txt (connections directories).
			cData = np.genfromtxt(cDir[k],dtype = int, delimiter=', ', skip_header=1, usecols=(1))			#read data from the second column, skipping the header
			node_names = ((cDir[k].split('\\')[2]).split('.')[0]).split('-')								#use splits to seperate the names of the to and from nodes into an array from the directory string
			#call join_nodes for current(self) network														#the first element of this array will be the from node and the second the to node
			self.join_nodes(self.get_node(node_names[0]), self.get_node(node_names[1]), sum(cData)/35)		#use get_node to to get the to and from nodes from their name strings, divide connection data by 35 to get average

		# **delete the placeholder command below once you have written your code**
		#pass
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
			
