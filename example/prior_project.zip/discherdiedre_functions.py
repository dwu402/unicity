import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		conn.wgt = weight
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			statconnlist = ln.split(',')
			stations =[]
			weight = []
			stations =[statconnlist[0]] 
			for i in range((len(statconnlist)-1)):
				TempList = statconnlist[i+1].split(';')
				stations.append(TempList[0])
				weight.append(TempList[1])
			for stat in stations:
				try:
					self.query_station(stat)
				except GridError:
					self.add_station(stat)
			for i in range(len(weight)):
				self.add_connection(self.query_station(stations[0]),self.query_station(stations[i+1]), weight[i])
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		sep = os.sep
		if os.path.isdir(directory):
			files = glob('{}{}*'.format(directory,sep))
			files.remove('{}{}connections'.format(directory,sep))
			for file in files:
				fp = open('{}{}info.txt'.format(file,sep),'r')
				name = fp.readline().strip('code: ').strip()
				x = int(fp.readline().strip('x: ').strip())
				y = int(fp.readline().strip('y: ').strip())
				fp.close()
				self.add_station(name,[x,y])
			connects = glob('{}{}connections{}*'.format(dictionary,sep,sep))
			for connect in connects:
				stat_from, stat_to = connect.strip('{}{}connections{}*.txt'.format(directory,sep,sep)).split('-')
				y,c = np.genfromtxt(connect,dtype ='float',delimiter = ', ', skip_header=1,unpack =1,)
				capacity = np.mean(c)
				self.add_connection(self.query_station(stat_from),self.query_station(stat_to),capacity)
		else:
			print('file not found')
