import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
		self.connections.append(conn)
	def get_or_add_station(self, stat_name):
		try:
			self.query_station(stat_name)
		except GridError:
			self.add_station(stat_name)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '': 
			if len(ln.split(',', 1)) == 1:
				self.get_or_add_station(ln)
				ln = fp.readline().strip()
				continue
			source_stat_name, conns = ln.split(',', 1)
			conns = conns.split(',')
			self.get_or_add_station(source_stat_name)
			source_stat = self.query_station(source_stat_name)
			for conn in conns:
				destination_stat_name, weight = conn.split(';')
				weight = int(weight)
				self.get_or_add_station(destination_stat_name)
				destination_stat = self.query_station(destination_stat_name)
				self.add_connection(source_stat, destination_stat, weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		connections = glob(directory + '\\connections\\*')
		stations = glob(directory + '\\*\\info.txt')
		for subfolder in os.listdir(directory):
			if (subfolder != 'backbone'):
