import numpy as np
Xs = np.genfromtxt('data.txt', delimiter=",", skip_header=1, dtype=None, usecols=0)
Ts = np.genfromtxt('data.txt', delimiter=",", skip_header=1, dtype=None, usecols=1)
print(Xs)
print(Ts)
