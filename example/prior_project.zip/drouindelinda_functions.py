import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		conn.wgt = weight
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			conns = []
			try:
				from_stat_name,to_stat_one,to_stat_two = ln.split(',')
				conns.append(to_stat_one)
				conns.append(to_stat_two)
			except ValueError:				
				try:
					from_stat_name,to_stat_one = ln.split(',')  
					conns.append(to_stat_one)
				except ValueError: 			
					from_stat_name = ln
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source_stat = self.query_station(from_stat_name)
			for conn in conns:
				to_stat, weight = conn.split(';')
				try:
					self.query_station(to_stat)
				except GridError:
					self.add_station(to_stat)
				destination_stat = self.query_station(to_stat)
				self.add_connection(source_stat,destination_stat,weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		files = glob(directory+os.sep+'*')
		for file in files:
			if os.path.isdir(file):
				subfiles = glob(file+os.sep+'*')
				if len(subfiles)==1: 			
					for subfile in subfiles:	
						data = np.genfromtxt(subfile,dtype=str,delimiter=': ',usecols=1)
						code = data[0]
						x = float(data[1])
						y = float(data[2])
						try:
							self.query_station(code)
						except GridError:
							self.add_station(code)
						code_stat = self.query_station(code)
						code_stat.val = [x,y]
				else:
					for subfile in subfiles:
						file_name = subfile.split(os.sep)
						from_stat,to_stat = file_name[2].strip('.txt').split('-')
						capacity = np.genfromtxt(subfile,dtype='float',delimiter=',',skip_header=True,usecols=1)
						weight = np.mean(capacity)
						try:
							self.query_station(from_stat)
						except GridError:
							self.add_station(from_stat)
						point_a_stat = self.query_station(from_stat)
						try:
							self.query_station(to_stat)
						except GridError:
							self.add_station(to_stat)
						point_b_stat = self.query_station(to_stat)
						self.add_connection(point_a_stat,point_b_stat,weight)
