
# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

    
# these classes are complete, do not modify them
class Node(object):
    def __init__(self):
        self.name = None
        self.value = None
        self.arcs_in = []
        self.arcs_out = []
class Arc(object):
    def __init__(self):
        self.weight=None
        self.to_node = None
        self.from_node = None
class NetworkError(Exception):
    '''An error to raise when violations occur.
    '''
    pass
        
    
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
    ''' Basic network class.
    '''
    # these methods are complete, do not modify them
    def __init__(self):
        self.nodes = []
        self.arcs = []
    def get_node(self, name):
        ''' Loops through the list of nodes and returns the one with NAME.
        
            Returns NetworkError if node does not exist.
        '''
        # loop through list of nodes until node found
        for node in self.nodes:
            if node.name == name:
                return node
        
        raise NetworkError
    def display(self):
        ''' Print information about the network.
        '''
        # print nodes
        print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
        # print arcs
        for arc in self.arcs:
            print('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
    
    # **these methods are incomplete, you must complete them as part of the lab task**
    def add_node(self, name, value=None):
        '''Adds a Node with NAME and VALUE to the network.
        '''
        # **to do: create an empty node object, assign its attributes**
        # **hint: how are empty network objects created in lab5_task1.py?**
        # **hint: how are names and values assigned in the __init__ method for node?**
        
        # create empty node object and assign its attributes
        node = Node()
        node.name = name
        node.value = value

        # append node to the list of nodes
        self.nodes.append(node)
        
    def join_nodes(self, node_from, node_to, weight):
        '''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
        '''
        # **to do: create an empty arc object, assign its attributes**
        # **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
        
        # create empty arc object and assign its attributes
        arc = Arc()
        arc.weight = weight
        arc.to_node = node_to
        arc.from_node = node_from

        # add the arc to the list of arcs coming out of the source node and the list of arcs going in to the destination node
        node_from.arcs_out.append(arc)
        node_to.arcs_in.append(arc)
    
        # append arc to the list of arcs
        self.arcs.append(arc)
    
    def read_network(self, filename):
        '''Read data from FILENAME and construct the network.
        
            Each line of FILENAME contains
             - the name of an origin node (first entry)
             - and destination;weight pairs (each pair separated by a comma)
             
        '''
        # **to do**
        # **hint: inspect 'network.txt' so that you understand the file structure**
        # **hint: each source-destination pair needs to be joined
        
        # **some useful (incomplete) code snippets**
        # ln.split
        #
        # 
                
        # open the file
        fp = open(filename, 'r')
        
        # get first line
        ln = fp.readline().strip()
        while ln is not '':        # keep looping to the end of the file
            # split string into origin node name and other arc-weight/destination pairs using split() method for strings
            splitted = ln.split(',')
            
            # find the length of the line to know how many destination arcs there are
            x = len(splitted)
            
            # the origin node will be the first in the list
            oNode = splitted[0]
                
            # if the origin node doesn't exist, add to network
            try:
                self.get_node(oNode)
            except NetworkError:
                self.add_node(oNode)
                
            # get the source node object
            sourceNode = self.get_node(oNode)
            

            # read the arc information and add to network
            # x = 3 means that there are two destination nodes connected to the origin node on that line
            if x == 3:
                dNode1,weight1 = (splitted[1]).split(';')
                dNode2,weight2 = (splitted[2]).split(';')
                weight1 = int(weight1)
                weight2 = int(weight2)
                
                # if the destination nodes don't exist, add to network
                try:
                    self.get_node(dNode1)
                except NetworkError:
                    self.add_node(dNode1)
                try:
                    self.get_node(dNode2)
                except NetworkError:
                    self.add_node(dNode2)

                # get destination node object and link it to origin node
                destNode1 = self.get_node(dNode1)
                destNode2 = self.get_node(dNode2)

                self.join_nodes(sourceNode, destNode1, weight1)
                self.join_nodes(sourceNode, destNode2, weight2)
                    
            # x = 2 means that there is one destination node connected to the origin node on that line
            elif x == 2:
                dNode,weight = (splitted[1]).split(';')
                weight = int(weight)
                
                # if the destination node doesn't exist, add to network
                try:
                    self.get_node(dNode)
                except NetworkError:
                    self.add_node(dNode)
            
                # get destination node object and link it to source node
                destNode = self.get_node(dNode)
                
                self.join_nodes(sourceNode, destNode, weight)
        
            # get next line
            ln = fp.readline().strip()


# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
    ''' Derived Network class, for NZ networks.
    '''    
    
    # **this method is incomplete, you must complete it as part of the lab task**
    def read_network(self, directory):
        ''' Read network information from DIRECTORY
        
            Notes:
            ------
            Assume that DIRECTORY contains one folder for 
            connections between nodes. All other folders define
            the nodes of the network. 
            
            Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
            node) and x and y values for the node position.
            
            In the connections folder, there is a file for each connection.
            The name of the file indicates which two nodes are connected 
            (from-to) and the contents of the file record the capacity of 
            the connection over the previous 35 years. The connection weight
            is the mean capacity.
        '''
        
        # **some useful functions**
        # glob
        # np.genfromtxt
        # os.path.isdir
        # create a list of paths to folders in the directory
        folderPaths = glob(directory+os.sep+'*')
        # loop through all the paths to files in the directory except the path to the file connections, i.e: all the ones corresponding to a station/node.
        for folderPath in folderPaths:
            # check that the last section of the file path, which is the file itself (after the last pathname separator) is not the connections file. If it is, the code will skip to the next file path.
            if (folderPath.split(os.sep)[-1]) != 'connections':
                # open the file inside the folder for reading, read the first line of the file and extract the code for the node. Need the file path to open it.
                filePath = folderPath+os.sep+'station_data.txt'
                fp = open(filePath, 'r')
                header = fp.readline().strip()
                codeLabel, code = header.split()
                # read the next two lines, extracting the x coordinate from the first and the y coordinate from the second. Ensure the x and y values are converted from strings to integers.
                xLine = fp.readline().strip()
                xLabel, x = xLine.split()
                yLine = fp.readline().strip()
                yLabel, y = yLine.split()
                x = int(x)
                y = int(y)
                # close the file
                fp.close()
                # add the node and its coordinates to the network
                self.add_node(code,[x,y])
        
        
        # now need the connections files
        for folderPath in folderPaths:
            if (folderPath.split(os.sep)[-1]) == 'connections':
                # create a list of paths to files in the connections folder
                connections = glob(folderPath+os.sep+'*')
                for connection in connections:
                    # find the three letter codes for the two nodes in the connection by splitting the folderPath in multiple steps.
                    fileNameAndType = connection.split(os.sep)[-1]
                    fileName,Type = fileNameAndType.split('.')
                    codeFrom,codeTo = fileName.split('-')
                    # use the codes to find the nodes in the network
                    nodeFrom = self.get_node(codeFrom)
                    nodeTo = self.get_node(codeTo)
                    # now extract two vectors from the connection file using np.genfromtxt. Set unpack to 1 so that the vectors are tranposed and can be used for later calculations.
                    time, capacity = np.genfromtxt(connection, skip_header = 1, delimiter = ',', unpack = 1)
                    # calculate the weight of the connection from the mean value of the capacity vector
                    weight = np.mean(capacity)
                    # create the connection between the two nodes
                    self.join_nodes(nodeFrom, nodeTo, weight)

    # this method is complete, do not modify
    def show(self, save=None):
        ''' Plot the network and optionally save to file SAVE
        '''
        # create figure axes
        fig=plt.figure()
        fig.set_size_inches([10,10])
        ax=plt.axes()
        
        # NZ coastline as background
        img=mpimg.imread('bg.png')
        ax.imshow(img,zorder=1)
    
        # a filthy hack to get coordinates in the right spot...
        for node in self.nodes:
            x,y = node.value
            y = int((y+10)*1.06)
            x -= int(50*y/800.)
            node.value = [x,y]
    
        # draw nodes as text boxes with station names
            # bounding box properties
        props = dict(boxstyle='round', facecolor='white', alpha=1.0)
        for node in self.nodes:
            # extract coordinates
            x,y = node.value
            ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
            
        # draw connections as lines
        weights = [arc.weight for arc in self.arcs]
            # scale for plotting connections
        wmin = np.min(weights)
        wmax = np.max(weights)
        lmin,lmax = [0.5, 10.0]
        
        # plot connections
        for arc in self.arcs:
            # compute line length, scales with connection size
            lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
            x1,y1 = arc.from_node.value
            x2,y2 = arc.to_node.value
            ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
    
        # remove ticks
        ax.set_xticks([])
        ax.set_yticks([])
    
        # display options
        if save:
            # save to file
            plt.savefig(save, dpi=300)
            plt.close()
        else:
            # open figure window in screen
            plt.show()
    
    
        
        
        
        
        
        
        
        
        
            
