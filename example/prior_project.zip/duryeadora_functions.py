import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
    def __init__(self):
        self.id = None
        self.val = None
        self.cons_in = []
        self.cons_out = []
class Connection(object):
    def __init__(self):
        self.wgt=None
        self.to_stat = None
        self.from_stat = None
class GridError(Exception):
    pass
class Grid(object):
    def __init__(self):
        self.stations = []
        self.connections = []
    def query_station(self, name):
        for stat in self.stations:
            if stat.id == name:
                return stat
        raise GridError
    def add_station(self, name, value=None):
        stat = Station()
        stat.id = name
        stat.val = value
        self.stations.append(stat)
    def add_connection(self, stat_from, stat_to, weight):
        conn = Connection()
        conn.wgt = weight
        conn.to_stat = stat_to
        conn.from_stat = stat_from
        stat_from.cons_out.append(conn)
        stat_to.cons_in.append(conn)
        self.connections.append(conn)
    def read(self, filename):
        fp = open(filename, 'r')
        ln = fp.readline().strip()
        while ln is not '':        
            splitted = ln.split(',')
            x = len(splitted)
            oStation = splitted[0]
            try:
                self.query_station(oStation)
            except GridError:
                self.add_station(oStation)
            sourceStation = self.query_station(oStation)
            if x == 3:
                dStation1,weight1 = (splitted[1]).split(';')
                dStation2,weight2 = (splitted[2]).split(';')
                weight1 = int(weight1)
                weight2 = int(weight2)
                try:
                    self.query_station(dStation1)
                except GridError:
                    self.add_station(dStation1)
                try:
                    self.query_station(dStation2)
                except GridError:
                    self.add_station(dStation2)
                destStation1 = self.query_station(dStation1)
                destStation2 = self.query_station(dStation2)
                self.add_connection(sourceStation, destStation1, weight1)
                self.add_connection(sourceStation, destStation2, weight2)
            elif x == 2:
                dStation,weight = (splitted[1]).split(';')
                weight = int(weight)
                try:
                    self.query_station(dStation)
                except GridError:
                    self.add_station(dStation)
                destStation = self.query_station(dStation)
                self.add_connection(sourceStation, destStation, weight)
            ln = fp.readline().strip()
class Roads(Grid):
    def read(self, directory):
        folderPaths = glob(directory+os.sep+'*')
        for folderPath in folderPaths:
            if (folderPath.split(os.sep)[-1]) != 'backbone':
                filePath = folderPath+os.sep+'info.txt'
                fp = open(filePath, 'r')
                header = fp.readline().strip()
                codeLabel, code = header.split()
                xLine = fp.readline().strip()
                xLabel, x = xLine.split()
                yLine = fp.readline().strip()
                yLabel, y = yLine.split()
                x = int(x)
                y = int(y)
                fp.close()
                self.add_station(code,[x,y])
        for folderPath in folderPaths:
            if (folderPath.split(os.sep)[-1]) == 'backbone':
                connections = glob(folderPath+os.sep+'*')
                for connection in connections:
                    fileNameAndType = connection.split(os.sep)[-1]
                    fileName,Type = fileNameAndType.split('.')
                    codeFrom,codeTo = fileName.split('-')
                    statFrom = self.query_station(codeFrom)
                    statTo = self.query_station(codeTo)
                    time, capacity = np.genfromtxt(connection, skip_header = 1, delimiter = ',', unpack = 1)
                    weight = np.mean(capacity)
                    self.add_connection(statFrom, statTo, weight)
