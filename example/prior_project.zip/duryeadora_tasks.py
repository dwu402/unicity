import numpy as np
(xs, ts) = np.genfromtxt('data.txt', skip_header=1, delimiter=",", autostrip=True, unpack=1)
