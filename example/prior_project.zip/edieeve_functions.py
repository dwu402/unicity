import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
    def __init__(self):
        self.id = None
        self.val = None
        self.cons_in = []
        self.cons_out = []
class Connection(object):
    def __init__(self):
        self.wgt=None
        self.to_stat = None
        self.from_stat = None
class GridError(Exception):
    pass
class Grid(object):
    def __init__(self):
        self.stations = []
        self.connections = []
    def query_station(self, name):
        for stat in self.stations:
            if stat.id == name:
                return stat
        raise GridError
    def add_station(self, name, value=None):
        stat = Station()
        stat.id = name
        stat.val = value
        self.stations.append(stat)
    def add_connection(self, stat_from, stat_to, weight):
        conn = Connection()
        conn.wgt = weight
        conn.to_stat = stat_to
        conn.from_stat = stat_from
        self.connections.append(conn)
        stat_from.cons_out.append(conn)
        stat_to.cons_in.append(conn)
    def read(self, filename):
        fp = open(filename, 'r')
        ln = fp.readline().strip()
        while ln is not '':       
            x = ln.split(",")
            from_stat_name = x[0]
            try:
                self.query_station(from_stat_name)
            except GridError:
                self.add_station(from_stat_name)
            i = 1
            for i in range (1,len(x)):
                to_stat_name, weight = x[i].split(";")
                try:
                    self.query_station(to_stat_name)
                except GridError:
                    self.add_station(to_stat_name)
                self.add_connection(self.query_station(from_stat_name), self.query_station(to_stat_name), weight)
                i = i + 1
            ln = fp.readline().strip()
class Roads(Grid):
    def read(self, directory):
        files = glob(directory + os.sep + "*")
        for file in files:
             stations = glob(file + os.sep + "info.txt")
             for file in stations:
                fp = open(file, 'r')
                coordinates = [-1,-1]
                ln = fp.readline().strip()
                name = ln.split(":")[1].strip()
                ln = fp.readline().strip()
                coordinates[0] = float(ln.split(":")[1].strip())
                ln = fp.readline().strip()
                coordinates[1] = float(ln.split(":")[1].strip())
                self.add_station(name, coordinates)
        connections = glob(directory + os.sep + "connections" + os.sep + "*")
        for file in connections:
            name = os.path.splitext(os.path.basename(file))[0]
            from_stat_name, to_stat_name = name.split("-")
            time, capacity = np.genfromtxt(file, skip_header = 1, delimiter = ',', unpack = True)
            weight = np.mean(capacity)
            self.add_connection(self.query_station(from_stat_name), self.query_station(to_stat_name), weight)
