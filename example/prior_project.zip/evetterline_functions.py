import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			line = ln.split(",")
			from_stat_name = line[0]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			stat_from = self.query_station(from_stat_name)
			for con in line[1:]:
				stat_to_name,weight = con.split(";")
				weight = float(weight)
				try:
					self.query_station(stat_to_name)
				except GridError:
					self.add_station(stat_to_name)
				stat_to = self.query_station(stat_to_name)
				self.add_connection(stat_from,stat_to,weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		files = glob(directory+os.sep+'*')
		for file in files:
			subfiles = glob(file+os.sep+'*')
			for subfile in subfiles:
				if len(subfiles) == 1:
					fp = open(subfile, 'r')
					ln = fp.readline().strip()
					line = ln.split(" ")
					name = line[1]
					ln = fp.readline().strip()
					line = ln.split(' ')
					x = line[1]
					x = float(x)
					ln = fp.readline().strip()
					line = ln.split(' ')
					y = line[1]
					y = float(y)
					value = (x,y)
					self.add_station(name,value)
				else:
					pass
		for file in files:
			subfiles = glob(file+os.sep+'*')
			for subfile in subfiles:
				if len(subfiles) > 1:
					line = os.path.basename(subfile)
					stat_from_name,stattotxt = line.split('-')
					stat_to_name,txt = stattotxt.split('.')
					Years,Capacities = np.genfromtxt(subfile,delimiter=',', dtype = float,skip_header=1,unpack=1)
					Total_Capacity = sum(Capacities)
					mean_capacity = Total_Capacity / 35
					stat_from = self.query_station(stat_from_name)
					stat_to = self.query_station(stat_to_name)
					self.add_connection(stat_from,stat_to,mean_capacity)
