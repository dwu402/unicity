import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt= weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			ln = ln.split(',')
			from_stat_name = ln[0]
			try:
				from_stat = self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			from_stat = self.query_station(from_stat_name)
			conns = ln[1:]
			for conn in conns:
				D = conn.split(";")
				try:
					to_stat = self.query_station(D[0])
				except GridError:
					self.add_station(D[0])
				to_stat = self.query_station(D[0])
				self.add_connection(from_stat,to_stat,D[1])
			ln = fp.readline().strip()
class Roads(Grid):
	def __init__(self):
		Grid.__init__(self)
	def read(self, directory):
		if os.path.isdir(directory):
			stat = glob(directory+os.sep+"*")
			conns = stat.pop(stat.index(directory+"\connections"))
			for file in stat:
				info = glob(file+os.sep+"*.txt")
				values = np.genfromtxt(info[0], dtype ='str' , delimiter = ':', unpack = True, usecols = 1)
				from_stat_name = values[0].strip()
				x = int(values[1])
				y = int(values[2])
				try:
					from_stat = self.query_station(from_stat_name)
				except GridError:
					self.add_station(from_stat_name,[x,y])
			conn1 = glob(conns+os.sep+"*.txt")
			for line in conn1:
				a = os.path.splitext(os.path.basename(line))
				b = a[0].split("-")
				from_stat_name = b[0]
				to_stat_name = b[1]
				cap = np.genfromtxt(line,delimiter = ',', skip_header = 1, unpack = True,usecols = 1)
				weight = np.mean(cap)
				try:
					from_stat = self.query_station(from_stat_name)
				except GridError:
					self.add_station(from_stat_name)
				from_stat = self.query_station(from_stat_name)
				try:
					to_stat = self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				to_stat = self.query_station(to_stat_name)
				self.add_connection(from_stat,to_stat,weight)
