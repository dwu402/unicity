# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is now complete for lab5 task 1b**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		
		# create new node
		node = Node()
		
		# assing attributes to node
		node.name = name
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		
		# create empty arc
		arc = Arc()
		
		# assign attributes to arc
		arc.weight= weight
		arc.to_node = node_to
		arc.from_node = node_from
		
		# append arc to the list of arcs
		self.arcs.append(arc)
		
		# assign attribute to nodes
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)

		
        
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
		
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			ln = ln.split(',')
			from_node_name = ln[0]


			# if node doesn't exist, add to network
			try:
				from_node = self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			from_node = self.get_node(from_node_name)
			
			# let arcs be an array of all arcs going out of source node
			arcs = ln[1:]
	
			# read the arc information and add to network
			for arc in arcs:
				
				# split every arc into to_node.name and weight of arc
				D = arc.split(";")

				try:
					to_node = self.get_node(D[0])
				except NetworkError:
					self.add_node(D[0])
					
				# get destination node object and link it to source node
				to_node = self.get_node(D[0])
				self.join_nodes(from_node,to_node,D[1])
						
			# get next line
			ln = fp.readline().strip()
			
# **This class is now complete for lab5 task 2**

#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	# these methods are complete, do not modify them
	def __init__(self):
		Network.__init__(self)
		

	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir

		# if directory is a path
		if os.path.isdir(directory):
			
			# glob for all files inside directory
			node = glob(directory+os.sep+"*")
			
			# pop out the folder called connections from the array of node
			# assign the connections folder to arcs
			arcs = node.pop(node.index(directory+"\connections"))
			
			# loop through all elements(folders in directory) of node
			for file in node:

				# search for txt file inside the folders of node
				info = glob(file+os.sep+"*.txt")

				# reads data in as strings
				values = np.genfromtxt(info[0], dtype ='str' , delimiter = ':', unpack = True, usecols = 1)

				# assign name to from node
				from_node_name = values[0].strip()

				# find x,y values of the node
				x = int(values[1])
				y = int(values[2])

				# if node doesn't exist, add to network
				try:
					from_node = self.get_node(from_node_name)
				except NetworkError:
					self.add_node(from_node_name,[x,y])
				
			# find all txt files in the connections folder
			arc1 = glob(arcs+os.sep+"*.txt")

			# loop through all txt files in connections
			for line in arc1:

				# get node names from txt filenames
				a = os.path.splitext(os.path.basename(line))
				b = a[0].split("-")
				from_node_name = b[0]
				to_node_name = b[1]

				# read capacity data into array cap (column 2)
				cap = np.genfromtxt(line,delimiter = ',', skip_header = 1, unpack = True,usecols = 1)
				# calculate weight of arc by finding mean of capacity
				weight = np.mean(cap)
				
				# if node doesn't exist, add to network
				try:
					from_node = self.get_node(from_node_name)
				except NetworkError:
					self.add_node(from_node_name)
				
				# get source node object
				from_node = self.get_node(from_node_name)	

				# if node doesn't exist, add to network
				try:
					to_node = self.get_node(to_node_name)
				except NetworkError:
					self.add_node(to_node_name)

				# get destination node object and link it to source node
				to_node = self.get_node(to_node_name)
				self.join_nodes(from_node,to_node,weight)


	
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)


	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
