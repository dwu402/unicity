import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
    def __init__(self):
        self.id = None
        self.val = None
        self.cons_in = []
        self.cons_out = []
class Connection(object):
    def __init__(self):
        self.wgt=None
        self.to_stat = None
        self.from_stat = None
class GridError(Exception):
    pass
class Grid(object):
    def __init__(self):
        self.stations = []
        self.connections = []
    def query_station(self, name):
        for stat in self.stations:
            if stat.id == name:
                return stat
        raise GridError
    def add_station(self, name, value=None):
        stat = Station()
        stat.id = name
        stat.val = value
        self.stations.append(stat)
    def add_connection(self, stat_from, stat_to, weight):
        conn = Connection()
        conn.wgt = weight
        conn.from_stat = stat_from
        conn.to_stat = stat_to
        stat_from.cons_out.append(conn)
        stat_to.cons_in.append(conn)
        self.connections.append(conn)
    def read(self, filename):
        fp = open(filename, 'r')
        ln = fp.readline().strip()
        while ln is not '':
            separate = ln.split(',')
            from_stat_name = separate[0]
            conns = []
            i = len(separate)   
            if i >2:
                for l in range(1,i):
                    conns.append(separate[l])
                    i=i-1
            elif i==2:
                conns.append(separate[1])
            try:
                self.query_station(from_stat_name)
            except GridError:
                self.add_station(from_stat_name)
            stat = self.query_station(from_stat_name)
            for conn in conns:
                [destination, weight] = conn.split(";")
                try:
                    self.query_station(destination)
                except GridError:
                    self.add_station(destination)
                destination = self.query_station(destination)
                self.add_connection(stat, destination, weight)
            ln = fp.readline().strip()
class Roads(Grid):
    def read(self, directory):
        folders = glob(directory)
        filenames = glob("./*/*/**station*")
        for filename in filenames:
            fp = open(filename, 'r')
            ln = fp.readline().strip()
            (code, name) = ln.split(':')
            name = name.strip()  
            ln = fp.readline().strip()
            (xname, xvalue) = ln.split(':')
            x = int(xvalue)
            ln = fp.readline().strip()
            (yname, yvalue) = ln.split(':')
            y = int(yvalue)
            value = [x, y]
            try:
                self.query_station(name)
            except GridError:
                self.add_station(name, value)
        folders = glob(directory)
        connectionfiles = glob("./*/**connections*/*")
        for connection in connectionfiles:
            capacity = 0
            delete = connection.split('/')
            nametxt = delete[3]
            nameoftofromtxt = nametxt.split('.')
            nameoftofrom = nameoftofromtxt[0]
            from_stat, to_stat = nameoftofrom.split('-')
            data = np.genfromtxt(connection, dtype = None, skip_header = 1, delimiter = ',', usecols = 1)
            length = len(data)
            i=[]
            a=0
            while a is not len(data):
                b = data[a]
                capacity = b+capacity
                i.append(b)
                a = a+1
            capacity = i
            capacitysum = int((np.sum(capacity)))
            length = int(length)
            weight= capacitysum/length
            sourcestat = self.query_station(from_stat.strip())
            destination = self.query_station(to_stat.strip())
            self.add_connection(sourcestat, destination, weight)
