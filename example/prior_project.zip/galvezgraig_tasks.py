import numpy as np
fp = open('example_file.txt','r')
data = np.genfromtxt('example_file.txt', dtype = None, skip_header = 1, delimiter = ',')
X = data[:,0]
T = data[:,1]
