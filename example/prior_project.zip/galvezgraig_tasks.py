import numpy as np
fp = open('data.txt','r')
data = np.genfromtxt('data.txt', dtype = None, skip_header = 1, delimiter = ',')
X = data[:,0]
T = data[:,1]
