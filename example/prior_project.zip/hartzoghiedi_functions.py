import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt = None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		conn.wgt = weight
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			string = ln.split(',')
			source_stat = string[0]
			conns = string[1:]
			try:
				self.query_station(source_stat)
			except GridError:
				self.add_station(source_stat) 
			source_stat = self.query_station(source_stat)
			for conn in conns:
				dwpair = conn.split(';') 
				destination = dwpair[0] 
				weight = dwpair[1]	
				try:
					self.query_station(destination)
				except GridError:
					self.add_station(destination)
				destination = self.query_station(destination)
				self.add_connection(source_stat, destination, weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		files = glob('*') 
		for file in files:
			if os.path.isdir(file): 
				if file == directory: 
					subfiles = glob(file + os.sep + '*') 
					for subfile in subfiles:
						string = subfile.split(os.sep)[-1] 
						if string != 'backbone': 
							subsubfiles = glob(subfile + os.sep + '*') 
							for subsubfile in subsubfiles: 
								fp = open(subsubfile,'r')
								name = fp.readline().strip()
								fp.close()
								name = name.split(':')[1]
								stat_name = name.strip()
								x, y = np.genfromtxt(subsubfile, skip_header = 1, usecols = 1)
								stat_value = x,y
								try:
									self.query_station(stat_name)
								except GridError:
									self.add_station(stat_name, stat_value)
					for subfile in subfiles: 
						string = subfile.split(os.sep)[-1] 
						if string == 'backbone': 
							subsubfiles = glob(subfile + os.sep + '*')
							for subsubfile in subsubfiles:
								string = subsubfile.split(os.sep)[-1] 
								string = string.split('.')[0]
								source_stat = string.split('-')[0] 
								destination = string.split('-')[1] 
								c = np.genfromtxt(subsubfile, delimiter = ",", skip_header = 1, unpack = True, usecols = 1)
								weight = np.mean(c) 
								source_stat = self.query_station(source_stat)
								destination = self.query_station(destination)
								self.add_connection(source_stat, destination, weight)
