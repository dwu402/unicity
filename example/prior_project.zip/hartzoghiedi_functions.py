# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight = None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
class Network(object):
	''' Basic network class.
	'''
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		
		# create empty node object
		node = Node()
		
		# assign node name and value
		node.name = name
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		
		# create empty arc object
		arc = Arc()
		
		# assign node which arc goes to and from
		arc.to_node = node_to
		arc.from_node = node_from
		
		# assign arc weight
		arc.weight = weight
		
		# append arc to arcs_in and arcs_out attributes of the nodes
		node_to.arcs_in.append(arc)
		node_from.arcs_out.append(arc)
		
		# append arc to the list of arcs
		self.arcs.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		
		while ln is not '':        # keep looping to the end of the file
		
			# split string into source node name and other arcs using split() method for strings
			string = ln.split(',')
			
			# first entry is the name of the source node
			source_node = string[0]
			
			# make a list of destination node/weights (arcs)
			arcs = string[1:]
			
			# if node doesn't exist, add to network
			try:
				self.get_node(source_node)
			except NetworkError:
				self.add_node(source_node) # these nodes do not have a value, only a name
				
			# get the source node object
			source_node = self.get_node(source_node)
	
			# read the arc information and add to network
			for arc in arcs:
				# parse arc information
				dwpair = arc.split(';') # split the destination node and the weight
				
				destination = dwpair[0] # first half of the split
				weight = dwpair[1]	# second half of the split
				
				# if destination node doesn't exist, add to network
				try:
					self.get_node(destination)
				except NetworkError:
					self.add_node(destination)
				
				# get destination node object and link it to source node
				destination = self.get_node(destination)
				
				self.join_nodes(source_node, destination, weight)
		
			# get next line
			ln = fp.readline().strip()
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network.
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
			
		files = glob('*') # all files in current directory
		for file in files:
			if os.path.isdir(file): # if the file is a directory (folder)
				if file == directory: # only use the file which is the given directory
					subfiles = glob(file + os.sep + '*') # find all files inside nz_network
					for subfile in subfiles:
						string = subfile.split(os.sep)[-1] # string is only the folder name (not path)
						if string != 'connections': # if the folder is not the connections folder
							subsubfiles = glob(subfile + os.sep + '*') # find files inside each network folder
							for subsubfile in subsubfiles: # will be station_data.txt

								# open the file and take the first line to get the node name
								fp = open(subsubfile,'r') 
								name = fp.readline().strip()
								fp.close()
								
								name = name.split(':')[1]
								node_name = name.strip()
								
								# get x and y coordinates from file and set as the node value
								x, y = np.genfromtxt(subsubfile, skip_header = 1, usecols = 1)
								node_value = x,y
								
								# check if node already exists in network, if not, add it
								try:
									self.get_node(node_name)
								except NetworkError:
									self.add_node(node_name, node_value)								
					
					for subfile in subfiles: # all nodes have now been created
						string = subfile.split(os.sep)[-1] # make string into only the folder name
						if string == 'connections': # if the folder is the connections folder
							subsubfiles = glob(subfile + os.sep + '*')
							for subsubfile in subsubfiles:
								string = subsubfile.split(os.sep)[-1] # get name of file (connections)
								
								# Split string by removing .txt part (only using first section) and spliting the two node names at the -
								string = string.split('.')[0]
								
								# get name for source node and destination node
								source_node = string.split('-')[0] # the node from name
								destination = string.split('-')[1] # the node to name
								
								# read capacity data from connection file and put into an array
								c = np.genfromtxt(subsubfile, delimiter = ",", skip_header = 1, unpack = True, usecols = 1)

								weight = np.mean(c) # weight of connection is the mean of the connection strengths over 35 years
									
								# get source and destination node objects
								source_node = self.get_node(source_node)
								destination = self.get_node(destination)
								
								# join these nodes with the weight (connection strenth)
								self.join_nodes(source_node, destination, weight)

									
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
