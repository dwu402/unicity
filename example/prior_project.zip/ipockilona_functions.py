import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			conns = []
			try:
				from_stat_name, points_to = ln.split(',', 1)
				try: 
					points1, points2 = points_to.split(',')
					conns.append(points1)
					conns.append(points2)
				except ValueError: 
					conns.append(points_to)
			except ValueError: 
				from_stat_name = ln
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source_stat = self.query_station(from_stat_name)
			for conn in conns:
				destination, weight = conn.split(';')
				try:
					self.query_station(destination)
				except GridError:
					self.add_station(destination)
				destination_stat = self.query_station(destination)
				self.add_connection(source_stat, destination_stat, weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		files = glob(directory+os.sep+'*')
		for file in files:
			if os.path.isdir(file): 
				subfiles = glob(file+os.sep+'*')
				if len(subfiles) == 1: 
					file_info = np.genfromtxt(subfiles[0], dtype=str, delimiter =": ", usecols = 1)
					stat_name = file_info[0]
					stat_values = [ float(file_info[1]),float(file_info[2]) ]
					try:
						self.query_station(stat_name)
					except GridError:
						self.add_station(stat_name)
					stat = self.query_station(stat_name)
					stat.val = stat_values
				else:
					for subfile in subfiles:
						filename = subfile.split(os.sep)
						from_stat_name, to_stat_name = filename[2].strip('.txt').split('-')
						capacity = np.genfromtxt(subfile, dtype="f8", delimiter =",", skip_header = 1, usecols = 1)
						mean_capacity = sum(capacity) / len(capacity)
						try:
							self.query_station(from_stat_name)
						except GridError:
							self.add_station(from_stat_name)
						try:
							self.query_station(to_stat_name)
						except GridError:
							self.add_station(to_stat_name)
						from_stat = self.query_station(from_stat_name)
						to_stat = self.query_station(to_stat_name)
						self.add_connection(from_stat, to_stat, mean_capacity)
