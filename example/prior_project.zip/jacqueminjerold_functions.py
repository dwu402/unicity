import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		self.connections.append(conn)
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			ln = ln.split(',')
			from_stat_name = ln[0]
			conns = ln[1:]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			for conn in conns:
				conn_destination, conn_weight = conn.split(';')
				try:
					self.query_station(conn_destination)
				except GridError:
					self.add_station(conn_destination)
				self.add_connection(self.query_station(from_stat_name),self.query_station(conn_destination),conn_weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		files = glob(directory+os.sep+'*')
		for file in files:
			subfiles = glob(file+os.sep+'info.txt')
			for subfile in subfiles:
				coords = [0,0]
				fp = open(subfile, 'r')
				ln = fp.readline().strip()
				name = ln.split(': ')[1]
				ln = fp.readline().strip()
				coords[0] = ln.split(': ')[1]
				ln = fp.readline().strip()
				coords[1] = ln.split(': ')[1]
				coords[0], coords[1] = int(coords[0]), int(coords[1])
				self.add_station(name,coords)
		subfiles2 = glob(directory + os.sep + 'backbone' + os.sep + '*')
		for subfile2 in subfiles2:
			time, capacity = np.genfromtxt(subfile2, skip_header = 1, delimiter = ',', unpack = True)
			mean_capacity = np.mean(capacity)
			line = subfile2.split(os.sep)[-1]
			line = line.split('.')[0]
			frm, to = line.split('-')
			self.add_connection(self.query_station(frm),self.query_station(to),mean_capacity)
