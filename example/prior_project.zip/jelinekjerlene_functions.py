import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
    def __init__(self):
        self.id = None
        self.val = None
        self.cons_in = []
        self.cons_out = []
class Connection(object):
    def __init__(self):
        self.wgt=None
        self.to_stat = None
        self.from_stat = None
class GridError(Exception):
    pass
class Grid(object):
    def __init__(self):
        self.stations = []
        self.connections = []
    def query_station(self, name):
        for stat in self.stations:
            if stat.id == name:
                return stat
        raise GridError
    def add_station(self, name, value=None):
        stat = Station() 
        stat.id = name
        stat.val = value 
        self.stations.append(stat)
    def add_connection(self, stat_from, stat_to, weight):
        conn = Connection() 
        conn.wgt = weight
        conn.to_stat = stat_to
        conn.from_stat = stat_from 
        stat_from.cons_out.append(conn)
        stat_to.cons_in.append(conn) 
        self.connections.append(conn) 
    def read(self, filename):
        fp = open(filename, 'r')
        ln = fp.readline().strip()
        while ln is not '':        
            ln=ln.split(",")
            from_stat_name= ln[0]
            try:
                self.query_station(from_stat_name)
            except GridError:
                self.add_station(from_stat_name)
            from_stat_name = self.query_station(from_stat_name)
            conns= ln[1:]
            for conn in conns:
                to_stat_name, weight=conn.split(';')
                try:
                    self.query_station(to_stat_name)
                except GridError:
                    self.add_station(to_stat_name)
                to_stat_name = self.query_station(to_stat_name)
                self.add_connection(from_stat_name,to_stat_name,weight)
            ln = fp.readline().strip()
class Roads(Grid):
    def read(self, directory):
        Original_path=os.path.dirname(os.path.realpath(__file__)); 
        path=os.path.join(Original_path, 'roads_grid') 
        folders= os.listdir(path) 
        for folder in folders:
            path_=os.path.join(path, folder) 
            if os.path.isdir(path_):
                info=os.listdir(path_) 
                if 'info.txt'in info: 
                    os.chdir(path_) 
                    garbage, name = np.genfromtxt('info.txt',dtype=None,skip_footer=2, delimiter=": ", unpack=1)
                    garbage, value = np.genfromtxt('info.txt',skip_header=1, delimiter=":", unpack=1) 
                    name = name.decode('UTF-8') 
                    self.add_station(name, value) 
                else:
                    path_conn=path_ 
        os.chdir(path_conn) 
        files= os.listdir(path_conn) 
        for file in files: 
            garbage, value = np.genfromtxt(file,dtype=None,skip_header=1, delimiter=",", unpack=1) 
            mean=np.mean(value) 
            file_name=file.strip('.txt') 
            stat_from, stat_to = file_name.split('-') 
            stat_from = self.query_station(stat_from)
            stat_to = self.query_station(stat_to) 
            self.add_connection(stat_from,stat_to,mean) 
        os.chdir(Original_path)
