import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt= weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		self.connections.append(conn)
		stat_to.cons_in.append(conn)
		stat_from.cons_out.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			line_info = ln.split(",")
			conns = line_info[1:]
			source_stat = line_info[0]
			try:
				self.query_station(source_stat)
			except GridError:
				self.add_station(source_stat)
			for conn in conns:
				stat_to,weight = conn.split(";")
				try:
					self.query_station(stat_to)
				except GridError:
					self.add_station(stat_to)
				self.add_connection(self.query_station(source_stat),self.query_station(stat_to),weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		from glob import glob
		conns = glob(directory + os.sep + 'backbone' + os.sep + '*')
		stations = glob(directory + os.sep +'*'+ os.sep + 'info.txt')
		for stat in stations:
			stat_name = []
			x_co_ord = []
			y_co_ord = []
			fp = open(stat,'r')
			stat_name = fp.readline().strip()
			stat_name = stat_name.replace('code: ','')
			x_co_ord,y_co_ord = np.genfromtxt(stat, unpack = 1, usecols = 1, delimiter = ' ',autostrip = True,skip_header =1 )
			stat_name = self.add_station(stat_name,value= [x_co_ord,y_co_ord])
		for conn in conns:
			file = os.path.basename(conn)
			file = file.replace('.txt','')
			stations_S_D = file.split("-")
			stat_from = stations_S_D[0]
			stat_to = stations_S_D[1]
			fp = open(conn,'r')
			capacities = np.genfromtxt(conn, unpack = 1, usecols = 1, delimiter = ',',autostrip = True,skip_header =1 )
			capacity = np.mean(capacities)
			self.add_connection(self.query_station(stat_from),self.query_station(stat_to),capacity)
