import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		newStation = Station()
		newStation.id = name
		newStation.val = value
		self.stations.append(newStation)
	def add_connection(self, stat_from, stat_to, weight):
		connFromA = Connection()
		connFromA.wgt = weight
		connFromA.to_stat = stat_to
		connFromA.from_stat = stat_from
		stat_from.cons_out.append(connFromA)
		stat_to.cons_in.append(connFromA)
		self.connections.append(connFromA)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			values = ln.split(",")
			from_stat_name = values[0]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source_stat = self.query_station(values[0])
			conns = values[1:]
			for conn in conns:
				connInfo = conn.split(";")
				try:
					self.query_station(connInfo[0])
				except GridError:
					self.add_station(connInfo[0])
				self.add_connection(self.query_station(values[0]), self.query_station(connInfo[0]), connInfo[1])
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		fileNames = glob("roads_grid\\*")
		for fileName in fileNames:
			if fileName != "roads_grid\\connections":
				fp = open(fileName + "\\info.txt", 'r')
				codeLine = fp.readline().strip()
				code = codeLine[6:]
				xCordLine = fp.readline().strip()
				xCord = xCordLine[3:]
				yCordLine = fp.readline().strip()
				yCord = yCordLine[3:]
				xyVec = [float(xCord), float(yCord)]
				self.add_station(name=code, value=xyVec)
		fileNames = glob("roads_grid\\connections\\*")
		for fileName in fileNames:
			statNames = fileName[23:].strip(".txt").split("-")
			from_stat = self.query_station(statNames[0])
			to_stat  = self.query_station(statNames[1])
			data = np.genfromtxt(fname=fileName, skip_header=1, delimiter = ", ")
			connWeight = np.mean(data[:,1])
			self.add_connection(stat_from=from_stat, stat_to=to_stat, weight=connWeight)
