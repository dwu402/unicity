import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat= Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			line = ln.split(',')
			from_stat_name = line[0]
			conns = line[1:]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source_stat = self.query_station(from_stat_name)
			for x in conns:
				conn_weight = x.split(';')[1]
				conn_to_stat = x.split(';')[0]
				try:
					self.query_station(conn_to_stat)
				except GridError:
					self.add_station(conn_to_stat)
				destination_stat = self.query_station(conn_to_stat)
				self.add_connection(source_stat,destination_stat,conn_weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		y = glob(r'{}\*'.format(directory))
		for path in y:
			if path != (r'{}\connections'.format(directory)):
				[Type, Location] = np.genfromtxt(path + '\info.txt',dtype = 'str', delimiter = ':', skip_footer=2, unpack = 1)
				[type, Coordinates] = np.genfromtxt(path + '\info.txt',delimiter = ':', skip_header=1, unpack = 1)
				self.add_station(Location.lstrip(' '),Coordinates)
		z = glob(r'{}\connections\*.txt'.format(directory))
		conn_titles = []
		for file_name in z:
			title = file_name.split('connections\\')[1].strip('.txt')
			conn_titles.append(title)
		from_to=[]
		for name in conn_titles:
			from_to.append(name.split('-'))
		c_weights = []
		for name in z:
			[Tm,Cap] = np.genfromtxt(name, delimiter = ',', skip_header=1, unpack = 1)
			Cap_mean = np.mean(Cap)
			c_weights.append(Cap_mean)
		i = 0
		for name in from_to:
			from_Station = self.query_station(name[0])
			to_Station = self.query_station(name[1])
			self.add_connection(from_Station,to_Station,c_weights[i])
			i = i +  1
