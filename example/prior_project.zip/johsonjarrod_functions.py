# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint: how are empty network objects created in lab5_task1.py?**
		# **hint: how are names and values assigned in the __init__ method for node?**
		
		# Creating a Node object called node 
		node= Node() 
		
		# Assigning the object its name and value given in the input
		node.name = name
		node.value = value
		
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both node objects have arcs_in and arcs_out objects - how should these be modified**
		
		# Creating an Arc object called arc
		arc = Arc()
		
		
		# Assinging the arc object its attributes
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from
		
		# Assinging the arc to respective arcs_out and arcs_in attributes of the input nodes
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		
		# Appending the arc to the list of arcs in the network
		self.arcs.append(arc)
		
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# split string into source node name and other arcs using split() method for strings
			
			# Splitting the string where ever a ',' is present and then storing the different parts of the string in a list
			line = ln.split(',')
			
			# Storing the first element in every list as the name of the from_node
			from_node_name = line[0]
			
			# The following elements in the list will be to_nodes for arcs from the from_node
			arcs = line[1:]
			
			# if node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			source_node = self.get_node(from_node_name)
			
			# read the arc information and add to network
			
			for x in arcs:
				# parse arc information
				
				# Assigning the weight and to_node attributes of a arc to variables
				arc_weight = x.split(';')[1]
				arc_to_node = x.split(';')[0]
				
				# get destination node object and link it to source node
				
				# If the to_node of the arc doesn't exist, it is added to the network
				try:
					self.get_node(arc_to_node)
				except NetworkError:
					self.add_node(arc_to_node)
				
				# Assigning destination_node a node object
				destination_node = self.get_node(arc_to_node)
				
				# Joining the source node and destination node with arc of weight of arc_weight
				self.join_nodes(source_node,destination_node,arc_weight)
				
						
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		
		# Creating a list, y, which contains strings of all paths withing the directory folder
		y = glob(r'{}\*'.format(directory))
		
		
		# Iterating through the list, y.
		for path in y:
			
			# Since the connections folder will not contain station_data.txt, the if statement avoids the connections folder
			if path != (r'{}\connections'.format(directory)):
			
				# Using the genfromtxt function to extract the 3 character location code, and the coordinates for each city from the station_data file
				[Type, Location] = np.genfromtxt(path + '\station_data.txt',dtype = 'str', delimiter = ':', skip_footer=2, unpack = 1)
				[type, Coordinates] = np.genfromtxt(path + '\station_data.txt',delimiter = ':', skip_header=1, unpack = 1)
				
				# Using the add_node function to create a node object for each location with the coordinates extracted as its value
				self.add_node(Location.lstrip(' '),Coordinates)
				
		
		
		
		# Creating a list, z, which contains all the paths within the connections folder within the directory as strings
		z = glob(r'{}\connections\*.txt'.format(directory))
		
		# Creating a list which will contain the names of the arcs in the network
		arc_titles = []
		
		# Iterating through the list, z.
		for file_name in z:
			
			# The string will be stripped of the all characters but the two location codes and the hyphen separating them. eg. ABC-EFG
			title = file_name.split('connections\\')[1].strip('.txt')
			# The title of the arc is added to the empty list
			arc_titles.append(title)
		
		
		# Creating a list which will contain the location codes for the from and to nodes for every arc
		from_to=[]

		for name in arc_titles:
			
			# Removing the hyphen bewteen the two location nodes and storing both strings in the list
			from_to.append(name.split('-'))
		
		
		# Creating a list which will contain the connection weights for all the arcs
		c_weights = []
		
		for name in z:
			
			# Using genfromtxt to create a vectors for both time (Tm) and capacity (Cap) data given in the station_data.txt for each connection 
			[Tm,Cap] = np.genfromtxt(name, delimiter = ',', skip_header=1, unpack = 1)
			
			# Finding the mean capacity for every connection
			Cap_mean = np.mean(Cap)
			
			# Appending the mean capacity to the list
			c_weights.append(Cap_mean)
		
		# Creating a counter, i
		i = 0

		for name in from_to:
			
			# Getting the from and to nodes for each element in the list
			from_Node = self.get_node(name[0])
			to_Node = self.get_node(name[1])
			
			# Joining the from and to nodes with the connection weight
			self.join_nodes(from_Node,to_Node,c_weights[i])
			# Incrementing the counter
			i = i +  1
			
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
