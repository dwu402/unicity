# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	

#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError		
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		
		#Create empty Node object
		node = Node() 
		
		#Assign name and value of the node to user inputs 
		node.name = name
		node.value = value
		
		#append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		#Form empty Arc object
		arc = Arc()
		
		#Assign weight, source node and destination node based on user inputs
		arc.weight = weight 
		arc.to_node = node_to 
		arc.to_node = node_to 
		arc.from_node = node_from
		
		#Append the new connection to the arcs_in and arcs_out to node_to and node_from respectively
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		self.arcs.append(arc)
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''

				
		# open the file (read mode)
		fp = open(filename, 'r')
		
		# get first line
		ln = fp.readline().strip()
		
		while ln is not '':        # keep looping to the end of the file
		
			# split string into source node name and other arcs using split() method for strings
			info = ln.split(',')
			from_node_name = info[0] 
			arcs = info[1:] 
			
			# get the source node. If node doesn't exist, add to network
			try:
				self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
					
			# get the source node object
			orig = self.get_node(from_node_name)	
				
			# read the arc information and add to network
			for arc in arcs:
			
				#Use split() to differentiate between destination node and magnitude of the arc
				arc_inf = arc.split(';')
				
				node_dest = arc_inf[0]
				node_mag = float(arc_inf[1])
				
				#Get the source node or create new node object if it doesn't already exist
				try:
					self.get_node(node_dest)
				except NetworkError:
					node = self.add_node(node_dest)
				
				
				node_to = self.get_node(node_dest) 
				
				#Join the source node to the destination node (create arc)
				self.join_nodes(orig, node_to, node_mag)
				
				
						
			# get next line
			ln = fp.readline().strip()
		
		

#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	
	def read_network(self, directory):
		''' Read network information from DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for 
			connections between nodes. All other folders define
			the nodes of the network. 
			
			Each node folder contains a file called station_data.txt that includes a code for the node (this should be used to name the
			node) and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected 
			(from-to) and the contents of the file record the capacity of 
			the connection over the previous 35 years. The connection weight
			is the mean capacity.
		'''
		
		#identify all directories containing the station_data.txt file using glob
		
		stations = glob(directory+os.sep+'*'+os.sep+'station_data.txt')
		
		 
		#create a for loop that iterates through the directories with station_data.txt
		for stat in stations:
		
			#Use genfromtxt() to store information infront of ': ' (which contains) the 
			#station/node name, x coordinate and y coordinate.
			[__, code_locs] = np.genfromtxt(fname = stat, delimiter = ': ', unpack = 1, dtype = str )
			
			#identify node name as well as convert x y coordinates to integer values
			node = code_locs[0]
			x = int(code_locs[1])
			y = int(code_locs[2])
			
			#find the node or add it if it does not already exist. 
			try:
				self.get_node(node)
			
			except NetworkError: 
				new_node = self.add_node(node,value = [x, y])
			
		#use glob() to find all directories of files within connections	folder	
		connections = glob(directory+os.sep+'connections'+os.sep+'*')
		
		#iterate through connections (file directories in connections folder)
		for link in connections: 
			
			#Use split() to find the last instance of '\\' i.e. the file name at the end of the directory
			*useless, from_to = link.split('\\')
			
			#remove the extension
			from_to = from_to.strip('.txt')
			
			#use split() again to find the source and destination nodes specified in the filename
			source_node, dest_node = from_to.split('-')
			
			#use genfromtxt to obtain list of capacities (2nd column)  
			[__, capacity] = np.genfromtxt(fname = link, delimiter = ', ', unpack = 1, skip_header = 1)
			
			#find and store the mean of  capacity list
			avgcapacity = np.mean(capacity)
			
			#get the source and destination nodes 
			source = self.get_node(source_node)
			dest = self.get_node(dest_node)
			
			#join the nodes (stations) with an arc of magnitude equivalent to the mean capacity
			self.join_nodes(source, dest, avgcapacity)
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()	
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
