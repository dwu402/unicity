import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.to_stat = stat_to
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			info = ln.split(',')
			from_stat_name = info[0]
			conns = info[1:]
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			orig = self.query_station(from_stat_name)
			for conn in conns:
				conn_inf = conn.split(';')
				stat_dest = conn_inf[0]
				stat_mag = float(conn_inf[1])
				try:
					self.query_station(stat_dest)
				except GridError:
					stat = self.add_station(stat_dest)
				stat_to = self.query_station(stat_dest)
				self.add_connection(orig, stat_to, stat_mag)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		stations = glob(directory+os.sep+'*'+os.sep+'info.txt')
		for stat in stations:
			[__, code_locs] = np.genfromtxt(fname = stat, delimiter = ': ', unpack = 1, dtype = str )
			stat = code_locs[0]
			x = int(code_locs[1])
			y = int(code_locs[2])
			try:
				self.query_station(stat)
			except GridError:
				new_stat = self.add_station(stat,value = [x, y])
		connections = glob(directory+os.sep+'backbone'+os.sep+'*')
		for link in connections:
			*useless, from_to = link.split('\\')
			from_to = from_to.strip('.txt')
			source_stat, dest_stat = from_to.split('-')
			[__, capacity] = np.genfromtxt(fname = link, delimiter = ', ', unpack = 1, skip_header = 1)
			avgcapacity = np.mean(capacity)
			source = self.query_station(source_stat)
			dest = self.query_station(dest_stat)
			self.add_connection(source, dest, avgcapacity)
