# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
class Network(object):
	''' Basic network class.
	'''
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		#Create the node and assign its values
		node = Node()
		node.name = name
		node.value = value

		self.nodes.append(node)	#Append node onto list of nodes
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''

		#Creating an arc class
		arc = Arc()
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from

		#Adding nodes from and nodes to to the arcs in and arcs out arrays
		node_to.arcs_in.append(arc)
		node_from.arcs_out.append(arc)

		#Add arc to the list of arcs
		self.arcs.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		'''
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# divide the string using the split() method for strings, to extract source node data
			Line = ln.split(',')    
			Line = [i.split(';') for i in Line]

			# - extract the source node
			Source_node = Line[0][0]

			# - extract the remaining arcs
			arcs = Line[1:]

			# if node doesn't exist, add to network
			try:
				#The output is a node object, the input is a string
				#This command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(Source_node)           
			except NetworkError:
					#This command gets executed if an error is raised above
				self.add_node(Source_node) #Adds node if it does not exist
				
			#Get the source node object, using the source node STRING
			Source_Node = self.get_node(Line[0][0])
				
			#Read the arc information and add it to network
			for arc in arcs:
				try:
					# The output is a node object, the input is a string
					# This command raises an ERROR if the node DOESN'T exist
					from_node = self.get_node(arc[0])           
				except NetworkError:
					# This command gets executed if an error is raised above
					self.add_node(arc[0]) #Adds node if it does not exist					
					from_node = self.get_node(arc[0]) 

				#Extract weight data
				weight = arc[1]
				self.join_nodes(Source_Node,from_node, weight)	#Join nodes together 
				
			# get next line			
			ln = fp.readline().strip()

class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''		
	def read_network(self, directory):

		#Find the nz_network directory
		output = glob('nz_network/*')
		#remove the connections folder from output array, as all we want to do is station data
		output.remove('nz_network/connections') 

		#In this segment, all of the nodes are acquired and added to the nodes array. 
		#Their values and location are saved.
		for i in range(len(output)): 
			if os.path.isdir(output[i]):	
				#Create the arrays from which values and location can be found
				NodeData = np.genfromtxt(output[i] + os.sep + 'station_data.txt',delimiter = ':', dtype= str, skip_footer = 2 ).T
				Location = np.genfromtxt(output[i] + os.sep + 'station_data.txt',delimiter = ':', dtype= str, skip_header = 1 ).T

				Location = [int(i) for i in Location[1]]
				node = str(NodeData[1])	

				self.add_node(node[1:],Location)	#Add node to the network

		#Now we are going to extract all of the arc data, and join them to the 
		#nodes
		output = glob('nz_network/connections/*') #Find the connections directory

		for i in range(len(output)):
			if os.path.isfile(output[i]): 

				DataFromConnections = np.genfromtxt(output[i] ,delimiter = ',', dtype= str, usecols = 1).T
				Arc_Weight = 0	#Initialise arc weight as 0
				for j in range(1,len(DataFromConnections)):
					Arc_Weight = Arc_Weight + float(DataFromConnections[j])	#Find the sum of weights		
				Arc_Weight = Arc_Weight / (j)	#Find the average value for the weight of the arc

				#Find the start and end nodes as strings
				Start_Node = str(output[i][23:26])
				End_Node = str(output[i][27:30])

				#Using the strings of the start and end nodes, use get node to extract the node object from node value.
				node_from = self.get_node(Start_Node)
				node_to = self.get_node(End_Node)

				#Join the two nodes together, with associated arc weight.
				self.join_nodes(node_from ,node_to ,Arc_Weight)
	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
