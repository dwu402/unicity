# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

        
# these classes and methods are complete, do not modify them
class Node(object):
        def __init__(self):
                self.name = None
                self.value = None
                self.arcs_in = []
                self.arcs_out = []
        def __repr__(self):
                return 'nd:{}'.format(self.name)
class Arc(object):
        def __init__(self):
                self.weight=None
                self.to_node = None
                self.from_node = None
        def __repr__(self):
                return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
        '''An error to raise when violations occur.
        '''
        pass
                
        
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
        ''' Basic network class.
        '''
        # these methods are complete, do not modify them
        def __init__(self):
                self.nodes = []
                self.arcs = []
        def __repr__(self):
                return 'ntwk'
        def get_node(self, name):
                ''' Loops through the list of nodes and returns the one with NAME.
                
                    Returns NetworkError if node does not exist.
                '''
                # loop through list of nodes until node found
                for node in self.nodes:
                        if node.name == name:
                                return node
                
                raise NetworkError
        def display(self):
                ''' Print information about the network.
                '''
                # print nodes
                print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
                # print arcs
                for arc in self.arcs:
                        print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
        
        # **these methods are incomplete, you must complete them as part of the lab task**
        def add_node(self, name, value=None):
                '''Adds a Node with NAME and VALUE to the network.
                '''
                # **to do: create an empty node object, assign its attributes**
                # **hint 1: how is an empty network object created in lab5_practice.py?**
                # **hint 2: take a look Section 0.6 in python101.ipynb, particularly attribute assignment**  
                # **hint 3: what values do the method arguments NAME and VALUE take when the method is called 
                #           in lab5_practice.py?**
                # **hint 4: what does the input argument 'self' represent in this method?**
                                
                # 1. WRITE PSEUDOCODE BELOW (optional, recommended)
                # create empty network/object
                #assign value and name to empty network/object
                #get the new node
                node=Node() 
                node.name=name
                node.value=value   
           
                # 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
                # ___
                                
                # 3. THINK VERY CAREFULLY ABOUT WHAT THE NEXT COMMAND IS DOING
                # append node to the list of nodes
                self.nodes.append(node)
                
        def join_nodes(self, node_from, node_to, weight):
                '''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
                '''
                # **to do: create an empty arc object, assign its attributes**
                # **hint: both input nodes have lists called arcs_in and arcs_out.
                # **   - what information do these store?
                # **   - because they are lists, they can be modified using the append method
                
                # 1. WRITE PSEUDOCODE BELOW (optional, recommended)
                # create arc
                #link to nodes
                #use arc in/out to tell nodes that arc exists
                #append arc, add it to network
                arc=Arc()
                arc.weight=weight
                arc.to_node=node_to
                arc.from_node=node_from

                node_from.arcs_out=[arc]
                node_to.arcs_in=[arc]

                self.arcs.append(arc)

   
        
                # 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
                # ___
                
                # **delete the placeholder command below once you have written your code**
                pass
                
        def read_network(self, filename):
                '''Read data from FILENAME and construct the network.
                
                        Each line of FILENAME contains
                         - the name of an origin node (first entry)
                         - and destination;weight pairs (each pair separated by a comma)
                         #(use comma as delimiter)
                '''
                # **to do**
                # **hint: inspect 'network.txt' so that you understand the file structure**
                # **hint: each source-destination node pair needs to be joined
                
                # **some useful (incomplete) code snippets**
                # ln.split
                #
                # 
                
                # 1. THE PSEUDOCODE FOR THIS METHOD HAS ALREADY BEEN WRITTEN BELOW
                                
                # open the file
                fp = open(filename, 'r')
                
                # get first line (a string)
                # - strip() is a useful method that removes white-space from the beginning and 
                #   end of the string
                n,a=np.genfromtxt('network.txt',delimiter=",")
                ln = fp.readline().strip()
                while ln is not '':        # keep looping to the end of the file
                        # divide the string using the split() method for strings
                        # - extract the source node
                        # - extract the remaining arcs
                        # ___
                        line=ln.strip().split(',')
                        source=line[1]
                        arcs=[]
                        for i in range(1,len(line)):
                                arcs.apppend(line[i])
                        

                        
                        # YOU WILL NEED TO THINK CAREFULLY ABOUT WHAT THIS TRY/EXCEPT BLOCK DOES
                        # if node doesn't exist, add to network
                        try:
                                # the output is a node object, the input is a string
                                # this command raises an ERROR if the node DOESN'T exist
                                from_node = self.get_node(from_node_name)           
                        except NetworkError:
                                # this command gets executed if an error is raised above
                                self.add_node(from_node_name)
                                
                        # get the source node OBJECT, using the source node STRING
                        # ___
                                
                        # read the arc information and add it to network
                        for arc in arcs:
                                # parse arc information
                                # ___
                                
                                # get destination node object and link it to source node
                                # ___
                                for i in range (len(arcs)) :
                                        n,w=arcs[i].split(';')
                                        join_nodes(self,source,n,w)

                                
                                # delete the placeholder command below when you start writing your code
                                #pass
                                                
                        # get next line
                        # ___
                        
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
        ''' Derived Network class, for NZ networks.
        '''     
        
        # **this method is incomplete, you must complete it as part of the lab task**
        def read_network(self, directory):
                ''' Read network information from input string DIRECTORY
                #read all files except connections
                #assign node name, store x, y values to name, create node.
                #add node to network (self.nodes)
                #read connections, file name is to/from node
                #arc weight= mean capacity (right side of txt added/35) for 35 yrs or /len(list)

                #if statement? only one file in directory, make nodes
                #else skip //
                #add arcs using connections dir
                        Notes:
                        ------
                        Assume that DIRECTORY contains one folder for connections between nodes. 
                        All other folders define the nodes of the network. 
                        
                        Each node folder contains a file called station_data.txt
                        This file includes the node name and x and y values for the node position.
                        
                        In the connections folder, there is a file for each connection.
                        The name of the file indicates which two nodes are connected (from-to).
                        The contents of the file record the capacity of that connection over the last 35 years.
                        The connection (arc) weight should be the mean capacity.
                '''
                #add nodes
                #access the relevant files
                output=glob('nz_network\\nz_network\\*')
                for i in range (len(output)):
                        try: #for all the folders try:
                            name,info=np.genfromtxt(os.path.join(output[i],"station_data.txt"),delimiter=':',skip_header=0, dtype = 'unicode').T #get info from the file           
                            name=info[0].strip() #get node names
                            
                            value=[] #create empty list
                            value.append(float(info[1])) #add x value
                            value.append(float(info[2])) #add y value
                            self.add_node(name,value) #info contains node name, x and y values
                        except: #if an error occurs, continue with next folder in directory
                                continue

#add arcs
                output=glob('nz_network\\nz_network\\connections\\*') #list of filenames in 'connections
                for i in range (len(output)):
                        node_f,node_t=output[i].split('-') #filename is from/to node
                       # split the path name so the from_node name is seperate 
                        path_from=(node_f.split(os.sep))
                       #get the from_node
                        node_from=self.get_node(path_from[3])
                        node_to=self.get_node((node_t.split('.'))[0]) #split the to_node and get the to_node
                        t,c=np.genfromtxt(output[i],delimiter=',',skip_header=1,dtype=float).T #file content is arc weight, store in value c
                        mean_capacity=sum(c)/35 #find the mean arc weight
                        self.join_nodes(node_from,node_to,mean_capacity) #make arc


                
                # **some useful functions**
                # glob
                # np.genfromtxt
                # os.path.isdir
                # ___
                
                # **delete the placeholder command below once you have written your code**
               # pass
        
        # this method is complete, do not modify        
        def show(self, save=None):
                ''' Plot the network and optionally save to file SAVE
                '''
                # create figure axes
                fig=plt.figure()
                fig.set_size_inches([10,10])
                ax=plt.axes()
                
                # NZ coastline as background
                img=mpimg.imread('bg.png')
                ax.imshow(img,zorder=1)
        
                # a filthy hack to get coordinates in the right spot...
                for node in self.nodes:
                        x,y = node.value
                        y = int((y+10)*1.06)
                        x -= int(50*y/800.)
                        node.value = [x,y]
        
                # draw nodes as text boxes with station names
                        # bounding box properties
                props = dict(boxstyle='round', facecolor='white', alpha=1.0)
                for node in self.nodes:
                        # extract coordinates
                        x,y = node.value
                        ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
                        
                # draw connections as lines
                weights = [arc.weight for arc in self.arcs]
                        # scale for plotting connections
                wmin = np.min(weights)
                wmax = np.max(weights)
                lmin,lmax = [0.5, 10.0]
                
                # plot connections
                for arc in self.arcs:
                        # compute line length, scales with connection size
                        lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
                        x1,y1 = arc.from_node.value
                        x2,y2 = arc.to_node.value
                        ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
        
                # remove ticks
                ax.set_xticks([])
                ax.set_yticks([])
        
                # display options
                if save:
                        # save to file
                        plt.savefig(save, dpi=300)
                        plt.close()
                else:
                        # open figure window in screen
                        plt.show()
        
        
                
                
                
                
                
                
                
                
                
                        
