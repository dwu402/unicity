import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
    def __init__(self):
        self.id = None
        self.val = None
        self.cons_in = []
        self.cons_out = []
class Connection(object):
    def __init__(self):
        self.wgt= None
        self.to_stat = None
        self.from_stat = None
class GridError(Exception):
    pass
class Grid(object):
    def __init__(self):
        self.stations = []
        self.connections = []
    def query_station(self, name):
        for stat in self.stations:
            if stat.id == name:
                return stat
        raise GridError
    def add_station(self, name, value=None):
        stat = Station()
        stat.id = name
        stat.val = value
        self.stations.append(stat)
    def add_connection(self, stat_from, stat_to, weight):
        conn = Connection()
        conn.wgt = weight
        conn.from_stat = stat_from
        conn.to_stat = stat_to
        self.connections.append(conn)
        stat_from.cons_out.append(conn)
        stat_to.cons_in.append(conn)
    def read(self, filename):
        fp = open(filename, 'r')
        ln = fp.readline().strip()
        while ln is not '':        
            try:
                from_stat_name, conns = ln.split(",",1) 
                conns = conns.split(",")  
            except:
                from_stat_name = ln     
                conns = []   
            try:
                self.query_station(from_stat_name) 
            except GridError:
                self.add_station(from_stat_name)   
            source = self.query_station(from_stat_name)  
            for conn in conns:
                conn = conn.split(";")    
                try:
                    self.query_station(conn[0]) 
                except:
                    self.add_station(conn[0]) 
                    target = self.query_station(conn[0]) 
                self.add_connection(source, target, conn[1]) 
            ln = fp.readline().strip()
class Roads(Grid):
    def read(self, directory):
        files = glob("roads_grid" + os.sep + "*")   
        for file in files:  
            if os.path.isdir(file): 
                if file != "roads_grid/connections" and file != "pycache": 
                    fp = open(file + os.sep + "info.txt", "r")  
                    ln = fp.readline().strip()
                    temp_splt = ln.split(": ")
                    station_name = temp_splt[1]
                    ln = fp.readline().strip()
                    x_splt = ln.split(": ")
                    x_coord = int(x_splt[1]) 
                    ln = fp.readline().strip()
                    y_splt = ln.split(": ")
                    y_coord = int(y_splt[1]) 
                    xy = [x_coord, y_coord]
                    self.add_station(station_name, xy)
        files = glob("roads_grid" + os.sep + "connections" + os.sep + "*")
        for file in files:
            s = file.split(os.sep) 
            txtFileName = s[2] 
            txtFileName = txtFileName.strip(".txt") 
            array = txtFileName.split("-") 
            from_stat = self.query_station(array[0]) 
            stat_to = self.query_station(array[1])   
            fp = open(file)
            [time, capacity] = np.genfromtxt(file, delimiter = ", ", skip_header = 1, unpack = 1)
            mean_capacity = np.mean(capacity)
            self.add_connection(from_stat, stat_to, mean_capacity)
