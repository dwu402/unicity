import numpy as np
[Xs, Ts] = np.genfromtxt('example_file.txt', delimiter = ", ", skip_header = 1, unpack = 1)
