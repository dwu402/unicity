import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value = None):
		stat = Station()
		stat.id = name
		stat.val = value
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.to_stat = stat_to
		conn.from_stat = stat_from
		conn.wgt = weight
		new_stat = self.query_station(stat_from.id) 
		new_stat.cons_out.append(conn) 
		new_stat = self.query_station(stat_to.id) 
		new_stat.cons_in.append(conn) 
		self.connections.append(conn) 
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':        
			conns = [0, 0] 
			if len(ln) == 9: 
				from_stat_name,conns[0],conns[1] = ln.split(',')
			elif len(ln) == 5: 
				from_stat_name,conns[0] = ln.split(',')
			else: 
				from_stat_name = ln
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			source_stat = self.query_station(from_stat_name)
			for conn in conns: 
				if conn == 0: 
					return
				ln2 = conn
				to_stat_name,weight = ln2.split(';') 
				try:
					self.query_station(to_stat_name)
				except GridError:
					self.add_station(to_stat_name)
				destination_stat = self.query_station(to_stat_name)
				conn = self.add_connection(source_stat,destination_stat,weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		directory_list = glob(directory+'\*')
		for folder in directory_list:
			if folder == 'roads_grid\connections':
				continue
			if os.path.isdir(folder) == False:
				continue
			fp = open(folder+'\info.txt', 'r') 
			ln = fp.readline().strip() 
			while ln is not '':
				ln = ln.split(' ')
				if ln[0] == 'code:':
					station_name = ln[1] 
				if ln[0] == 'x:':
					x = float(ln[1])
				if ln[0] == 'y:':
					y = float(ln[1])
				ln = fp.readline().strip() 
			try:
				self.query_station(station_name)
			except GridError:
				self.add_station(station_name) 
			station = self.query_station(station_name) 
			station.val = ([x,y]) 
		all_connections = glob(directory+'\connections\*.txt') 
		for connected_stations in all_connections:
			(t,c) = np.genfromtxt(connected_stations, delimiter = ',', skip_header = 1, unpack = True)
			average_connection = np.mean(c)
			connected_stations = connected_stations.split('-')
			connected_stations[0] = connected_stations[0].replace('roads_grid\\connections\\','')
			try:
				self.query_station(connected_stations[0])
			except GridError:
				self.add_station(connected_stations[0]) 
			stat_from = self.query_station(connected_stations[0]) 
			connected_stations[1] = connected_stations[1].replace('.txt','')
			try:
				self.query_station(connected_stations[1])
			except GridError:
				self.add_station(connected_stations[1]) 
			stat_to = self.query_station(connected_stations[1]) 
			self.add_connection(stat_from,stat_to,average_connection) 
