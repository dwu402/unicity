import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
class Station(object):
	def __init__(self):
		self.id = None
		self.val = None
		self.cons_in = []
		self.cons_out = []
class Connection(object):
	def __init__(self):
		self.wgt=None
		self.to_stat = None
		self.from_stat = None
class GridError(Exception):
	pass
class Grid(object):
	def __init__(self):
		self.stations = []
		self.connections = []
	def query_station(self, name):
		for stat in self.stations:
			if stat.id == name:
				return stat
		raise GridError
	def add_station(self, name, value=None):
		stat = Station()
		stat.id = name
		stat.val = value
		stat.cons_in = []
		stat.cons_out = []
		self.stations.append(stat)
	def add_connection(self, stat_from, stat_to, weight):
		conn = Connection()
		conn.wgt = weight
		conn.from_stat = stat_from
		conn.to_stat = stat_to
		stat_from.cons_out.append(conn)
		stat_to.cons_in.append(conn)
		self.connections.append(conn)
	def read(self, filename):
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while (ln != ''):
			line_array = ln.split(",")
			from_stat_name = line_array[0]
			x = len(line_array)
			try:
				self.query_station(from_stat_name)
			except GridError:
				self.add_station(from_stat_name)
			self.query_station(from_stat_name)
			for i in range (1,x):
				A = line_array[i]
				dest, weight = A.split(";")
				try:
					self.query_station(dest)
				except GridError:
					self.add_station(dest)
				self.add_connection(self.query_station(from_stat_name), self.query_station(dest), weight)
			ln = fp.readline().strip()
class Roads(Grid):
	def read(self, directory):
		connections_list = glob('%s/connections/*.txt' % directory)
		stripped_list = [j.strip('%s/connections/*.txt' % directory) for j in connections_list]
		lengthofconnectionlist = len(stripped_list)
		stationdata = glob('%s/**/*.txt' % directory)
		station_list = []
		for v in stationdata:
			if v not in connections_list:
				station_list.append(v)
		lengthofstationlist = len(station_list)
		for k in range(0, lengthofstationlist):
			s = station_list[k]
			stationinfo = np.genfromtxt(s, delimiter=': ',  skip_header=0, dtype = None, usecols=1)
			value = [int(stationinfo[1]), int(stationinfo[2])]
			try:
				self.query_station(stationinfo[0])
			except GridError:
				self.add_station(stationinfo[0], value)
		for i in range(0, lengthofconnectionlist):
			s = connections_list[i]
			Capacity = np.genfromtxt(s, delimiter=', ',  skip_header=1, dtype = float, usecols=1)
			weight = np.mean(Capacity)
			from_stat, to_stat = stripped_list[i].split("-")
			self.add_connection(self.query_station(from_stat), self.query_station(to_stat), weight)
