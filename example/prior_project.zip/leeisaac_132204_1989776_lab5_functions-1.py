# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
			Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint 1: how is an empty network object created in lab5_practice.py?**
		# **hint 2: take a look Section 0.6 in python101.ipynb, particularly attribute assignment**  
		# **hint 3: what values do the method arguments NAME and VALUE take when the method is called 
		#           in lab5_practice.py?**
		# **hint 4: what does the input argument 'self' represent in this method?**
				
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# **your pseudocode here**
		
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		# ___

		#-----------------------------------------------------------------------------

		node = Node() # create empty node object
		node.value = value # assign value and name to the node attribute
		node.name = name

		#-----------------------------------------------------------------------------

		# 3. THINK VERY CAREFULLY ABOUT WHAT THE NEXT COMMAND IS DOING
		# append node to the list of nodes in network
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both input nodes have lists called arcs_in and arcs_out.
		# **   - what information do these store?
		# **   - because they are lists, they can be modified using the append method
		
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# ___
				
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		# ___
		
		#-----------------------------------------------------------------------------

		# create an empty arc object
		arc = Arc()
		arc.weight = float(weight) # assign its attributes (weight, to_node, from_node)
		arc.to_node = node_to
		arc.from_node = node_from

		self.arcs.append(arc) # append the arc to the list of arcs in network
		# append the arc to the arcs_out list in node_from
		# and arcs_in list in node_to
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)

		#-----------------------------------------------------------------------------

		# **delete the placeholder command below once you have written your code**
		
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination node pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
		
		# 1. THE PSEUDOCODE FOR THIS METHOD HAS ALREADY BEEN WRITTEN BELOW
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		# - strip() is a useful method that removes white-space from the beginning and 
		#   end of the string
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# divide the string using the split() method for strings
			# - extract the source node
			# - extract the remaining arcs
			# ___

			#-----------------------------------------------------------------------------
			
			# split the line by a comma, first entry is a origin node,
			# from second element to the last contains destination node with arc weight
			from_node_name = ln.split(',')[0]
			arcs = ln.split(',')[1:]

			#-----------------------------------------------------------------------------
			
			# YOU WILL NEED TO THINK CAREFULLY ABOUT WHAT THIS TRY/EXCEPT BLOCK DOES
			# if node doesn't exist, add to network
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(from_node_name)           
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(from_node_name)

			#-----------------------------------------------------------------------------
				
			# get the source node OBJECT, using the source node STRING			
			from_node = self.get_node(from_node_name)

			#-----------------------------------------------------------------------------
				
			# read the arc information and add it to network
			for arc in arcs:
				# parse arc information
				# ___
				
				#-----------------------------------------------------------------------------

				# get destination and arc weight from arc information
				to_node_name, weight = arc.split(';')

				# get the node object, using the node string
				# if the node is not already in the network add the node to the network
				try:
					to_node = self.get_node(to_node_name)           
				except NetworkError:
					self.add_node(to_node_name)	
				to_node = self.get_node(to_node_name)
				
				# join nodes with from_node object, to_node object and arc weight
				self.join_nodes(from_node,to_node,weight)
														
			# get next line
			ln = fp.readline().strip()
			
		# close the file
		fp.close()
		#-------------------------------------------------------------------------------
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		# ___

		#-----------------------------------------------------------------------------

		# find PATHS to all files and folders inside the directory
		path_list_dir = glob(directory+os.sep+'*')
		
		# use for loop to add stations to the network
		for path in path_list_dir:
			# if 'connections' is not in pathname extract station information from the file inside that path
			if 'connections' not in path:
				# extract the data from the file 'station_data.txt' that contains station name,
				# station value(x,y coordinates). we will separate data by ':' and only read column 1
				data = np.genfromtxt(path+os.sep+'station_data.txt', delimiter = ': ', skip_header=0, dtype =str, usecols = 1).T
				data = data.tolist() # genfromtxt() returns data in an array, so we will change it as a list for easier handling
				name = data[0] # get station name and its value(x and y coordinates for the node position) from the data
				value = data[1:]
				
				# value is currently in string type, change all the element in the value list as a float 
				for i in range(len(value)):
					value[i] = float(value[i])
				
				# add station to the network
				self.add_node(name,value)
		
		# add connections between stations
		# extract list of all files in 'connections' folder
		connections_list = glob(directory+os.sep+'connections'+os.sep+'*')
		# run for loop for every file in connections folder
		for arc_data in connections_list:
			# take out unnecessary strings from the pathname string so that we are only left with the file name
			# The name of the file indicates which two nodes are connected (from-to)
			from_node,to_node = arc_data.strip(directory+os.sep+'connections').strip('.txt').split('-')
			
			# extract the data from the file which record the capacity of that connection over the last 35 years.
			# we are only interested in capacity so only read column 1
			capacity_list = np.genfromtxt(arc_data, delimiter = ', ', skip_header=1, dtype =float, usecols = 1).T
			capacity_list = capacity_list.tolist() # genfromtxt returns an array, change it to list for easier handling
			
			capacity_sum = 0 # initialise capacity_sum
			# calculate the mean capacity by adding up all the numbers, then divide by how many there are
			for capacity in capacity_list:
				capacity_sum += capacity
			weight = capacity_sum/len(capacity_list)
			
			# get station(node object) from the network
			node_from = self.get_node(from_node)
			node_to = self.get_node(to_node)
			
			# join stations with the connection
			self.join_nodes(node_from,node_to,weight)
			
		#-----------------------------------------------------------------------------


		# **delete the placeholder command below once you have written your code**
		
		

	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
