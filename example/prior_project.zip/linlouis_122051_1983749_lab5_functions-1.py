# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - [COMPLETED] the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# Imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
	
# These classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass

class Network(object):
	''' Basic network class.
	'''
	# These methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		    Returns NetworkError if node does not exist.
		'''
		# Loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# Print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# Print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		node = Node()							# Create an empty Node object
		node.name = name						# Assign name attribute 
		node.value = value						# Assign value attribute
		self.nodes.append(node)					# Append node to the list of network nodes

	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''	
		arc = Arc()								# Create an empty Arc object
		arc.weight = weight						# Assign arc weight attribute
		arc.to_node = node_to					# Assign to-node attribute
		arc.from_node = node_from 				# Assign from-node attribute
		node_from.arcs_out.append(arc)			# Append arc to the list of out-arcs of from-node
		node_to.arcs_in.append(arc)				# Append arc to the list of in-arcs of to-node
		self.arcs.append(arc)					# Append arc to the list of network arcs
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
		'''	
		network_info = open('network.txt', 'r')			# Open the file
		ln = network_info.readline()					# Read the first line
		
		while ln is not '':        				# Keep looping to the end of the file
			ln = ln.strip()						# Strip off \n 
			split_ln = ln.split(',')			# Divide the string using the split() method for strings
			
			from_node = Node()
			from_node.name = split_ln[0]		# Extract the source node
			arcs = []								
			i = 1
			while (i < len(split_ln)):			# Extract the arcs
				arcs.append(split_ln[i])		# Add arc to a list containing arc information
				i += 1
			
			try:										# If node doesn't exist, add to network
				from_node = self.get_node(from_node)    # Command raises an error if the node DOESN'T exist      
			except NetworkError:
				self.add_node(from_node)				# Add node to network if error is raised			
			
			for i in range (0, len(arcs)):						# Read the arc information and add it to network
				to_node = Node()
				to_node.name, weight = arcs[i].split(';')		# Parse arc information
				weight = float(weight)							# Convert string to float
				self.join_nodes(from_node, to_node, weight)		# Get destination node object and link it to source node
						
			ln = network_info.readline()		# Read next line
			

class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		from glob import glob						# Imports
		all_files = glob(directory+os.sep+'*')		# Finding all files in directory
		node_files = []								# Empty list containing files of nz_network

		for file in all_files:						# Separating connections file from all other subfiles
			subfiles = glob(file+os.sep+'*')		
			if len(subfiles)>1:						# Finds connections subfile
				connections_file = subfiles
			else:									# All other subfiles are appended to another list
				node_files.append(file)
		
		for file in node_files:																			# Adding nodes to the network									
			location_file = glob(file+os.sep+'*')														# Extract file
			node = Node()		
			value = []																		
			code = np.genfromtxt(location_file[0], dtype = str, delimiter = ': ', usecols = (1))		# Extract location code
			node.name = code[0]																			# Assign name attribute
			coord = np.genfromtxt(location_file[0], dtype = int, delimiter = ': ', usecols = (1))		# Extract location coordinates
			value.append(coord[1])																		
			value.append(coord[2])																		
			node.value = value																			# Assign value attribute
			self.nodes.append(node)																		# Add node to network
			
		for file in connections_file:						# Extracting information from subfiles in connections file
			filename = file.split('\\')[2]					# Get rid of file path												
			filename = filename.split('.')[0]				# Get rid of file predecessor
			from_node, to_node = filename.split('-')		# Assign to and from nodes
			for i in range(0, len(self.nodes)):											# Find the matching nodes
				if (from_node == self.nodes[i].name):									# If from_node matches existing node 
					from_node = self.nodes[i]											# from_node is assigned
				if (to_node == self.nodes[i].name):										# If to_node matches existing node
					to_node = self.nodes[i]												# to_node is assigned
			capacities = np.genfromtxt(file, dtype = None, delimiter = ',', skip_header = 1, usecols = (1))		# Extracts capacity records
			total_capacity = 0																					
			for i in range(0,len(capacities)):											# Calculating mean capacity for connection
				total_capacity = total_capacity + capacities[i]												
			weight = total_capacity / len(capacities)															
			self.join_nodes(from_node, to_node, weight)									# Get destination node object and link it to source node

	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
		
		
		
		
		
		
		
			
