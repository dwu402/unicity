# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# Author: Ashton Matthee 120942168

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.from_node.name,self.to_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		
		node = Node()
		node.value = value
		node.name = name
				
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''	
		# IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		arc = Arc()
		arc.from_node = node_from
		arc.to_node = node_to
		arc.weight = weight

		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)

		self.arcs.append(arc)		
				
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''

		# open the file
		fp = open(filename, 'r')
		
		# gets the first line in the file, removes white space
		ln = fp.readline().strip()
		
		# keeps looping until the end of the file
		while ln is not '':     
			# splits the line into source node and the nodes the source is connected to
			split_line = ln.split(',')
			source = split_line[0]
			del split_line[0]
			length_split_line = len(split_line)

			# when reached end of file, break out of the loop
			if (length_split_line == 0):
				break	
			else:
				# if there is only one arc connected to a node, the remade_line is the 
				# original split line
				if (length_split_line == 1):
					remade_line = split_line[0]	
				else:
					# joins together the split lines to remake a complete string
					remade_line = split_line[0] + ';' + split_line[1]
				# break up the remade string to separate the nodes and weights
				split_remade = remade_line.split(';')
				length_split_remade = len(split_remade)
			
				# This loop appends the names and weights of nodes separately into 2 
				# different arrays
				counter = 0
				nodes = []
				weights = []
				while (counter != length_split_remade):
					if (counter%2 == 0):
						nodes.append(split_remade[counter])
						counter = counter + 1
					else:
						weights.append(float(split_remade[counter]))
						counter = counter + 1			

				# this attempts to assign the source node
				try:
					# if the source node exists, this fetches it and assigns it
					from_node = self.get_node(source)           
				except NetworkError:
					# if source node does not exist, this creates the source node
					self.add_node(source)
					if (nodes[0] != source):
						from_node = self.get_node(source)

				# this loop creates the nodes that the source is connecting to
				counter3 = 0
				while (counter3 != length_split_line):
					counter2 = 0
					while (counter2 != length_split_line):
						try:
						# if the node exists assign it as the to_node
							to_node = self.get_node(nodes[counter2])
							counter2 = counter2 + 1           
						except NetworkError:
							# creates the node if it doesn't exist yet
							self.add_node(nodes[counter2])
							counter2 = counter2 + 1
					to_node = self.get_node(nodes[counter3])
					counter3 = counter3 + 1
					# creates an arc between the source node and a node it is connected to
					self.join_nodes(from_node,to_node, weights[counter3 - 1])
						
				# get next line in file
				ln = fp.readline().strip()

# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):	

	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		# this sets up arrays that will be used later
		nodes = []
		nodes_val = []
		nodes_from = []
		nodes_to = []
		cap_array = []
		weights =[]

		# this is modifying the path to examine the subfolders inside the directory
		next_dir = directory + '/*' 
		subfolders = glob(next_dir)

		# this loop will run through all folders contained within the directory we want
		for i in range (len(subfolders)):
			# looks at the folders and modifies paths and checks to see what files are 
			# contained in each folder
			if os.path.isdir(subfolders[i]):
				directory_path = subfolders[i]
				node_dir = directory_path + '/'
				files_in_dir = glob(node_dir + '*')
				files_in_dir = files_in_dir[0].split('\\')
				file_name = files_in_dir[-1]

				# if the folder contains this file, it is a node
				if (file_name == 'station_data.txt'):
					# opens the file and assigns the node code, and x and y values 
					fp = open(node_dir + '/' + 'station_data.txt','r')
					ln1 = fp.readline()
					ln2 = fp.readline()
					ln3 = fp.readline()
					node_code = ln1.strip().split(': ')[-1]
					node_x = ln2.strip().split(': ')[-1]
					node_x = float(node_x)
					node_y = ln3.strip().split(': ')[-1]
					node_y = float(node_y)

					# appends the code and values to two arrays
					node_value = [node_x, node_y]
					nodes.append(node_code)
					nodes_val.append(node_value)

					# closes the file
					fp.close()

				else:
					# the folder is the connections folder and contains files that give the weight and 
					# to and from nodes
					connections_folder = glob(node_dir + '*')
					for i in range(len(connections_folder)):
						# splits the name of the file into the 'to' and 'from' nodes
						file_name = connections_folder[i]
						split_nodes = connections_folder[i].strip().split('-')
						nodes_from.append(split_nodes[0].split('\\')[2])
						nodes_to.append(split_nodes[1].split('.')[0])

						# opens the file and reads the first two lines
						fp = open(file_name, 'r')
						cap_array = []
						ln = fp.readline().strip()
						i = 0
						ln = fp.readline().strip()

						# loops until the end of the file
						while ln is not '':
							# appends all the capacities (weights) in an array
							cap = float(ln.split(',')[-1])
							cap_array.append(cap)
							i = i+1
							ln = fp.readline().strip()
						# finds the mean of the capacities, this will be the weight of the arc	
						weight = np.mean(cap_array)
						weights.append(weight)

						fp.close()

		# goes through the completed arrays and adds them as nodes	
		nodes_length = len(nodes)  
		for i in range(nodes_length):
			self.add_node(nodes[i], nodes_val[i])

		# loops through all the arc weights and assigns them to nodes and connects them
		arcs_length = len(nodes_from) 
		for i in range(arcs_length):
			from_node = self.get_node(nodes_from[i])
			to_node = self.get_node(nodes_to[i])
			self.join_nodes(from_node, to_node, weights[i])


	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	