# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		
		# creates a new node object and adds the required attributes
		node = Node()
		node.name = name
		if value: node.value = value
				
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''

		# creates a new arc with the required attributes
		arc = Arc()
		arc.weight, arc.to_node, arc.from_node = [weight, node_to, node_from]

		# Adds this arc to each of the nodes involved
		node_to.arcs_in.append(arc)
		node_from.arcs_out.append(arc)

		# Appends arc to the list of arcs
		self.arcs.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
					
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# divide the string using the split() method for strings
			arcs = ln.split(',')
			# extract the source node
			from_node_name = arcs.pop(0)
			
			# if node doesn't exist, add to network
			try:
				from_node = self.get_node(from_node_name)
			except NetworkError:
				self.add_node(from_node_name)
				from_node = self.get_node(from_node_name)
				
			# read the arc information and add it to network
			for arc in arcs:
				# reads arc information
				to_node_name, weight = arc.split(';')

				# in theory, all the arcs should have been added already
				# but this will add the node if it was somehow skipped
				try:
					to_node = self.get_node(to_node_name)
				except NetworkError:
					self.add_node(to_node_name)
					to_node = self.get_node(to_node_name)
				
				# adds the arc to the network
				self.join_nodes(from_node, to_node, weight)
						
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		
		# check if the directory is valid
		if not os.path.isdir(directory):
			raise ValueError('Directory: ' + directory + ' - No such directory exists')

		data = glob(directory + '/*')

		# adds each node to the network
		for station in data:
			# skips the connections sub-directory
			if station == (directory + '\\connections'):
				continue

			# parses data from the text file and convert to appropriate types
			data =  np.genfromtxt(station + '\\station_data.txt', usecols = 1, dtype='unicode')
			station, x, y = [int(i) if i.isdigit() else str(i) for i in data]
			self.add_node(station, (x,y))
			
		# adds arcs between the nodes in the network
		for arc in glob(directory + '\\connections\\*'):
			# removes 'directoryName\connections\' and '.txt' from the filename to get node names
			index = len(directory) + 13
			from_node, to_node = arc[index:index + 7].split('-')

			# reads the connection's capacity data and computes the mean capacity.
			data = np.genfromtxt(arc, usecols = 1, skip_header = 1)
			mean = np.mean(data)

			self.join_nodes(self.get_node(from_node), self.get_node(to_node), mean)
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
