# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''

		# Define an empty node
		node = Node()
		# Set the node name and value
		node.name = name
		node.value = value
				
		# Append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
	
        # Create an empty arc object	
		arc = Arc()

		# Passing the attributes of the arc, including the to and from nodes 
		# and the weight
		arc.to_node  = node_to
		arc.from_node = node_from
		arc.weight = weight

		# Append the arc to the list of arcs
		self.arcs.append(arc)

		# Append arc in and arc out to the node
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)



	
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
				
		# Open the file
		fp = open('network.txt', 'r')
		
		# Get first line (a string)
		# Use the strip() command to remove white space from the ends of the string
		ln = fp.readline().strip()
		while ln is not '':        # Keep looping to the end of the file
			
			# Create a list using the split method
			Line1 = ln.split(',')

			# Allocate an array to store the final points from the line
			Line2 = []
			for i in Line1:
				# Add the points to the array Line2
				Line2.append(i.split(';'))
			
			for i in Line2:
				# Set the node name to the first point
				from_node_name = i[0][0]
				try:		
					# Check to see if node exists and raise an error if it doesn't 
					from_node = self.get_node(from_node_name)           
				except NetworkError:
					# If an error is raised, add the node to the network
					self.add_node(from_node_name)
			
			# get the source node OBJECT, using the source node STRING			
			source_node = self.get_node(Line2[0][0])
			for i in Line2[1::]:
				# Join the nodes
				self.join_nodes(source_node, self.get_node(i[0]), float(i[1]))

			arcs = self.arcs

			# read the arc information and add it to network
			for arc in arcs:
				# parse arc information
				destination = arc.to_node	
						
				# get destination node object and link it to source node
				destination.arcs_in.append(arc)

			# get next line in the file
			ln = fp.readline().strip()
			

class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	

	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		# Open the nz_network directory
		Files = glob('nz_network/*') 

		# Remove the connections file
		Files.remove('nz_network\\connections')
		

		for i in Files:
			# Open the file and read the first line
			fp = open(i+'\\station_data.txt', 'r')
			ln = fp.readline().strip()

			# Split the line using ': ' as a delimiter and store the second part as a string
			Header = ln.split(': ')
			nd = str(Header[1])
			
			# Read the second line and split it at the ':'
			ln2 = fp.readline().strip()
			xline = ln2.split(':')
			# Store the x value as an int
			x = int(xline[1])

			# Read the third line and split it at the ':'
			ln3 = fp.readline().strip()
			yline = ln3.split(':')
			# Store the y value as an int
			y = int(yline[1])

			# Create a position using the x and y values and add the node name and values to the network
			Position = [x,y]
			self.add_node(nd, Position)

		# Open the connections directory
		Connections = glob('nz_network/connections/*')

		# Allocate an array for arc weights
		weights = []
		# Use a for loop to iter through the connections files
		for i in Connections:

			# Open the file and put the data from the capacity column in an array
			fp = open(i,'r')
			ConnectionData = np.genfromtxt(fp, delimiter = ',', skip_header=1, usecols= (1))

			# Create a sum variable and start a for loop to go through the capacity array
			sum = 0
			for j in ConnectionData:
				# Add the capacity value to the sum
				sum = sum + j 

				# Calculate the weight by averaging the capacity values
				weight = sum/len(ConnectionData)
			
			# Append the weight to the weights array
			weights.append(weight)

		# Initialise arrays for the from nodes and to nodes
		from_nodes = []
		to_nodes = []

		# Create a for loop to go through each of the connection files
		for i in range(len(Connections)):
			
			# Read the connection name from the file and split the to and from 
			# nodes at the '-'
			Nds = Connections[i][23:30]
			names = Nds.split('-')
			# Add the to and from nodes to their arrays
			from_nodes.append(names[0])
			to_nodes.append(names[1])


		# Create a for loop to run through the number of files in the connections directory 
		for i in range(len(Connections)):

			# Get the to and from nodes and the weights from their respective arrays
			node_in = self.get_node(from_nodes[i])
			node_out = self.get_node(to_nodes[i])
			weight = weights[i]

			# Join the nodes using the join_nodes function
			self.join_nodes(node_in, node_out,weight)

	
		

	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
