# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# Imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# These classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight = None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.from_node.name,self.to_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		


class Network(object):
	''' Basic network class.
	'''
	# These methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# Loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# Print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# Print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint 1: how is an empty network object created in lab5_practice.py?**
		# **hint 2: take a look Section 0.6 in python101.ipynb, particularly attribute assignment**  
		# **hint 3: what values do the method arguments NAME and VALUE take when the method is called 
		#           in lab5_practice.py?**
		# **hint 4: what does the input argument 'self' represent in this method?**
				
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# ___
		
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE

		# Create an empty node
		node = Node()
		# Assign node name and value
		node.name = name
		node.value = value
		# Append the node to the nodes in the network
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both input nodes have lists called arcs_in and arcs_out.
		# **   - what information do these store?
		# **   - because they are lists, they can be modified using the append method
		
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# ___
				
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE

		# Create an empty arc
		arc = Arc()
		# Assign its 'from_node' and 'to_node' an weight
		arc.from_node = node_from
		arc.to_node = node_to
		arc.weight = weight
		# Append the arc to the arcs in the network
		self.arcs.append(arc)
		# Append the arc to the 'from_node' and 'to_node' attributes
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)

		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination node pair needs to be joined
		
		
		# 1. THE PSEUDOCODE FOR THIS METHOD HAS ALREADY BEEN WRITTEN BELOW
				
		# Open the file
		fp = open(filename, 'r')
		
		# Get first line and remove white space from the beginning and end of string
		ln = fp.readline().strip()

		# Keep looping til the end of the file
		while ln is not '':
			# Divide the string using the split() method
			line = ln.split(",")

			# Extract the source node
			from_node_name = line.pop(0)

			# If node doesn't exist, add to network
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(from_node_name)           
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(from_node_name)
				
			# get the source node OBJECT, using the source node STRING
			# Set from_node for join_nodes
			from_node = self.get_node(from_node_name)

			# Initialise lists for destination nodes and weights
			DestNodes = []
			Wts = []

			# Loop through all of the arcs in the line
			for i in range(len(line)):
				# Store the Destination Node and Weight in variables 'DN' and 'weight'
				DN,weight = line[i].split(';')
				# Append the Destination node and weight in the list
				DestNodes.append(DN)
				Wts.append(weight)

			# Loop through all of the Destination Nodes
			for i in range(len(DestNodes)):

				# If the Destination Node doesn't exist, add it to network
				try:
					# the output is a node object, the input is a string
					# this command raises an ERROR if the node DOESN'T exist
					to_node = self.get_node(DestNodes[i])           
				except NetworkError:
					# this command gets executed if an error is raised above
					self.add_node(DestNodes[i])
				
				# Get the destination node OBJECT, using the destination node STRING
				to_node = self.get_node(DestNodes[i])
				# Set the weight for join_nodes
				weight_arc = Wts[i]

				# Create the arc and set its weight attribute 
				self.join_nodes(from_node, to_node, float(weight_arc))
						
			# Get next line
			ln = fp.readline().strip()

		# Close file	
		fp.close()
			

class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		# Get all the node files
		Nodes = glob(directory+os.sep+'*')

		# Loop through all of the files
		for Nodes in Nodes:
			# If the path is a directory and not the 'connections' folder
			if os.path.isdir(Nodes) and Nodes != directory+os.sep+'connections':
				# Reset Node Values
				NodeValue = [0,0]
				# Get Node position data and sort into 'Name', 'Xpos' & 'Ypos'
				_, Data = np.genfromtxt(Nodes+os.sep+'station_data.txt',dtype=str,delimiter = ': ').T
				# Set NodeValue using data
				NodeValue[0], NodeValue[1] = float(Data[1]),float(Data[2])
				# Get node using Data[0] and set its value using NodeValue
				self.add_node(Data[0])
				node = self.get_node(Data[0])
				node.value = NodeValue

		# Get the names of all files in 'connections' folder
		Connects = glob(directory+os.sep+'connections'+os.sep+'*')

		# Initialise node lists
		FromNodes = []
		ToNodes = []

		for Connects in Connects:
			# Remove excess string
			Connects = Connects.strip(directory+os.sep+'connections'+os.sep+'.txt')
			# Store node name and append to the lists
			FromNode,ToNode = Connects.split('-')
			FromNodes.append(FromNode)
			ToNodes.append(ToNode)

			# Get capacity  data for the arc weight
			_, Cap = np.genfromtxt(directory+os.sep+'connections'+os.sep+FromNode+'-'+ToNode+'.txt', dtype=float, delimiter =", ", skip_header = 1,).T
			# Calculate the average capacity for the  arc weight
			weight = sum(Cap)/len(Cap)
			
			# Set to and from nodes for 'join_nodes'
			from_node = self.get_node(FromNode)  
			to_node = self.get_node(ToNode)
			# Create an arc between the two nodes and set its weight
			self.join_nodes(from_node, to_node, weight)

	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
