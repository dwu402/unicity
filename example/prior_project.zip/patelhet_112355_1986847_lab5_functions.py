# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint 1: how is an empty network object created in lab5_practice.py?**
		# **hint 2: take a look Section 0.6 in python101.ipynb, particularly attribute assignment**  
		# **hint 3: what values do the method arguments NAME and VALUE take when the method is called 
		#           in lab5_practice.py?**
		# **hint 4: what does the input argument 'self' represent in this method?**
				
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# **your pseudocode here**
		
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		# ___
		#create an empty node 
		node = Node() 
		node.name = name #add name attribute
		node.value = value	#add value attribute
		# 3. THINK VERY CAREFULLY ABOUT WHAT THE NEXT COMMAND IS DOING
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both input nodes have lists called arcs_in and arcs_out.
		# **   - what information do these store?
		# **   - because they are lists, they can be modified using the append method
		
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# ___
				
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		# ___
		arc = Arc() #create empty Arc
		arc.weight = weight #add attribute weight
		arc.to_node = node_to #add attribute which node arc goes to 
		arc.from_node = node_from # add attribute which node it comes from
		node_to.arcs_in.append(arc)  #adds arc coming in to the node the arc going to
		node_from.arcs_out.append(arc)  #adds arc going out of the node to which the arc is coming out of
		
		
		# **delete the placeholder command below once you have written your code**
		self.arcs.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination node pair needs to be joined
		
		# **some useful (incomplete) code snippets**
		# ln.split
		#
		# 
		
		# 1. THE PSEUDOCODE FOR THIS METHOD HAS ALREADY BEEN WRITTEN BELOW
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		# - strip() is a useful method that removes white-space from the beginning and 
		#   end of the string
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# divide the string using the split() method for strings
			# - extract the source node
			# - extract the remaining arcs
			# ___
			listna = ln.split(',') #list of node and arc weights
			olength = len(listna)
            
			if len(listna) == 1:     #if only source node in line
				sourcend =listna[0]
        #if source node with one destination arc and weight
			elif len(listna) == 2: 
				sourcend = listna[0]
				listna.pop(0) #removes source node from list
				desnode1 = listna[0].split(';')[0]     #splits the component of arc and weight and takes only arc
				arcweight1 = float(listna[0].split(';')[1]) #takes only the weight from the info
		#if more than one source node and desnode with weigh
			else:                             #
				sourcend = listna[0]
				listna.pop(0)
				desnode1 = listna[0].split(';')[0]
				arcweight1 = float(listna[0].split(';')[1])
				desnode2 = listna[1].split(';')[0]
				arcweight2 = float(listna[1].split(';')[1])
			

			# YOU WILL NEED TO THINK CAREFULLY ABOUT WHAT THIS TRY/EXCEPT BLOCK DOES
			# if node doesn't exist, add to network
			#check if there is source nodes if not add it to the nodes
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				sourcend = self.get_node(sourcend)           
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(sourcend)
			if olength >= 2: #if there are atleast one desnode check if it has been added or not(add if not)
			    try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				    desnode1 = self.get_node(desnode1)           
			    except NetworkError:
				# this command gets executed if an error is raised above
				    self.add_node(desnode1)
					
			if olength > 2: #if there is more than one, check the second one if its added or not(add if not)
			    try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				    desnode2 = self.get_node(desnode2)           
			    except NetworkError:
				# this command gets executed if an error is raised above
				    self.add_node(desnode2)
					
			
			  

				
			#^^^	
			# get the source node OBJECT, using the source node STRING
			# ___
			if type(desnode1) == str:
				desnode1 = self.get_node(desnode1)
			if type(desnode2) == str:
				desnode2 = self.get_node(desnode2)
            
			if type(sourcend) == str:
				sourcend = self.get_node(sourcend)
				
				
			# read the arc information and add it to network
			#for arc in arcs:
				# parse arc information
				# ___
				
				# get destination node object and link it to source node
				# ___
				
				# delete the placeholder command below when you start writing your code
				#pass
			if olength > 2:
				self.join_nodes(sourcend,desnode1,arcweight1)
				self.join_nodes(sourcend,desnode2,arcweight2)
			elif olength == 2:
				self.join_nodes(sourcend,desnode1,arcweight1)
			else:
				pass
				
						
			# get next line
			# ___
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		# Author: Het Patel__

		#get paths for all directories
		output = glob(directory + os.sep + '*')
        #get path for connection directory
		arcfiles = glob(directory + os.sep + 'connections' + os.sep + '*.txt')
		
		#goes through each directory but avoids connections
		for i in range (len(output)):
			if output[i] == (directory + os.sep + 'connections'):
				pass
			else:
				#if directory is not connections then enter the directory and open file and get date
				if os.path.isdir(output[i]):
					#delimiter removes colon and space
					data = np.genfromtxt(output[i]+os.sep+'station_data.txt', delimiter = ': ', skip_header=0,dtype='U10')
					#add node, first input is string of the code node name, second input is list of x and y values.
					self.add_node((str(data[0][1])),[float(data[1][1]),float(data[2][1])])
					

		#for all number of files in connections, open each text file			
		for j in range (len(arcfiles)):
			count = 0
			sum = 0
			#take the last input of the path string to get the from and to nodes
			nodenames = arcfiles[j].split(os.sep)[-1]
			#strip the .txt
			nodenames = nodenames.strip('.txt')
			#split the from and to nodes 
			from_node = nodenames.split('-')[0]
			to_node = nodenames.split('-')[-1]
			#using get_node , change the from and to nodes from strings to Nodes
			from_node = self.get_node(from_node)
			to_node = self.get_node(to_node)
			#opens each file at a time
			fp = open(arcfiles[j],'r')
			#removes header
			hdr = fp.readline()
			
			ln = fp.readline()
			while ln is not '':
				#splits the line into time and capacity, only take the capacity value and convert to a floating pt
				capacity = float(ln.strip().split(',')[-1])
				#add capacity to sum
				sum += capacity
				#iterate count for number of capacities
				count += 1
				ln = fp.readline()

			#find mean capacity hence arc weight
			arcweight = sum/count
			#close file
			fp.close()
			#join nodes together by using from node and to node and arc weight
			self.join_nodes(from_node,to_node,arcweight)
		
		# **delete the placeholder command below once you have written your code**
		
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
