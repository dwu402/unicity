# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)

class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)

class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task** #
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
				
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# **Create a new Node**
		# **Allocate the name of the node**
		# **Allocate the value of the node**
		# **NB. the value and name of this node are its attributes
		
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		node = Node()
		node.name = name
		node.value = value

		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# **Create an empty arc**
		# **The arc points from 'node_from'**
		# **The arc points to 'node_to'**
				
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		arc = Arc()
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from
		self.arcs.append(arc)
		node_to.arcs_in.append(arc)
		node_from.arcs_out.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		# - strip() is a useful method that removes white-space from the beginning and end

		ln = fp.readline().strip()
		# keep looping to the end of the file
		while ln is not '':        
			# divide the string using the split() method for strings
			ln_split = ln.split(',')
			# - extract the source node
			from_node_name = ln_split[0]
	
			# if node doesn't exist, add to network
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(from_node_name)           
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(from_node_name)
			
				
			# get the source node OBJECT, using the source node STRING
			from_node = self.get_node(from_node_name) 
			
			# Loop through arcs that the source node point to.
			for count in range (len(ln_split)):
				if count != 0:
					to_node_name = ln_split[count][0]
					try:
						# this command raises an ERROR if the node DOESN'T exist
						to_node = self.get_node(to_node_name)           
					except NetworkError:
						# If the node does not exist; it will be created and added to the network
						self.add_node(to_node_name)

					# These three lines use the pre-existing 'join_nodes' method to join the nodes	
					weight = int(ln_split[count][2])
					to_node = self.get_node(to_node_name)
					self.join_nodes(from_node, to_node, weight)

			# get next line
			ln = fp.readline().strip()
			
		fp.close()
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	

	# created method that reads the corrections folder
	def read_corrections(self, directory):

		for roots, dirs, files in os.walk('{}/connections'.format(directory)):
			# searches through all the files within the connections directory
			for file in files:
				fp = open('{}/connections/{}'.format(directory, file))
				# disregards the header
				hdr = fp.readline().strip()
				# reads first line in file
				ln = fp.readline().strip()
				# takes the file name and gets the names of the nodes(to and from)
				name = str(file)
				name_split = name.split('-')
				my_nodes = name_split.pop()
				my_nodes = my_nodes.split('.')
				node_to = my_nodes.pop()
				node_to = my_nodes.pop()
				to_node_name = node_to.strip()
				my_nodes = name_split.pop()
				from_node_name = my_nodes.strip()

				count = 0
				average = 0
				# this while loop reads through the file and takes records the number of recorded conections
				# and the sum of all connections
				while ln != '':
					ln_split = ln.split(',')
					connection = float(ln_split.pop())
					average += connection
					count += 1

					ln = fp.readline().strip()
				# the average weight is equal to the sum of all weights over the number of weights recorded
				weight = average/count
				
				# joins the nodes
				from_node = self.get_node(from_node_name)           
				to_node = self.get_node(to_node_name)           
				self.join_nodes(from_node, to_node, weight)
			fp.close()


	# Created method that creates all nodes
	def create_all_nodes(self, directory):

		for roots, dirs, files in os.walk(directory):
			# searches through all the folders within the given directory
			for dir in dirs:
				# if the folder is not the connections folder it must contain a file called station_data.txt
				if dir != 'connections':
					# opens station_data.txt
					fp = open('{}/{}/station_data.txt'.format(directory, dir))
					# the following commands read through the file and record the code and co-ordinates
					ln = fp.readline().strip()
					ln_split = ln.split(':')
					code = ln_split[1].strip()
					ln = fp.readline().strip()
					ln_split = ln.split(':')
					x = float(ln_split[1].strip())
					ln = fp.readline().strip()
					ln_split = ln.split(':')
					y = float(ln_split[1].strip())
					coordinates = [x,y]
					# adds a node to the network with the code as the name and co-ordinates as the value
					self.add_node(code, coordinates)
					# closes the file
					fp.close()

	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		# **some useful functions**
		# glob
		# np.genfromtxt
		# os.path.isdir
		# comma is delimiter in connections
		
		# creates all of the nodes with names and values
		self.create_all_nodes(directory)
		# reads the corrections folder
		self.read_corrections(directory)

	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()