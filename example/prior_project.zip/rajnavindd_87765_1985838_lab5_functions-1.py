# ENGSCI233: Lab 5 - Data
# lab5_functions.py
# Author: Navindd Raj 822790840

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob
import string

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)

class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.from_node.name,self.to_node.name)

class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass

class Network(object):
	''' Basic network class.
	'''

	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		node = Node() 		# creates new node object
		node.name = name 		# update node name
		node.value = value		# update node value
					
		# 3. THINK VERY CAREFULLY ABOUT WHAT THE NEXT COMMAND IS DOING
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		arc = Arc()		# creates new object
		arc.from_node = node_from 	# update FROM node information
		arc.to_node = node_to		# update TO node information
		arc.weight = weight		# update the arc weight information

		node_from.arcs_out.append(arc) 	# add the arc to the arcs OUT list for node where it comes FROM
		node_to.arcs_in.append(arc)		# add the arc to the arcs IN list for node where it goes TO

		self.arcs.append(arc)		# append the newly created arc to the network
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''		
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		# - strip() is a useful method that removes white-space from the beginning and 
		#   end of the string
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# divide the string using the split() method for strings
			ln_split = ln.split(',')
			from_node_name = ln_split[0]		# extract the source node
			# - extract the remaining arcs
			# contains info of arcs FROM source node (element 0) TO other nodes
			arcs_to = ln_split[1:]
			arcs = []
			for pair in arcs_to:
				arcs.append(pair.split(';'))

			
			# YOU WILL NEED TO THINK CAREFULLY ABOUT WHAT THIS TRY/EXCEPT BLOCK DOES
			# if node doesn't exist, add to network
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(from_node_name)           
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(from_node_name)
				
			# get the source node OBJECT, using the source node STRING
			from_node = self.get_node(from_node_name)
				
			# read the arc information and add it to network
			for arc in arcs:
				# parse arc information
				# if arc destination node is not in network, add it to the network
				try:
					arc_dest = self.get_node(arc[0])
				except NetworkError:
					self.add_node(arc[0])
					arc_dest = self.get_node(arc[0])
				arc_weight = arc[1]
				
				# get destination node object and link it to source node
				self.join_nodes(from_node,arc_dest,arc_weight)
						
			# get next line
			ln = fp.readline().strip()


class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	

	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''

		# change the directory to the input dir, so we can work on the dirs inside this one
		# this dir contains all the info we need on station data and connections in the network
		os.chdir(directory)

		# create a list of directories within the current dir
		dirList = os.listdir()

		# iterate across all directories within the input directory
		# ignore 'connections' directory as that has to do with arcs between nodes - 
		# we want to work on adding all nodes into the network FIRST, THEN add 
		# the connections (arcs) between nodes
		for dirname in dirList:
			if dirname != 'connections':

				os.chdir(dirname)      # enter new station directory
				# from the expected 'station_data.txt' file containing code and coordinates of each node,
				# unpack the labels 'code', 'x' and 'y' (first column) in one variable to throw away,
				# and the second column containing the data relating to code, x and y into another
				# variable to use. The 0th element corresponds to the code of the station, 1st element
				# the x pos and 2nd element the y pos
				# since dtype = None, variable values will be in bytecode and must be decoded accordingly
				labels,code_x_y = np.genfromtxt('station_data.txt', dtype = None, unpack = True)

				# add a node containing the name of station and 2 element list of x,y values of node
				# use .decode() or float cast to convert code_x_y data to a string/floating pt required for input
				newNodeName = code_x_y[0].decode()
				newNodeValues = [float(code_x_y[1]),float(code_x_y[2])]
				self.add_node(newNodeName, newNodeValues)

				os.chdir('..')		# go back to parent folder

		# now that all the nodes have been added to the network, we can add connections between them
		os.chdir('connections')		# enter the 'connections' folder in the input dir

		# create a list of files within the 'connections' dir
		fileList = os.listdir()

		# iterate across all files within the 'connections' directory
		for filename in fileList:

			# get vectors containing info about time and capacities of connections 
			time,capacity = np.genfromtxt(filename, skip_header=1, delimiter=',', unpack=True)
			# average the capacities over all times - time vector unused
			# this is the weight of the arc connecting the two nodes
			avgCapacity = sum(capacity)/len(capacity)

			# remove the '.txt' extension from the filename string
			arcsFromTo = filename.strip('.txt')      
			# then remove the '-', thus separating the two location codes
			# the order does not matter as the arcs between two nodes are undirected
			# this gives a list containing the two node names which the arc connects
			arcsFromTo = arcsFromTo.split('-')

			# get to and from nodes
			from_node = self.get_node(arcsFromTo[0])
			to_node = self.get_node(arcsFromTo[1])

			# join the nodes using the calculated arc weight avgCapacity
			self.join_nodes(from_node,to_node,avgCapacity)

		os.chdir('..\..')		# go back to original parent folder (now 2 directories up)

	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		# *** I had some issues here where I would get this error: ***
		# Traceback (most recent call last):
  		# File "c:\Users\User\Documents\School\ENGSCI 233\Labs\Lab 5\tests2.py", line 7, in <module>
    	# 	network.show()
  		# File "c:\Users\User\Documents\School\ENGSCI 233\Labs\Lab 5\lab5_functions.py", line 308, in show
    	#	img=mpimg.imread('bg.png')
  		# File "C:\Users\User\AppData\Local\Programs\Python\Python36\lib\site-packages\matplotlib\image.py", line 1375, in imread
    	# 	with open(fname, 'rb') as fd:
		# FileNotFoundError: [Errno 2] No such file or directory: 'bg.png'
		# So I edited the code with the absolute path of bg.png file... reverted back to original
		# so if this error occurs again please try with absolute path :)
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = float((y+10)*1.06)
			x -= float(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
