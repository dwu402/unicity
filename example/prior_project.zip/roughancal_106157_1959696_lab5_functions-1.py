# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob


# these classes and methods are complete, do not modify them
class Node(object):
    def __init__(self):
        self.name = None
        self.value = None
        self.arcs_in = []
        self.arcs_out = []

    def __repr__(self):
        return 'nd:{}'.format(self.name)


class Arc(object):
    def __init__(self):
        self.weight = None
        self.to_node = None
        self.from_node = None

    def __repr__(self):
        return '{} -> {}'.format(self.from_node.name, self.to_node.name)


class NetworkError(Exception):
    # An error to raise when violations occur.
    pass


# **this class is incomplete, you must complete it as part of the lab task**
class Network(object):
    # Basic network class.
    # these methods are complete, do not modify them
    def __init__(self):
        self.nodes = []
        self.arcs = []

    def __repr__(self):
        return 'ntwk'

    def get_node(self, name):
        ''' Loops through the list of nodes and returns the one with NAME.
            Returns NetworkError if node does not exist.
        '''
        # loop through list of nodes until node found
        for node in self.nodes:
            if node.name == name:
                return node

        raise NetworkError

    def display(self):
        ''' Print information about the network.
        '''
        # print nodes
        print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
        # print arcs
        for arc in self.arcs:
            print('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))

    # **these methods are incomplete, you must complete them as part of the lab task**
    def add_node(self, name, value=None):
        # Adds a Node with NAME and VALUE to the network.
        # Define a new node
        # Assign .name and .value attributes
        # Append this to the network's list of nodes.

        node = Node()
        node.name = name
        node.value = value
        self.nodes.append(node)

    def join_nodes(self, node_from, node_to, weight):
        '''
            Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
        '''
        # **to do: create an empty arc object, assign its attributes**
        # **hint: both input nodes have lists called arcs_in and arcs_out.
        # **   - what information do these store?
        # **   - because they are lists, they can be modified using the append method

        arc = Arc()
        arc.to_node = node_to
        arc.from_node = node_from
        arc.weight = weight
        self.arcs.append(arc)

        node_from.arcs_out.append(arc)
        node_to.arcs_in.append(arc)

    def read_network(self, filename):
        '''
            Read data from FILENAME and construct the network.
            Each line of FILENAME contains
             - the name of an origin node (first entry)
             - and destination;weight pairs (each pair separated by a comma)
        '''

        # Open the files for data extraction and strip the white space from the line.
        fp = open(filename, 'r')
        ln = fp.readline().strip()

        # Cycle through the data while each line isn't blank.
        while ln is not '':

            # Split the line and save the pairs containing arc weight and nodes. Also save the initial
            # node as from_node_name.
            data_pairs = ln.split(',')
            from_node_name = data_pairs[0]
            del data_pairs[0]

            # if node doesn't exist, add to network
            try:
                # the output is a node object, the input is a string
                # this command raises an ERROR if the node DOESN'T exist
                from_node = self.get_node(from_node_name)
            except NetworkError:
                # this command gets executed if an error is raised above
                self.add_node(from_node_name)
                from_node = self.get_node(from_node_name)

            # get the source node OBJECT, using the source node STRING
            # read the arc information and add it to network
            while len(data_pairs) is not 0:
                # parse arc information
                object_node, arc_weights = data_pairs.pop(0).split(';')

                try:
                    to_node = self.get_node(object_node)
                except NetworkError:
                    self.add_node(object_node)
                    to_node = self.get_node(object_node)

                # get destination node object and link it to source node with the arc weights.
                self.join_nodes(from_node, to_node, float(arc_weights))

            # get next line, and repeat.
            ln = fp.readline().strip()


class NetworkNZ(Network):

    # **this method is incomplete, you must complete it as part of the lab task**
    def read_network(self, directory):
        '''
            Notes:
            ------
            Assume that DIRECTORY contains one folder for connections between nodes.
            All other folders define the nodes of the network.

            Each node folder contains a file called station_data.txt
            This file includes the node name and x and y values for the node position.

            In the connections folder, there is a file for each connection.
            The name of the file indicates which two nodes are connected (from-to).
            The contents of the file record the capacity of that connection over the last 35 years.
            The connection (arc) weight should be the mean capacity.
        '''

        # Open the directory to create a string of the connection arc data
        # Below returns the contents of \nz_network\connections
        arcs = glob(directory+os.sep+'connections'+os.sep+'*')

        # Split the names to isolate the nodes that these arcs connect to, and the associated capacity averages
        # which are the arc weights.
        for arc in arcs:
            file_name = arc.split('\\')[-1]
            node_from, node_to = file_name.split('-')
            node_to = node_to.split('.')[0]
            time, capacity = np.genfromtxt(directory+os.sep+'connections'+os.sep+file_name, delimiter=',',
                                           skip_header=1, dtype='float', autostrip=True).T

            arc_weight_avg = sum(capacity)/len(capacity)

            # Test if the current nodes have been already created, if not, generate them.
            try:
                node_from = self.get_node(node_from)

            except NetworkError:
                self.add_node(node_from)
                node_from = self.get_node(node_from)

            try:
                node_to = self.get_node(node_to)

            except NetworkError:
                self.add_node(node_to)
                node_to = self.get_node(node_to)

            self.join_nodes(node_from, node_to, arc_weight_avg)

        # Access the co-ordinates of the nodes, without any reference to the 'connections' directory.
        locations = glob(directory+os.sep+'*')
        locations.remove(directory+os.sep+'connections')

        # Cycle through the directory and retrieve the stored location, and co-ordinate data.
        for node in locations:
            labels, data = np.genfromtxt(node+os.sep+'station_data.txt', delimiter=':', dtype=str, autostrip=1).T
            current_node = self.get_node(data[0])

            # Define the node.value as the x, y co-ordinates relative to the map of NZ
            current_node.value = [int(data[1]), int(data[2])]

    def show(self, save=None):
        ''' Plot the network and optionally save to file SAVE
        '''
        # create figure axes
        fig = plt.figure()
        fig.set_size_inches([10, 10])
        ax = plt.axes()

        # NZ coastline as background
        img = mpimg.imread('bg.png')
        ax.imshow(img, zorder=1)

        # a filthy hack to get coordinates in the right spot...
        for node in self.nodes:
            x, y = node.value
            y = int((y+10)*1.06)
            x -= int(50*y/800.)
            node.value = [x, y]

        # draw nodes as text boxes with station names
        # bounding box properties
        props = dict(boxstyle='round', facecolor='white', alpha=1.0)
        for node in self.nodes:
            # extract coordinates
            x, y = node.value
            ax.text(x, y, node.name, ha='center', va='center', zorder=2, bbox=props)

        # draw connections as lines
        weights = [arc.weight for arc in self.arcs]
        # scale for plotting connections
        wmin = np.min(weights)
        wmax = np.max(weights)
        lmin, lmax = [0.5, 10.0]

        # plot connections
        for arc in self.arcs:
            # compute line length, scales with connection size
            lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
            x1, y1 = arc.from_node.value
            x2, y2 = arc.to_node.value
            ax.plot([x1, x2], [y1, y2], '-', lw=lw, color=[0.6, 0.6, 0.6])

        # remove ticks
        ax.set_xticks([])
        ax.set_yticks([])

        # display options
        if save:
            # save to file
            plt.savefig(save, dpi=300)
            plt.close()
        else:
            # open figure window in screen
            plt.show()