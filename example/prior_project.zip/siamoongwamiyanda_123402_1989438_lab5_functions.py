# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.from_node.name,self.to_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''

		node = Node()   #creates empty node object
		node.name = name   #assigns name attribute to node
		node.value = value  #assigns value attribute to node

		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		
		#creates an empty Arc object, then assigns the weight attribute to arc and assigns the
		#receiving and sending nodes to the arc as attributes
		arc = Arc() 
		arc.weight = weight
		arc.from_node = node_from
		arc.to_node = node_to


		node_from.arcs_out.append(arc)  #appends this arc to the list of arcs out in the sending node
		node_to.arcs_in.append(arc)  #appends this arc to the list of 'arcs in' in the receiving node
		self.arcs.append(arc) #appends this arc to the list of arcs



	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		# - strip() is a useful method that removes white-space from the beginning and 
		#   end of the string
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file

			# divide the string using the split() method for strings
			ArcData = ln.split(',')
			
			# - extract the source node
			from_node_name = ArcData[0]
			
			# - extract the remaining arcs
			arcs = []
			for i in range (1,len(ArcData)):
				arcs.append(ArcData[i].split(';')) #append to created arcs list

			
			try:
				# get the node in the network with the input name
				# this command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(from_node_name)           
			except NetworkError:
				#if an error is raised above, add node to network
				self.add_node(from_node_name)

			#repeat code above for the names of the 'to nodes' in arcs list
			for i in range(len(arcs)):
				try:
					to_node = self.get_node(arcs[i][0]) 
				except NetworkError:
					self.add_node(arcs[i][0])

			# get the source node OBJECT, using the source node STRING			
			from_node = self.get_node(from_node_name)

			# read the arc information and add it to network
			for arc in arcs:
				# get destination node object and link it to source node				
				to_node = self.get_node(arc[0])
				self.join_nodes(from_node, to_node, float(arc[1]))
				

			# get next line
			ln = fp.readline().strip()
			

class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		
		node_folders = glob(directory+os.sep+'*')  #creates list of all folders in the network directory
		
		#loops over all folders
		for i in range(len(node_folders)):

			#skip making any action on the connections folder
			if node_folders[i] == directory+os.sep+'connections': 
				i += 1

			else:
				fp = open(node_folders[i]+os.sep+'station_data.txt','r')   #open station data text file
				ln = fp.readline().strip()   #get first line in file
				nodename = ln.split(': ')[1]  #divide the string using the split() method, extract the node name
				
				#loop to end of file, get next lines in file, divide the string using 
				#the split() method to extract the decimal of the x and y coordinates respectively
				nodevalue=[]
				ln = fp.readline().strip()				
				while ln is not '':
					nodevalue.append(float(ln.split(': ')[1]))
					ln = fp.readline().strip()   #get next line

				self.add_node(nodename, nodevalue)   #adds node with value to the network

		#creates string list of all the connection text files in the directory
		connection_files = glob(directory+os.sep+'connections'+os.sep+'*')

		for i in range(len(connection_files)): #loops over all files
			
			#find corresponding node names by using the split() method on the string of the file path.
			#store the result between steps in a temporary variable, then use the get.node() method to
			#extract node objects
			temp = connection_files[i].strip().split(os.sep)[-1]
			temp = temp.split('.txt')
			from_nodename, to_nodename = temp[0].split('-')
			from_node = self.get_node(from_nodename)
			to_node = self.get_node(to_nodename)
			
			#open the text file containing the capacity of every connection between the 2 nodes
			#using np.genfromtxt. Ignore the first line using skip_header, and seperate
			#time and capacity using delimeter ','. Transpose the reault and save the values
			#corresponding to the capacities in the capacities string
			capacities = np.genfromtxt(connection_files[i], delimiter = ',', skip_header=1 ).T[1]

			#use the sum and len method to find the average capacitiy between the 2 nodes.
			#float method to convert number into a float value
			mean_capacity = float(sum(capacities)/len(capacities))
			
			#joins nodes with weight (represented by mean capacity) and adds arc to
			#network
			self.join_nodes(from_node, to_node, mean_capacity)
			
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
