# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob


# these classes and methods are complete, do not modify them
class Node(object):
    def __init__(self):
        self.name = None
        self.value = None
        self.arcs_in = []
        self.arcs_out = []

    def __repr__(self):
        return 'nd:{}'.format(self.name)

class Arc(object):
    def __init__(self):
        self.weight = None
        self.to_node = None
        self.from_node = None

    def __repr__(self):
        return '{} -> {}'.format(self.to_node.name, self.from_node.name)


class NetworkError(Exception):
    '''An error to raise when violations occur.
    '''
    pass


# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
    ''' Basic network class.
    '''
    # these methods are complete, do not modify them
    def __init__(self):
        self.nodes = []
        self.arcs = []

    def __repr__(self):
        return 'ntwk'

    def get_node(self, name):
        ''' Loops through the list of nodes and returns the one with NAME.

            Returns NetworkError if node does not exist.
        '''
        # loop through list of nodes until node found
        for node in self.nodes:
            if node.name == name:
                return node

        raise NetworkError

    def display(self):
        ''' Print information about the network.
        '''
        # print nodes
        print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
        # print arcs
        for arc in self.arcs:
            print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))

    # **these methods are incomplete, you must complete them as part of the lab task**
    def add_node(self, name, value=None):
        '''Adds a Node with NAME and VALUE to the network.
        '''

        # **to do: create an empty node object, assign its attributes**
        # **hint 1: how is an empty network object created in lab5_practice.py?**
        # **hint 2: take a look Section 0.6 in python101.ipynb, particularly attribute assignment**
        # **hint 3: what values do the method arguments NAME and VALUE take when the method is called
        #           in lab5_practice.py?**
        # **hint 4: what does the input argument 'self' represent in this method?**

        # 1. IMPLEMENT COMMANDS
        node = Node()
        node.value = value
        node.name = name

        # 2. THINK VERY CAREFULLY ABOUT WHAT THE NEXT COMMAND IS DOING
        # append node to the list of nodes
        self.nodes.append(node)

    def join_nodes(self, node_from, node_to, weight):
        '''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
        '''

        # **to do: create an empty arc object, assign its attributes**
        # **hint: both input nodes have lists called arcs_in and arcs_out.
        # **   - what information do these store?
        # **   - because they are lists, they can be modified using the append method

        # 1. IMPLEMENT COMMANDS
        arc = Arc()
        arc.to_node = node_to
        arc.from_node = node_from
        arc.weight = weight

        node_from.arcs_out.append(arc)
        node_to.arcs_in.append(arc)

        self.arcs.append(arc)

    def read_network(self, filename):
        '''Read data from FILENAME and construct the network.

            Each line of FILENAME contains
             - the name of an origin node (first entry)
             - and destination;weight pairs (each pair separated by a comma)

        '''
        # **to do**
        # **hint: inspect 'network.txt' so that you understand the file structure**
        # **hint: each source-destination node pair needs to be joined

        # **some useful (incomplete) code snippets**
        # ln.split
        #
        #

        # 1. THE PSEUDOCODE FOR THIS METHOD HAS ALREADY BEEN WRITTEN BELOW

        # open the file
        fp = open(filename, 'r')

        # get first line (a string)
        # - strip() is a useful method that removes white-space from the beginning and
        #   end of the string
        ln = fp.readline().strip()
        while ln is not '':        # keep looping to the end of the file
            # divide the string using the split() method for strings
            # - extract the source node
            # - extract the remaining arcs
            # ___
            data = ln.split(',')
            from_node = data[0]

            # YOU WILL NEED TO THINK CAREFULLY ABOUT WHAT THIS TRY/EXCEPT BLOCK DOES
            # if node doesn't exist, add to network
            try:
                # the output is a node object, the input is a string
                # this command raises an ERROR if the node DOESN'T exist
                from_node = self.get_node(from_node.name)
            except NetworkError:
                # this command gets executed if an error is raised above
                self.add_node(from_node.name)

            # get the source node OBJECT, using the source node STRING
            # ___

            arcs = data[1:]

            # read the arc information and add it to network
            for arc in arcs:
                # parse arc information
                # ___
                arc_values = arc.split(';')

                # get destination node object and link it to source node
                # ___
                current_arc = Arc()
                current_arc.weight = arc_values[1]
                current_arc.to_node = arc_values[0]

            # get next line
            # ___
            ln = next(fp).strip()


# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
    ''' Derived Network class, for NZ networks.
    '''

    # **this method is incomplete, you must complete it as part of the lab task**
    def read_network(self, directory):

        # Read the files from the directory
        directory_files = glob(directory + '/*')

        # Opening each file directory (with the exception of connections), and saving and formatting
        # data found in each subsequent file (station_data).
        for name_file in directory_files:
            if name_file != 'nz_network\connections':
                subdirectory_files = glob(name_file + '/*.txt')
                fp = open(subdirectory_files[0], 'r')
                ln = fp.readline().strip()
                temp_node_list = []
                # Appending all of the data to temp_node_list, and formatting with strip(), then adding
                # to the network.
                while ln != '':
                    data = ln.split(':')[1].strip()
                    temp_node_list.append(data)
                    ln = fp.readline().strip()
                self.add_node(temp_node_list[0], [int(temp_node_list[1]), int(temp_node_list[2])])

        connections = glob('nz_network\connections' + '/*')

        # Opening each of the files in sequence, stripping to remove unwanted white space.
        for connection in connections:
            fp = open(connection, 'r')
            ln = fp.readline().strip()
            # Formatting and saving the data found in the file.
            while ln != '':
                data = ln.split(',')
                ln = fp.readline().strip()
            nd_connection = connection[23:-4].split('-')

            # Looping through each node, and finding the to_node and from_node (from the file name) associated
            # with each, so that it may be joined to the network.
            for node_pos in self.nodes:
                if node_pos.name == nd_connection[0]:
                    for node_dest in self.nodes:
                        if node_dest.name == nd_connection[1]:
                            weights = np.genfromtxt(connection, delimiter=",", usecols=1, skip_header=1, autostrip=True)
                            mean = 0
                            for weight in weights:
                                mean += weight

                            # Associating each connection between destinations with a weight.
                            mean /= len(weights)
                            self.join_nodes(node_pos, node_dest, mean)

    # this method is complete, do not modify
    def show(self, save=None):
        ''' Plot the network and optionally save to file SAVE
        '''
        # create figure axes
        fig=plt.figure()
        fig.set_size_inches([10,10])
        ax=plt.axes()

        # NZ coastline as background
        img=mpimg.imread('bg.png')
        ax.imshow(img,zorder=1)

        # a filthy hack to get coordinates in the right spot...
        for node in self.nodes:
            x,y = node.value
            y = int((y+10)*1.06)
            x -= int(50*y/800.)
            node.value = [x,y]

        # draw nodes as text boxes with station names
        # bounding box properties
        props = dict(boxstyle='round', facecolor='white', alpha=1.0)
        for node in self.nodes:
            # extract coordinates
            x,y = node.value
            ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)

        # draw connections as lines
        weights = [arc.weight for arc in self.arcs]
        # scale for plotting connections
        wmin = np.min(weights)
        wmax = np.max(weights)
        lmin,lmax = [0.5, 10.0]

        # plot connections
        for arc in self.arcs:
            # compute line length, scales with connection size
            lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
            x1,y1 = arc.from_node.value
            x2,y2 = arc.to_node.value
            ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])

        # remove ticks
        ax.set_xticks([])
        ax.set_yticks([])

        # display options
        if save:
            # save to file
            plt.savefig(save, dpi=300)
            plt.close()
        else:
            # open figure window in screen
            plt.show()


