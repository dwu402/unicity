# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them

# really just concerned with the node class and the network class
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.from_node.name,self.to_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None): 
		'''The add_node method adds a Node with NAME and VALUE to the network.
		'''
		# self is the network here
		# value = None is a default value
		
		# empty node object created and attributes assigned
		node = Node()
		node.value = value
		node.name = name

		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''The join_nodes method adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
				
		# empty arc object created and attributes assigned
		arc = Arc()
		arc.weight = weight
		arc.to_node = node_to
		arc.from_node = node_from

		# append arc to lists: arcs_in and arcs_out
		# corresponding to the appropriate input nodes
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
		
		# append arc to list of arcs
		self.arcs.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		'''
				
		# open the input file and keep looping to end of file
		fp = open(filename, 'r')
		ln = fp.readline().strip()
		while ln is not '':
			from_node_name = ln.split(',')[0] # source node
			arcs = ln.split(',')[1:] # remaining arcs

			# if source node doesn't exist, add to network
			try:
				from_node = self.get_node(from_node_name)           
			except NetworkError:
				self.add_node(from_node_name)
				
			# get the source node object
			from_node = self.get_node(from_node_name)
				
			# read the arc information and add it to network
			for arc in arcs:
				# parse arc information
				arc = arc.split(';')
				to_node_name = arc[0] # destination node

				# if destination node doesn't exist, add to network
				try:
					to_node = self.get_node(to_node_name)           
				except NetworkError:
					self.add_node(to_node_name)
				
				# get the destination node object
				to_node = self.get_node(to_node_name)

				# arc weight float value
				weight = float(arc[1])

				# link source node object to destination node object
				self.join_nodes(from_node, to_node, weight)
						
			# get next line in file
			ln = fp.readline().strip()
			
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Nodes: NZ stations where electricity is generated or consumed
			Arcs: high-voltage power lines linking the nodes

		'''
		# loop through all folders inside the input directory
		nodes = glob(directory+os.sep+'*')
		for i in range(len(nodes)):
			if nodes[i] != directory+os.sep+'connections': #exclude connections subdirectory
				fp = open(nodes[i]+os.sep+'station_data.txt','r')
				ln = fp.readline().strip()
				node_data = [] # list to hold node name and coordinates
				while ln is not '':       # keep looping to the end of the file
					node_data.append(ln.split(':')[1])
					ln = fp.readline().strip()
			
			node_name = node_data[0].replace(' ', '')

			# node location coordinates
			x = float(node_data[1])
			y = float(node_data[2])
			value = [x,y]

			# if node doesn't exist, add node and its value to network
			try:
				node = self.get_node(node_name)           
			except NetworkError:
				self.add_node(node_name,value)

		# loop through all files inside the subdirectory 'connections'
		connections = glob('nz_network/connections/*')
		for i in range(len(connections)):
			# extract file name indicating connected nodes
			connected_nodes = os.path.splitext(connections[i])
			connected_nodes = connected_nodes[0].split('/')[2]
			
			# extract source node and destination node
			from_node_name = connected_nodes.split('-')[0]
			to_node_name = connected_nodes.split('-')[1]

			# get the source node obect
			node_from = self.get_node(from_node_name)
			
			# get the destination node obect
			node_to = self.get_node(to_node_name)

			# reads data inside node returning capacity vector
			time, capacity = np.genfromtxt(connections[i], delimiter =',', skip_header = 1).T

			# arc weight == mean capacity
			weight = float(sum(capacity))/float(len(capacity))
			
			# link source node object to destination node object
			self.join_nodes(node_from, node_to, weight)
			
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
