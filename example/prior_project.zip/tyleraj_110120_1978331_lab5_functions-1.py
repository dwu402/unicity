# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob


class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)

class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)

class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
class Network(object):
	''' Basic network class.
	'''
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
	
		#Create a node
		node  = Node()
		#Assign its name attribute as the input variable name
		node.name = name
		#Assign its value attribute as the input variable value
		node.value = value				
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		
		#Create an arc
		arc = Arc()
		#Assign its weight attribute as the input variable weight
		arc.weight = weight
		#Assign its to_node attribute as the input variable node_to
		arc.to_node = node_to
		#Assign its from_node attribute as the input variable node_from
		arc.from_node = node_from
		#Add arc to the list arcs_out from node_from
		node_from.arcs_out.append(arc)
		#Add arc to the list arcs_in from node_to
		node_to.arcs_in.append(arc)
		#Add arc to the list arcs in the network
		self.arcs.append(arc)
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
				
		# open the file
		fp = open(filename, 'r')
		# get first line (a string)
		ln = fp.readline().strip()

		# keep looping to the end of the file
		while ln is not '':        
			# divide the string using the split() method for strings
			data = ln.split(',')
			# extract the source node
			from_node_name = data[0]
			# - extract the remaining arcs
			arcs = [None] * (len(data)-1)

			for i in range(1,len(data)):
				arcs[i-1] = data[i]

			try:
				# First try to obtain the from node from the network
				from_node = self.get_node(from_node_name)           
			except NetworkError:
				# If the from node does not exist in the network, it is created and then obtained
				self.add_node(from_node_name)
				from_node = self.get_node(from_node_name)
				
			# For all the arcs
			for ARC in arcs:
				# parse arc information
				to_node_name, weight = ARC.split(';')

				try:
					# First try to obtain the to node from the network
				    to_node = self.get_node(to_node_name)           
				except NetworkError:
					# If the to node does not exist in the network, it is created and then obtained
				    self.add_node(to_node_name)
				    to_node = self.get_node(to_node_name)

				# Join the two nodes
				self.join_nodes(from_node,to_node,weight)
						
			# get next line
			ln = fp.readline().strip()

class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		
		#Create a list to store the 'connections' folder location
		arcfolder = glob('connections')

		#If folder is in the working directory
		if os.path.isdir(arcfolder[0]): 
			#Create a list containing all the subfile names within the folder
			subfiles = glob(arcfolder[0]+os.sep+'*')
			
			#For all the subfiles
			for arcfile in subfiles:
				#Read the data from the subfile
				data = np.genfromtxt(arcfile, dtype = float, delimiter = ", ", skip_header = 1)
				#Store the Capacity data is a list
				Capacity = data[:,1]
				#Initialise the sum of the capacities to 0
				CapSum = 0

				#For all the capacity values
				for i in range(len(Capacity)):
					#Add the current capacity value to the running total
					CapSum += Capacity[i]

				#Calculate the mean capacitance
				CapMean = CapSum/(i+1)
				#Split the arcfile location name to determine the from and to node names
				first_half, second_half = arcfile.split('-')
				path, from_node_name = first_half.split('\\')
				to_node_name, filetype = second_half.split('.')

				try:
					#First try to obtain the from node from the network
					from_node = self.get_node(from_node_name)           
				except NetworkError:
					#If the from node does not exist in the network, it is created and then obtained
					self.add_node(from_node_name)
					from_node = self.get_node(from_node_name)

				try:
					#First try to obtain the to node from the network
					to_node = self.get_node(to_node_name)           
				except NetworkError:
					#If the to node does not exist in the network, it is created and then obtained
					self.add_node(to_node_name)
					to_node = self.get_node(to_node_name)

				#Join the nodes with a weighting of the mean capacitance
				self.join_nodes(from_node,to_node,CapMean)
		#Create a list of all the files/folders
		files = glob('*')

		#For each file
		for file in files:

			#If the file is in the working directory 
			if os.path.isdir(file):  
				#Create a list containing all the subfile names within the folder                    
				subfiles = glob(file+os.sep+'*')

				#If the file is location data
				if file != 'connections':
					#Read data from the subfile
					data = np.genfromtxt(subfiles[0], dtype = str, delimiter = ':', autostrip = True)
					#Get the node name
					node_name  = data[0,1]
					#Get the x position as a floating point number
					x = float(data[1,1])
					#Get the y position as a floating point number
					y = float(data[2,1])
					#Get the node from the network
					node = self.get_node(node_name)
					#Assign the coordinates as the node's value
					node.value = x,y		
		
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
