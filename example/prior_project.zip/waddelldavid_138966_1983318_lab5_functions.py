# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os, glob
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg


	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return '{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.from_node.name,self.to_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, float(arc.weight)))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''

		node=Node()	# Create new node object
		node.name=name	
		node.value=value 
	

	
		self.nodes.append(node) # add node object to the list of nodes in the network object (self)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''

		arc=Arc() # Create new arc object
		arc.to_node=node_to	
		arc.from_node=node_from	
		arc.weight=weight	
		
		# add arc object to the arc object's list of arcs in and out (self referencial)
		arc.to_node.arcs_in.append(arc)	
		arc.from_node.arcs_out.append(arc) 

		self.arcs.append(arc) # add arc object to the (self) network object's list of arcs
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
				
		# open the file
		fp = open(filename, 'r')
		
		ln = fp.readline().strip()

		# Create incrementing variables
		arcindex=0	
		nodeindex=0
		numnodesindex=0 


		t=0 # boolean variable for ending while loop

		# Create lists to store the nodes and arcs created when reading the network
		listofnodes=[Node()]
		listofarcs=[Arc()]

		if ln is not '':	# if first line is not empty, store the first letter as a node in listofnodes
			listofnodes[0].name=ln[0]

		while ln is not '':        # keep looping to the end of the file
			lnarray=ln.split(',')
			size=len(lnarray)
			listofarcs[arcindex].from_node=lnarray[0]
			while t==0: # this loop detects if the node found at the start of the line (i.e. the from_node) has already been stored in the list of nodes
				if nodeindex==numnodesindex:
					if listofnodes[nodeindex].name==lnarray[0]: # if node is already in the list of nodes
						t=1 # end loop
						node1=nodeindex
						nodeindex=0 
					else: 
						listofnodes.append(Node())	
						numnodesindex=numnodesindex+1 
						listofnodes[numnodesindex].name=lnarray[0] 
						node1=numnodesindex
				elif listofnodes[nodeindex].name==lnarray[0]: # if node is already in the list of nodes
					t=1 # end loop
					node1=nodeindex 
					nodeindex=0 
				else:
					nodeindex=nodeindex+1

			t=0 

			for i in range(1,size): # this loop adds more nodes from the same line and also adds info about the arcs between the nodes
				listofarcs[arcindex].from_node=lnarray[0]
				listofarcs[arcindex].to_node=lnarray[i][0]
				listofarcs[arcindex].weight=int(lnarray[i][2])
				while t==0: # This loop is almost identical to the other while t==0 loop above. Only difference is that it tests whether the remaining 
							# nodes in the current line have also been added to the list of nodes.
					if nodeindex==numnodesindex:
						if listofnodes[nodeindex].name==lnarray[i][0]: # if ith node in line is already in list of nodes
							t=1	
							node2=nodeindex 
							nodeindex=0					
						else:
							listofnodes.append(Node()) 
							numnodesindex=numnodesindex+1 
							listofnodes[numnodesindex].name=lnarray[i][0] 
							t=1 
							node2=numnodesindex 
							nodeindex=0 

					elif listofnodes[nodeindex].name==lnarray[i][0]: # if ith node in line is already in list of nodes
						t=1	
						node2=nodeindex 
						nodeindex=0				
					else:
						nodeindex=nodeindex+1 

				t=0

				self.join_nodes(listofnodes[node1],listofnodes[node2],listofarcs[arcindex].weight) # create arc between nodes
				arcindex=arcindex+1 
				listofarcs.append(Arc()) 
				pass
			ln = fp.readline().strip() # read the next line of the input and strip it

		self.nodes=listofnodes # assign listofnodes to the networks list of nodes

			
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	

	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		
		
		folders=glob.glob('nz_network'+os.sep+'**') # obtain alist containing the folders within the nz_network directory
		connectionsfound=0 # create variable representing whether the connections folder has been found yet

		for i in range (len(folders)):
			if folders[i]=='nz_network'+os.sep+'connections': # if element of folders list is the connections folder
				connectionsfound=1 
				k=i # assign index of connections folder to k
			else:				
				self.nodes.append(Node()) 
				fp=open(folders[i]+os.sep+'station_data.txt') # create file pointer to txt file in current directory
				ln=fp.readline() 
				self.nodes[i-connectionsfound].name=ln[6:9] 
				ln=fp.readline()
				x=int(ln[3:6]) 
				ln=fp.readline()
				y=int(ln[3:6]) 
				self.nodes[i-connectionsfound].value=x,y # assign x and y values to the current node's value attribute
				fp.close() 
			
		files=glob.glob(folders[k]+os.sep+'**') # create a list containing the files containing the connection data between nodes
		for i in range (len(files)):
			# obtain node data from file name
			from_node=files[i][23:26] 
			to_node=files[i][27:30] 

			fp=open(files[i]) 
			ln=fp.readline()
			arcweight=[] # create list containing info about the connection weights across the 35 year period
			for j in range(35):	# fill arcweight list
				ln=fp.readline().strip()
				lnarray=ln.split(', ')	
				arcweight.append(float(lnarray[1]))
			avg=sum(arcweight)/35 # find average of connection weight
			fp.close() 
			for j in range(len(self.nodes)): # loop through list of nodes to find the ones the txt file refers to
				if self.nodes[j].name==from_node:
					fromnode_idx=j
				if self.nodes[j].name==to_node:
					tonode_idx=j
			
			self.join_nodes(self.nodes[fromnode_idx], self.nodes[tonode_idx], avg) 

	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
