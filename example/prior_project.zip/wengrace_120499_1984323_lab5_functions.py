# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint 1: how is an empty network object created in lab5_practice.py?**
		# **hint 2: take a look Section 0.6 in python101.ipynb, particularly attribute assignment**  
		# **hint 3: what values do the method arguments NAME and VALUE take when the method is called 
		#           in lab5_practice.py?**
		# **hint 4: what does the input argument 'self' represent in this method?**
				
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# **your pseudocode here**
		
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		
		# create an empty node object
		node=Node()
		# assign its attributes
		node.value=value
		node.name=name
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both input nodes have lists called arcs_in and arcs_out.
		# **   - what information do these store?
		# **   - because they are lists, they can be modified using the append method
		
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# ___
				
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		# ___
		arc=Arc()                   # create an empty arc object, assign its attributes
		
		# assign its attributes
		arc.weight=weight           
		arc.from_node=node_from
		arc.to_node=node_to
        # append arc to the list of arcs
		self.arcs.append(arc)
		node_from.arcs_out.append(arc)
		node_to.arcs_in.append(arc)
			
	def read_network(self, filename):
		
		'''Read data from FILENAME and construct the network.
			
		    Each line of FILENAME contains
			- the name of an origin node (first entry)
			- and destination;weight pairs (each pair separated by a comma)
				
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination node pair needs to be joined
			
		# **some useful (incomplete) code snippets**
		# ln.split
			
		# 1. THE PSEUDOCODE FOR THIS METHOD HAS ALREADY BEEN WRITTEN BELOW
					
		# open the file
		# open the file   
		fp = open(filename, 'r')
		
		# get first line (a string)
		# - strip() is a useful method that removes white-space from the beginning and 
		#   end of the string

		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
			# divide the string using the split() method for strings

			# extract the source node
			from_node_name = ln.split(',')[0]
			# extract the remaining arcs
			arcs = ln.split(',')[1:]
			
			# YOU WILL NEED TO THINK CAREFULLY ABOUT WHAT THIS TRY/EXCEPT BLOCK DOES
			# if node doesn't exist, add to network
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(from_node_name)           
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(from_node_name)
				# get the source node OBJECT, using the source node STRING
				from_node = self.get_node(from_node_name)	
			
			# read the arc information and add it to network
			for arc in arcs:
				# parse arc information
				weight = float(arc.split(';')[1])
				# get destination node 
				to_node_name = arc.split(';')[0]

				# if node doesn't exist, add to network
				try:
					# the output is a node object, the input is a string
					# this command raises an ERROR if the node DOESN'T exist
					to_node = self.get_node(to_node_name)
				except NetworkError:
					self.add_node(to_node_name)
					to_node = self.get_node(to_node_name)

				# get destination node object and link it to source node
				self.join_nodes(from_node,to_node,weight)	

			# get next line
			ln = fp.readline().strip()
		
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		# open the folder from input string directory
		output = os.listdir(directory)

		# read every folders in the input directory
		for i in range (len(output)):

			# read the files in the directory using try/except. 
			# if station_data.txt doesn't exit in output folder, then the folder is 'connection'
			try:   
				# read the station_data.txt files 
				datafromfile = np.genfromtxt(directory+os.sep+output[i]+os.sep+'station_data.txt', delimiter = ' ',skip_header=0,dtype='U10').T
				# assign node_name, x_value and y_value
				node_name = datafromfile[1][0]
				node_value = datafromfile[1][1:]
				x_value = float(node_value[0])
				y_value = float(node_value[1])
                # add nodes 
				self.add_node(node_name, (x_value,y_value))
			except:
				# read 'connections' and return the name of files(xxx-xxx.txt) in connections
				filename = os.listdir(directory+os.sep+output[i])
				count=i    # get the position of 'connections' in the directory which is used as a path to get the txt in it. 
		
        # get every text files in the 'connection' folder
		for files in filename:

			connection=files.split('.')[0]
			# get the source node and the destination node 
			from_node_name = connection.split('-')[0]
			to_node_name = connection.split('-')[1]

			# read the txt. files in connections and get the data in it
			data = np.genfromtxt(directory+os.sep+output[count]+os.sep+files,delimiter= ' ',skip_header=1).T
			weight_data=data[1]    # return all the weight as weight_data
			total_weight=0   # initialise the total weight
            

			# calculate the average weight as the arc weight
			for k in range(len(weight_data)):
				# get the sum of weight in each .txt file
				total_weight = float(total_weight + weight_data[k])
				# get the average arc_weight 
				weight = total_weight / len(weight_data)
			
			# join nodes 
			self.join_nodes(self.get_node(from_node_name),self.get_node(to_node_name),weight)
		
		       	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value 
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
