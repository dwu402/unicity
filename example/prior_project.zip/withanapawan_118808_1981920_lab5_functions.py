# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# **to do: create an empty node object, assign its attributes**
		# **hint 1: how is an empty network object created in lab5_practice.py?**
		# **hint 2: take a look Section 0.6 in python101.ipynb, particularly attribute assignment**  
		# **hint 3: what values do the method arguments NAME and VALUE take when the method is called 
		#           in lab5_practice.py?**
		# **hint 4: what does the input argument 'self' represent in this method?**
				
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		#		create a new NODE object
		#		assign the given name
		#		assign the given value
		# 		append node to the list of nodes

		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE

		nd = Node() #creating a new NODE object
		nd.name = name #assigning the given name	
		nd.value = value #assigning the given value
				
		# 3. THINK VERY CAREFULLY ABOUT WHAT THE NEXT COMMAND IS DOING
		# append node to the list of nodes
		self.nodes.append(nd)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		
		# **to do: create an empty arc object, assign its attributes**
		# **hint: both input nodes have lists called arcs_in and arcs_out.
		# **   - what information do these store?
		# **   - because they are lists, they can be modified using the append method
		
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		#		create new Arc object
		#		assign given wight
		#		assign to_node attribute
		#		assign from_node attribute
		#		join the tail of the arc by adding the arc in to the acrs_out list of the from_node 
		#		join the head of the arc by adding the arc in to the acrs_in list of the to_node
		#		add the arc in to the list of arcs for the overall network
			
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		ar =Arc() #create new Arc object
		ar.weight=weight #assign given wight
		ar.to_node = node_to # assign to_node attribute
		ar.from_node = node_from # assign from_node attribute
		node_from.arcs_out.append(ar) #join the tail of the arc by adding the arc in to the acrs_out list of the from_node
		node_to.arcs_in.append(ar)#join the head of the arc by adding the arc in to the acrs_in list of the to_node
		self.arcs.append(ar)#add the arc in to the list of arcs for the overall network
		
		
		
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination node pair needs to be joined
		
		
		# 1. THE PSEUDOCODE FOR THIS METHOD HAS ALREADY BEEN WRITTEN BELOW
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		# - strip() is a useful method that removes white-space from the beginning and 
		#   end of the string
		ln = fp.readline().strip()#getting the first line
		while ln is not '':        # keep looping to the end of the file
			# divide the string using the split() method for strings
			# - extract the source node
			# - extract the remaining arcs
			
			from_node_name=ln.split(',')[0]#extracting the name for the node by spliting the string at the comma and taking the first value
			arcs=ln.split(',')[1:]#making a list for the rest of the arc information given
		
			# YOU WILL NEED TO THINK CAREFULLY ABOUT WHAT THIS TRY/EXCEPT BLOCK DOES
			# if node doesn't exist, add to network
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(from_node_name)#finds the starting node if it already exist   
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(from_node_name)#if the node is not created yet, this will created the node
				
			# get the source node OBJECT, using the source node STRING
			from_node = self.get_node(from_node_name)#gets the source node
				
			# read the arc information in the arcs list and add it to network
			for arc in arcs:
				# parse arc information
				#splits arc information in the arcs list above at semicolons
				to=arc.split(';')[0]#sets the first part as the connecting node name
				weight=arc.split(';')[1]#sets the second value as the weight
				try:
					node_to = self.get_node(to)#finds the connecting node if it already exist        
				except NetworkError:
					self.add_node(to)#if the node is not created yet, this will created the node
				
				node_to = self.get_node(to)#finds the connecting node
				self.join_nodes(from_node, node_to, weight)#joins the two nodes with an arc between them
				
				
						
			# get next line
			ln = fp.readline().strip()
			
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	# **this method is incomplete, you must complete it as part of the lab task**
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		
		files = glob(directory+os.sep+'*') #creates a list of all the folders in the given directory        

		#this loops through all the files in the above list
		for file in files:  
			#if the folder is not the connections folder following steps are followed to create nodes           
			if os.path.isdir(file) and file != 'nz_network'+os.sep+'connections' :                        
				subfile = glob(file+os.sep+'*') #get all files in the given folder. in this case there is only one file in each folder
				#following step crates a 2D array by reading the information in the file 
				#information represented in the following order by spliting the strings at ':' sign
				#[['name' , name for the node
				# 'x val', x location
				# 'y val', y location]]
				data=np.genfromtxt(subfile[0],delimiter=':',dtype="|U5", autostrip=True)
				name=data[0][1]#variable extracting the name of the node from above matrix
				val=[int(data[1][1]),int(data[2][1])]#variable extracting x and y locations of the node from above matrix
				self.add_node(name,val)#uses the information extracted to create a new node usnd add_node method

		#lists all the files in the connections folder which was skipped in the above loop		
		folder=	glob(directory+os.sep+'connections'+os.sep+'*')

		#goes through all the files in the folder extracting arc information
		for file in folder:
			#following three steps of spliting strips down the folder path and extracts the connecting nodes
			link=file.split(os.sep)[-1]#strips all of the first section of the path only leaving the file name
			from_node=link.split('-')[0]#extracts from_node by spliting the file name at '-' and taking the first section
			to_node=link.split('-')[1].split('.')[0]#extracts to_node by spliting the file name at '-' and taking the second section and stripping the file extention
			
			from_n=self.get_node(from_node)#gets the corresponding from node using the name extracted above
			to_n=self.get_node(to_node)#gets the corresponding to node using the name extracted above
			#reads all sets of data in the goven file and creates a single column vector containing all capacity values
			weights=np.genfromtxt(file,skip_header=1,delimiter=',')[:,1]
			weight=np.mean(weights)#finds the mean value for the capacities recorded in the vector above
			self.join_nodes(from_n,to_n, weight)#uses all the information above to create arcs between the nodes


	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
