# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob


class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		

class Network(object):
	''' Basic network class.
	'''
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		node=Node()   # create an empty node object and assign its attributes
		node.name=name
		node.value=value

		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		arc = Arc()   # create an empty arc object and assign its attributes
		arc.weight=weight
		arc.to_node=node_to
		arc.from_node=node_from
		node_from.arcs_out.append(arc)    # add this arc object to arc attribute in the nodes
		node_to.arcs_in.append(arc)
		self.arcs.append(arc)

		pass
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		ln = fp.readline().strip()
		while ln is not '':        # keep looping to the end of the file
	
			arcs=ln.split(",") # seperate the line string with ","
			src=arcs.pop(0) # the first element of arcs would be the source node

			# if node doesn't exist, add to network
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(src)           
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(src)
				
			# get the source node OBJECT, using the source node STRING
			src=self.get_node(src)
				
			# read the arc information and add it to network
			for arc in arcs:
				# parse arc information
				dstn,wght=arc.split(";")
				try:  # check if the node exists in self.nodes
					to_node=self.get_node(dstn)
				except NetworkError:
					self.add_node(dstn)  # add this node if an error is raised above
				
				dstn=self.get_node(dstn)  # get the destination node object
				self.join_nodes(src,dstn,wght)			
				
				pass
						
			# get next line
			ln = fp.readline().strip()
			
class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''		

	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		# access the folder containing the informations about the network
		folders1=glob('nz_network') 
		folders2=glob(folders1[0]+os.sep+'nz_network')
		folders=glob(folders2[0]+os.sep+'*')
		for folder in folders:
			if folder.split(os.sep)[-1]!='connections': # check each folder except "connections"
				data=open(glob(folder+os.sep+'station_data.txt')[0])
				info=[]
				for i in range(3):
					ln=data.readline().strip() # get informations from each line
					info.append(ln.split(":")[1])
				info[0]=info[0].strip()
				info[1]=int(info[1]) # make strings into int variables
				info[2]=int(info[2])
				self.add_node(info[0],[info[1],info[2]])
		folder=glob(folders2[0]+os.sep+'connections')[0] 
		connections=glob(folder+os.sep+'*.txt') # loop through the txt files in connections
		for txts in connections: 
			data=open(txts)
			ln=data.readline().strip() # skip the header
			ln=data.readline().strip()
			i=0
			wght=0
			while ln is not '':
				i=i+1  # count the number of capacities
				wght=wght+float(ln.split(",")[1]) # add up the capacities
				ln=data.readline().strip()
			wght=wght/i  # calculate the average
			# extracting both node from the file name
			from_node,to_node=txts.split(os.sep)[-1].strip(".txt").split("-") 			
			from_node=self.get_node(from_node)
			to_node=self.get_node(to_node)
			# creating an arc with the informations above
			self.join_nodes(from_node,to_node,wght)
		pass
	
	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
