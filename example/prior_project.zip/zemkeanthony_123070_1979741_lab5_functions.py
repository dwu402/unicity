# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		#set of empty lists and objects
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.to_node.name,self.from_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
			Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	#adding a node t the network object
	#value=none is a default 
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# create an empty node object
		node = Node()
		# assigning varriables to the attributes
		# assign a node name
		node.name = name
		#assign a node value
		node.value = value
		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		#self is already defined
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# create an empty arc object to assign attributes to
		arc = Arc()
		# create an arc to an existing node
		arc.to_node = node_to
		# create an arc from an existing node
		arc.from_node = node_from
		# attribute a weight value to the arc
		arc.weight = weight

		# append the new arc to the list of arcs
		self.arcs.append(arc)

		# adds the arcs created to the nodes' list of arcs (from)
		node_from.arcs_out.append(arc)
		# adds the arcs created to the nodes' list of arcs (into)
		node_to.arcs_in.append(arc)

		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		# strip the white space from the beginning and end of the line
		ln = fp.readline().strip()
		# create a while loop to run through the file lines until 
		# stop when it reaches an empty line
		while ln is not '':        
			# divide the string using the split() method for strings at the ',' character
			newLine = ln.split(',')
			# use the pop function to assign the origin node name
			# pop the first character only
			origin_node = newLine.pop(0)
			# initialise the arrays nodes_to and weights
			# these variables will be used to store the arc destinations and arc weights
			nodes_to = []
			weights = []

			# an if statement to make sure the line being red has node values
			if len(newLine) > 0:

				# a for loop to run through the different node destinations	
				for i in range(len(newLine)):
    				# split the line using the delimiter ';' into the destination node and weight
					nd_to,wghts = newLine[i].split(';')
					# append the node to the array nodes_to
					nodes_to.append(nd_to)
					# append the arc weight to the array weights
					weights.append(wghts)
							
			# if the origin node doesnt exist then add it to the network		
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				# tries to access node (get) 
				from_node = self.get_node(origin_node)           
			except NetworkError:
				# this command gets executed if an error is raised above
				# establishes the new node if not already made
				# adds the new node string to the node class
				self.add_node(origin_node) 
				
			# get the source node OBJECT, using the source node STRING
			from_node = self.get_node(origin_node)
				
			# run throught the number of node destinations
			for i in range(len(weights)):
						
				# if destinination node does not exist then add it to the network
				try:
					# test if the node that you are pointing to does not exist
					to_node = self.get_node(nodes_to[i])
				except NetworkError:
					# if the node does not exist and raises an error, 
					# add the node (string)
					self.add_node(nodes_to[i])

				# add the node to the variable to_node (object) using the source node string
				to_node = self.get_node(nodes_to[i])
				# find the specific weight to correlate to the nodes being joined
				arc_weight = weights[i]
				# calling from a differnet method,
				# get destination node and link it to the source node with a weight specified
				self.join_nodes(from_node, to_node, float(arc_weight))
			
			# read the next line or the loop to run through
			ln = fp.readline().strip()		
						
		#close the file
		fp.close()
		 
			

class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''	
	
	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
		# use glob to assign the names of all the directories within the directory chosen to output
		output = glob(directory+os.sep+'*')
		# loop through the number of directories listed
		for i in range(len(output)):
    		# an if statement to accept only directories and to skip past the folder 'connections'
			if os.path.isdir(output[i]) and output[i] != (directory+os.sep+'connections'): 
				# open the file station.txt and transpose its text
				# set up two coloumns,keeping data from the right side in 'data', delimited by ': '
				none,data = np.genfromtxt(output[i]+os.sep+'station_data.txt',dtype = str , delimiter = ': ').T
				# assign the first row to be the node name (string)
				node_name = data[0]
				# create an empty array for the coordinates
				# assign the second row value to be the x coordinate
				# assign the third row value to be the y coordinate
				node_position = [0,0]
				node_position[0],node_position[1] = float(data[1]), float(data[2])

				# create a node with the name as the string
				self.add_node(node_name)
				# get the node from the network to assign its attributes (x and y)
				node = self.get_node(node_name)
				node.value = node_position
		   
		# connections is a folder that has all the files glob will retrieve
		# glob will create a list of all of these files
		# directory is the name of the folder connections is in
		connections = glob(directory+os.sep+'connections'+os.sep+'*')

		# creating node lists (origin and entry)
		originNodes = []
		entryNodes = []

		#a for loop to run through the length of the connections list
		for i in range(len(connections)):
			
			# for each file within the list
			# strip off the directory and '.txt' to reveal the arc vector
			name = connections[i].strip(directory+os.sep+'connections'+os.sep+'.txt')
			# split the arc vector into the origin and entry node
			origin_Nodes,entry_Nodes = name.split('-')
			# append the node name strings to the arrays containing all the joining nodes
			originNodes.append(origin_Nodes)
			entryNodes.append(entry_Nodes)
			# create the node_from
			node_from = self.get_node(originNodes[i])
			# create the node_to
			node_to = self.get_node(entryNodes[i])

			# generate the arc weight by opening each file and extracting the capacity data
			# create an average value for the arc weight from the sum of the capacities 
			# and the number of data points
			none,data = np.genfromtxt(connections[i], dtype = float, delimiter = ', ', skip_header = 1).T
			average = sum(data) / len(data)

			#create the arc and join the two nodes together
			self.join_nodes(node_from, node_to, average)

	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
