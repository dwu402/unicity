# ENGSCI233: Lab 5 - Data
# lab5_functions.py

# PURPOSE:
# To IMPLEMENT several METHODS for NETWORK DATA STRUCTURES.

# PREPARATION:
# Notebooks data.ipynb and python101.ipynb ESPECIALLY Section 0.6 on Classes, objects, attributes, and methods.

# SUBMISSION:
# - YOU MUST submit this file to complete the lab. 
# - DO NOT change the file name.

# TO DO:
# - COMPLETE the methods add_node(), join_nodes() and read_network() as part of the Network class.
# - COMPLETE the method read_network() as part of the NetworkNZ class.
# - DO NOT modify the other classes and methods.

# Submission by Xinyi Zhang
#            Username : xzha909
#            ID : 978432703

# imports
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from glob import glob

	
# these classes and methods are complete, do not modify them
class Node(object):
	def __init__(self):
		self.name = None
		self.value = None
		self.arcs_in = []
		self.arcs_out = []
	def __repr__(self):
		return 'nd:{}'.format(self.name)
class Arc(object):
	def __init__(self):
		self.weight=None
		self.to_node = None
		self.from_node = None
	def __repr__(self):
		return '{} -> {}'.format(self.from_node.name,self.to_node.name)
class NetworkError(Exception):
	'''An error to raise when violations occur.
	'''
	pass
		
	
# **this class is incomplete, you must complete it as part of the lab task**
#                 ----------
class Network(object):
	''' Basic network class.
	'''
	# these methods are complete, do not modify them
	def __init__(self):
		self.nodes = []
		self.arcs = []
	def __repr__(self):
		return 'ntwk'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# **these methods are incomplete, you must complete them as part of the lab task**
	def add_node(self, name, value=None):
		'''Adds a Node with NAME and VALUE to the network.
		'''

		# **to do: create an empty node object, assign its attributes**
		# **hint 1: how is an empty network object created in lab5_practice.py?**
		# **hint 2: take a look Section 0.6 in python101.ipynb, particularly attribute assignment**  
		# **hint 3: what values do the method arguments NAME and VALUE take when the method is called 
		#           in lab5_practice.py?**
		# **hint 4: what does the input argument 'self' represent in this method?**
				
		# 1. WRITE PSEUDOCODE BELOW (optional, recommended)
		# **your pseudocode here**
		
		# 2. IMPLEMENT COMMANDS FOR YOUR PSEUDOCODE
		# add an empty node object
		node = Node()

		# modify its attributes
		node.value = value
		node.name = name

		# 3. THINK VERY CAREFULLY ABOUT WHAT THE NEXT COMMAND IS DOING
		# append node to the list of nodes
		self.nodes.append(node)

		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		arc = Arc()
		# store the node_from, node_to and weight inputs in arc.
		arc.from_node = node_from
		arc.to_node = node_to
		arc.weight = weight

		# **   - because they are lists, they can be modified using the append method
		# use append method to add arc in self. 
		self.arcs.append(arc)
		# At from node the arc is toward an another node, therefore add arc in arcs_out
		node_from.arcs_out.append(arc)
		# At to node the arc is toward this node, therefore add arc in arcs_in
		node_to.arcs_in.append(arc)
	
		# **delete the placeholder command below once you have written your code**


		
		
	def read_network(self, filename):
		'''Read data from FILENAME and construct the network.
		
			Each line of FILENAME contains
			 - the name of an origin node (first entry)
			 - and destination;weight pairs (each pair separated by a comma)
			 
		'''
		# **to do**
		# **hint: inspect 'network.txt' so that you understand the file structure**
		# **hint: each source-destination node pair needs to be joined

		# **some useful (incomplete) code snippets**
		# ln.split
				
		# open the file
		fp = open(filename, 'r')
		
		# get first line (a string)
		# - strip() is a useful method that removes white-space from the beginning and 
		#   end of the string
		ln = fp.readline().strip()
		while ln is not '':     
			# The first character in the line is the start node, store it in from_node_name
			from_node_name = ln.split(',')[0]
			# The characters behind the start node are to nodes and weights, store them in arcs
			arcs = ln.split(',')[1:]
		    # keep looping to the end of the file

			# YOU WILL NEED TO THINK CAREFULLY ABOUT WHAT THIS TRY/EXCEPT BLOCK DOES
			# if node doesn't exist, add to network
			try:
				# the output is a node object, the input is a string
				# this command raises an ERROR if the node DOESN'T exist
				from_node = self.get_node(from_node_name)           
			except NetworkError:
				# this command gets executed if an error is raised above
				self.add_node(from_node_name)
				from_node = self.get_node(from_node_name)
			# get the source node OBJECT, using the source node STRING	
			# read the arc information and add it to network
			for arc in arcs:
				# parse arc information
			
				# each arc character in arcs contains two parts: a letter and a number
				# The number part in arc is weight, store it in weight
				weight = arc.split(';')[1]
				# use try/except method to get arc_weight
				try:
					arc_weight = self.get_node(weight)        
				except NetworkError:
					self.add_node(weight)
					arc_weight = self.get_node(weight)
				# The letter part in arc is name of the to node, store it in end_node
				end_node = arc.split(';')[0]
				# use try/except method to get to_node
				try:
					to_node = self.get_node(end_node)   
				except NetworkError:
					self.add_node(end_node)
					to_node = self.get_node(end_node)
		
				# get destination node object and link it to source node
				# use join_nodes method to create arcs
				self.join_nodes(from_node,to_node,arc_weight)
				
				
			# get next line
			ln = fp.readline().strip()
			


# **this class is incomplete, you must complete it as part of the lab task**

class NetworkNZ(Network):
	''' Derived Network class, for NZ networks.
	'''
	# copy and paste the defs from class Network
	def __init__ (self):
		self.nodes = []
		self.arcs = []
	def __repr__ (self):
		return 'ntwknz'
	def get_node(self, name):
		''' Loops through the list of nodes and returns the one with NAME.
		
		    Returns NetworkError if node does not exist.
		'''
		# loop through list of nodes until node found
		for node in self.nodes:
			if node.name == name:
				return node
		
		raise NetworkError
	def display(self):
		''' Print information about the network.
		'''
		# print nodes
		print('network has {:d} nodes: '.format(len(self.nodes))+(len(self.nodes)*'{}, ').format(*(nd.name for nd in self.nodes)))
		# print arcs
		for arc in self.arcs:
			print ('{} --> {} with weight {}'.format(arc.from_node.name, arc.to_node.name, arc.weight))
	
	# Same add_node and join_nodes in class Network
	def add_node(self, name, value):
		'''Adds a Node with NAME and VALUE to the network.
		'''
		# add an empty node object
		node = Node()

		# modify its attributes
		node.value = value
		node.name = name

		# append node to the list of nodes
		self.nodes.append(node)
		
	def join_nodes(self, node_from, node_to, weight):
		'''Adds an Arc joining NODE_FROM to NODE_TO with WEIGHT.
		'''
		# **to do: create an empty arc object, assign its attributes**
		arc = Arc()
		# store the node_from, node_to and weight inputs in arc.
		arc.from_node = node_from
		arc.to_node = node_to
		arc.weight = weight

		# **   - because they are lists, they can be modified using the append method
		# use append method to add arc in self. 
		self.arcs.append(arc)
		# At from node the arc is toward an another node, therefore add arc in arcs_out
		node_from.arcs_out.append(arc)
		# At to node the arc is toward this node, therefore add arc in arcs_in
		node_to.arcs_in.append(arc)

	def read_network(self, directory):
		''' Read network information from input string DIRECTORY
		
			Notes:
			------
			Assume that DIRECTORY contains one folder for connections between nodes. 
			All other folders define the nodes of the network. 
			
			Each node folder contains a file called station_data.txt
			This file includes the node name and x and y values for the node position.
			
			In the connections folder, there is a file for each connection.
			The name of the file indicates which two nodes are connected (from-to).
			The contents of the file record the capacity of that connection over the last 35 years.
			The connection (arc) weight should be the mean capacity.
		'''
	
		# Use glob to get all the station_data.txt files' names and store in station_data_paths
		from glob import glob
		station_data_paths = glob( directory + "\\*\\station_data.txt" )
		# Use for loop to access each folder's station_data.txt file
		for station_data_path in station_data_paths:
			# Read stations data from station_data.txt
			nodes_data = np.genfromtxt(station_data_path , delimiter = ':' ,dtype = 'str')
			# Store code of each node contains in txt file in nodes_name, the type is string
			nodes_name = nodes_data[0][1].strip()
			# Store x and y coordinates of nodes in value array and convert string type to float(coordinates need to be float type)
			value = [ float(nodes_data[1][1]), float(nodes_data[2][1]) ]
			# Use add_node method to add nodes_name and value in self.nodes
			self.add_node(nodes_name,value)

		# Use glob to get all txt files name in connections folder and store in connections_data array
		connections_data = glob (directory + '\\connections\\*.txt')

		# Use for loop to run through each file in connections folder
		for connection_data in connections_data :
			# Use np.genfromtxt to get datas except the header line from each file and store in arc_capacities array
			# Convert string to float(the arc weight need to be a float)
			arc_capacities = np.genfromtxt(connection_data,delimiter = ',',dtype = 'float',skip_header = 1)
			# Use np.mean to get the mean value of the capacities and store it in arc_mean
			arc_mean = np.mean(arc_capacities[:,1])
			# Use .replace to delete all things in each txt file name except the from node and to node names(type is string)
			# The node string should be like for example 'BPE-WKM'
			node = connection_data.replace(directory + '\\connections\\','').replace('.txt','')
			# Use split to get node_from name and node_to name, the code before '-' is the node_from and behind '-' is node_to
			node_from = node.split('-')[0]
			node_to = node.split('-')[1]
			# Use get_node method to get data of node_from and node_to and then use join_nodes method to create arcs and store datas in self.arcs
			# The inputs are accessed node_from, node_to and mean value of each years' capacity(which is the weight)
			self.join_nodes(self.get_node(node_from),self.get_node(node_to),arc_mean)

	# this method is complete, do not modify	
	def show(self, save=None):
		''' Plot the network and optionally save to file SAVE
		'''
		# create figure axes
		fig=plt.figure()
		fig.set_size_inches([10,10])
		ax=plt.axes()
		
		# NZ coastline as background
		img=mpimg.imread('bg.png')
		ax.imshow(img,zorder=1)
	
		# a filthy hack to get coordinates in the right spot...
		for node in self.nodes:
			x,y = node.value
			y = int((y+10)*1.06)
			x -= int(50*y/800.)
			node.value = [x,y]
	
		# draw nodes as text boxes with station names
			# bounding box properties
		props = dict(boxstyle='round', facecolor='white', alpha=1.0)
		for node in self.nodes:
			# extract coordinates
			x,y = node.value
			ax.text(x, y, node.name, ha = 'center', va = 'center', zorder = 2, bbox=props)
			
		# draw connections as lines
		weights = [arc.weight for arc in self.arcs]
			# scale for plotting connections
		wmin = np.min(weights)
		wmax = np.max(weights)
		lmin,lmax = [0.5, 10.0]
		
		# plot connections
		for arc in self.arcs:
			# compute line length, scales with connection size
			lw = (arc.weight-wmin)/(wmax-wmin)*(lmax-lmin)+lmin
			x1,y1 = arc.from_node.value
			x2,y2 = arc.to_node.value
			ax.plot([x1,x2],[y1,y2], '-', lw=lw, color = [0.6,0.6,0.6])
	
		# remove ticks
		ax.set_xticks([])
		ax.set_yticks([])
	
		# display options
		if save:
			# save to file
			plt.savefig(save, dpi=300)
			plt.close()
		else:
			# open figure window in screen
			plt.show()
	
	
		
		
		
		
		
		
		
		
		
			
